# 🚀 CheatEX Deployment Guide

Complete guide for publishing your CheatEX study platform to the web.

---

## 📦 Quick Start - Build Your Project

Before deploying, you need to create a production build:

```bash
npm run build
```

This creates a `dist/` folder with optimized static files ready for deployment.

---

## 🌐 Deployment Options

### 1. **Vercel** (Recommended - Easiest & Free)

**Best for:** React apps, automatic deployments, free SSL, global CDN

#### Option A: Deploy via CLI
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy (first time)
vercel

# Deploy to production
vercel --prod
```

#### Option B: Deploy via GitHub
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your GitHub repository
5. Vercel auto-detects Vite settings
6. Click "Deploy"

**Configuration:**
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: `npm install`

**Your site will be live at:** `https://your-project.vercel.app`

---

### 2. **Netlify** (Easy & Free)

**Best for:** Static sites, form handling, serverless functions

#### Option A: Drag & Drop (Simplest)
1. Run `npm run build`
2. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
3. Drag your `dist/` folder
4. Done!

#### Option B: Deploy via CLI
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build your project
npm run build

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

#### Option C: Deploy via GitHub
1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "Add new site" → "Import an existing project"
4. Connect to GitHub
5. Configure:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Click "Deploy"

**Your site will be live at:** `https://your-site.netlify.app`

---

### 3. **GitHub Pages** (Free)

**Best for:** Open-source projects, portfolio sites

#### Setup:
1. Install gh-pages package:
```bash
npm install --save-dev gh-pages
```

2. Update `vite.config.js` - add base URL:
```javascript
export default defineConfig({
  base: '/your-repo-name/', // Change this to your repo name
  // ... rest of config
})
```

3. Add deployment scripts to `package.json`:
```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

4. Deploy:
```bash
npm run deploy
```

**Your site will be live at:** `https://yourusername.github.io/your-repo-name/`

---

### 4. **Cloudflare Pages** (Fast & Free)

**Best for:** Global performance, DDoS protection, unlimited bandwidth

#### Deploy via CLI:
```bash
# Install Wrangler CLI
npm install -g wrangler

# Login to Cloudflare
wrangler login

# Build and deploy
npm run build
wrangler pages deploy dist --project-name=cheatex
```

#### Deploy via Dashboard:
1. Push code to GitHub
2. Go to [dash.cloudflare.com](https://dash.cloudflare.com)
3. Go to "Pages" → "Create a project"
4. Connect GitHub repository
5. Configure:
   - Build command: `npm run build`
   - Build output directory: `dist`
6. Click "Save and Deploy"

**Your site will be live at:** `https://cheatex.pages.dev`

---

### 5. **Render** (Free tier available)

**Best for:** Full-stack apps, static sites with APIs

1. Push code to GitHub
2. Go to [render.com](https://render.com)
3. Click "New" → "Static Site"
4. Connect GitHub repository
5. Configure:
   - Build Command: `npm run build`
   - Publish Directory: `dist`
6. Click "Create Static Site"

**Your site will be live at:** `https://your-site.onrender.com`

---

### 6. **Railway** (Free tier available)

**Best for:** Full-stack apps, databases, services

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize and deploy
railway init
railway up
```

Or deploy via dashboard at [railway.app](https://railway.app)

---

### 7. **Firebase Hosting** (Google Cloud)

**Best for:** Integration with Firebase services, Google ecosystem

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Initialize Firebase in your project
firebase init hosting

# Build your app
npm run build

# Deploy
firebase deploy --only hosting
```

**Configuration during init:**
- Public directory: `dist`
- Single-page app: `Yes`
- GitHub auto-deploy: `Optional`

**Your site will be live at:** `https://your-project.web.app`

---

### 8. **AWS Amplify** (Amazon Web Services)

**Best for:** AWS ecosystem integration, enterprise apps

1. Push code to GitHub
2. Go to [AWS Amplify Console](https://console.aws.amazon.com/amplify)
3. Click "New app" → "Host web app"
4. Connect GitHub repository
5. Configure:
   - Build command: `npm run build`
   - Output directory: `dist`
6. Click "Save and deploy"

---

### 9. **Azure Static Web Apps** (Microsoft Azure)

**Best for:** Microsoft ecosystem, enterprise deployments

```bash
# Install Azure Static Web Apps CLI
npm install -g @azure/static-web-apps-cli

# Build
npm run build

# Deploy via Azure portal or GitHub Actions
```

Or use Azure Portal:
1. Create a Static Web App resource
2. Connect to GitHub
3. Configure build settings
4. Deploy automatically on push

---

### 10. **DigitalOcean App Platform** (Paid)

**Best for:** More control, custom domains, team collaboration

1. Push code to GitHub
2. Go to [cloud.digitalocean.com/apps](https://cloud.digitalocean.com/apps)
3. Click "Create App"
4. Connect GitHub repository
5. Configure:
   - Build Command: `npm run build`
   - Output Directory: `dist`
6. Click "Next" and deploy

**Starts at:** $5/month

---

### 11. **Custom Server / VPS**

**Best for:** Full control, custom configurations

#### Using Nginx on Ubuntu/Debian:

```bash
# 1. Build your project locally
npm run build

# 2. Upload dist/ folder to your server
scp -r dist/* user@your-server:/var/www/cheatex

# 3. Configure Nginx
sudo nano /etc/nginx/sites-available/cheatex
```

**Nginx Configuration:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/cheatex;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Enable gzip compression
    gzip on;
    gzip_types text/css application/javascript image/svg+xml;
}
```

```bash
# Enable site and restart Nginx
sudo ln -s /etc/nginx/sites-available/cheatex /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

### 12. **Docker Deployment**

**Best for:** Containerized deployments, Kubernetes

Create `Dockerfile`:
```dockerfile
FROM nginx:alpine
COPY dist/ /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `nginx.conf`:
```nginx
server {
    listen 80;
    location / {
        root /usr/share/nginx/html;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
}
```

```bash
# Build image
docker build -t cheatex .

# Run container
docker run -p 80:80 cheatex
```

---

## 🔧 Pre-Deployment Checklist

Before deploying, make sure:

- [ ] `npm run build` completes successfully
- [ ] `npm run check:safe` passes (TypeScript + ESLint)
- [ ] Update `index.html` meta tags (already done ✓)
- [ ] Test the production build locally: `npm run serve`
- [ ] Remove any console.logs or debug code
- [ ] Check environment variables are configured
- [ ] Set up custom domain (optional)
- [ ] Configure SSL certificate (most platforms do this automatically)

---

## 🎯 Recommended Deployment Strategy

### For Beginners:
**Vercel or Netlify** - Easiest, free, automatic deployments from GitHub

### For Advanced Users:
**Cloudflare Pages** - Best performance, unlimited bandwidth

### For Enterprise:
**AWS Amplify or Azure** - Scalability, integration with cloud services

### For Full Control:
**VPS with Nginx** - Complete customization

---

## 🔒 Environment Variables

If you need environment variables, create `.env` file:

```env
VITE_API_URL=https://api.example.com
VITE_APP_NAME=CheatEX
```

**Important:** Environment variables in Vite must be prefixed with `VITE_`

Configure them in your deployment platform:
- **Vercel:** Settings → Environment Variables
- **Netlify:** Site settings → Environment variables
- **GitHub Pages:** Use GitHub Secrets and Actions

---

## 🌍 Custom Domain Setup

Most platforms support custom domains:

1. **Buy a domain** (Namecheap, GoDaddy, Google Domains)
2. **Add domain to deployment platform:**
   - Vercel: Settings → Domains
   - Netlify: Site settings → Domain management
   - Cloudflare: DNS settings
3. **Update DNS records:**
   - Add A record or CNAME pointing to platform
   - Wait for DNS propagation (5 min - 48 hours)

---

## 📊 Performance Optimization

Your site is already optimized with:
- ✓ Vite build optimization
- ✓ Code splitting
- ✓ Asset compression
- ✓ React 19 performance improvements

Additional tips:
- Use CDN (most platforms include this)
- Enable HTTP/2
- Configure caching headers
- Use lazy loading for images

---

## 🚨 Common Issues & Solutions

### Build fails with TypeScript errors
```bash
npm run check:safe
# Fix any reported errors
```

### 404 errors on deployed site
Configure rewrites to serve `index.html` for all routes (most platforms do this automatically for SPAs)

### Environment variables not working
Make sure they're prefixed with `VITE_` and configured in your deployment platform

### Slow load times
- Check bundle size: Large dependencies?
- Enable compression
- Use CDN
- Optimize images

---

## 📈 Next Steps After Deployment

1. **Analytics:** Add Google Analytics or Plausible
2. **Monitoring:** Set up error tracking (Sentry, LogRocket)
3. **SEO:** Add meta tags, sitemap, robots.txt
4. **Performance:** Monitor with Lighthouse, Web Vitals
5. **CI/CD:** Set up automated deployments from GitHub

---

## 🎉 You're Ready to Deploy!

Choose your preferred platform above and follow the steps. Most deployments take less than 5 minutes!

**Questions?** Check platform-specific documentation:
- [Vercel Docs](https://vercel.com/docs)
- [Netlify Docs](https://docs.netlify.com)
- [Cloudflare Pages Docs](https://developers.cloudflare.com/pages)
