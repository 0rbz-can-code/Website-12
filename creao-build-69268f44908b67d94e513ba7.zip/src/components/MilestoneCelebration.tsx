import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";

interface MilestoneCelebrationProps {
	minutes: number;
	onDismiss: () => void;
}

export function MilestoneCelebration({ minutes, onDismiss }: MilestoneCelebrationProps) {
	const [isVisible, setIsVisible] = useState(true);

	useEffect(() => {
		// Auto-dismiss after 7 seconds
		const timer = setTimeout(() => {
			setIsVisible(false);
			setTimeout(onDismiss, 500); // Wait for fade out animation
		}, 7000);

		return () => clearTimeout(timer);
	}, [onDismiss]);

	if (!isVisible) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
			{/* Backdrop with sparkle effects */}
			<div className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-in fade-in duration-500" />

			{/* Celebration card */}
			<div className="relative z-10 animate-in zoom-in duration-700 slide-in-from-bottom-8">
				<div className="bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 p-1 rounded-3xl shadow-2xl">
					<div className="bg-white rounded-3xl px-12 py-10 text-center space-y-6">
						{/* Geometric Cat */}
						<div className="relative inline-block">
							<svg
								className="w-32 h-32 animate-bounce"
								viewBox="0 0 200 200"
								xmlns="http://www.w3.org/2000/svg"
							>
								{/* Left ear */}
								<polygon
									points="40,60 60,20 80,60"
									fill="#fbbf24"
									className="animate-pulse"
									style={{ animationDuration: "2s" }}
								/>
								{/* Right ear */}
								<polygon
									points="120,60 140,20 160,60"
									fill="#fbbf24"
									className="animate-pulse"
									style={{ animationDuration: "2s", animationDelay: "0.3s" }}
								/>
								{/* Head */}
								<circle
									cx="100"
									cy="100"
									r="50"
									fill="#f59e0b"
									className="animate-pulse"
									style={{ animationDuration: "1.5s" }}
								/>
								{/* Left eye */}
								<circle cx="85" cy="95" r="8" fill="#1f2937" />
								<circle cx="87" cy="93" r="3" fill="white" />
								{/* Right eye */}
								<circle cx="115" cy="95" r="8" fill="#1f2937" />
								<circle cx="117" cy="93" r="3" fill="white" />
								{/* Nose */}
								<polygon points="100,105 95,112 105,112" fill="#ec4899" />
								{/* Mouth */}
								<path
									d="M 100 112 Q 90 120 85 115"
									stroke="#1f2937"
									strokeWidth="2"
									fill="none"
									strokeLinecap="round"
								/>
								<path
									d="M 100 112 Q 110 120 115 115"
									stroke="#1f2937"
									strokeWidth="2"
									fill="none"
									strokeLinecap="round"
								/>
								{/* Whiskers */}
								<line x1="50" y1="100" x2="70" y2="98" stroke="#1f2937" strokeWidth="1.5" />
								<line x1="50" y1="105" x2="70" y2="105" stroke="#1f2937" strokeWidth="1.5" />
								<line x1="130" y1="98" x2="150" y2="100" stroke="#1f2937" strokeWidth="1.5" />
								<line x1="130" y1="105" x2="150" y2="105" stroke="#1f2937" strokeWidth="1.5" />
							</svg>

							{/* Sparkles around cat */}
							<Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-400 animate-spin" style={{ animationDuration: "3s" }} />
							<Sparkles className="absolute -bottom-2 -left-2 w-6 h-6 text-pink-400 animate-spin" style={{ animationDuration: "4s" }} />
							<Sparkles className="absolute top-1/2 -right-4 w-5 h-5 text-purple-400 animate-pulse" />
							<Sparkles className="absolute top-1/2 -left-4 w-5 h-5 text-orange-400 animate-pulse" style={{ animationDelay: "0.5s" }} />
						</div>

						{/* Congratulations text */}
						<div className="space-y-3">
							<h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent">
								Great Job!
							</h2>
							<p className="text-xl font-semibold text-gray-700">
								You studied for {minutes} minutes!
							</p>
							<p className="text-base text-gray-600">
								Keep up the amazing work! 🎉
							</p>
						</div>

						{/* Confetti particles */}
						<div className="absolute inset-0 overflow-hidden pointer-events-none">
							{[...Array(20)].map((_, i) => (
								<div
									key={i}
									className="absolute w-2 h-2 rounded-full animate-ping"
									style={{
										left: `${Math.random() * 100}%`,
										top: `${Math.random() * 100}%`,
										backgroundColor: ["#ec4899", "#f59e0b", "#8b5cf6", "#06b6d4"][i % 4],
										animationDelay: `${Math.random() * 2}s`,
										animationDuration: `${2 + Math.random() * 2}s`,
									}}
								/>
							))}
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
