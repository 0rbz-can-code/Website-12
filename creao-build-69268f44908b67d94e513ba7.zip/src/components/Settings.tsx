import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useBackground, type BackgroundTheme } from "@/contexts/BackgroundContext";
import { Check, Volume2, Bell, Clock, Zap, Volume1, VolumeX } from "lucide-react";
import { useState, useEffect } from "react";
import { soundManager, SoundEffect, playSound } from "@/lib/sounds";

export function Settings() {
	const { theme, setTheme } = useBackground();

	// Study Settings
	const [soundEnabled, setSoundEnabled] = useState(() => soundManager.isEnabled());
	const [soundVolume, setSoundVolume] = useState(() => soundManager.getVolume() * 100);

	const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
		const saved = localStorage.getItem("notifications-enabled");
		return saved !== null ? JSON.parse(saved) : true;
	});

	const [studySessionDuration, setStudySessionDuration] = useState(() => {
		const saved = localStorage.getItem("study-session-duration");
		return saved ? parseInt(saved) : 25;
	});

	const [breakDuration, setBreakDuration] = useState(() => {
		const saved = localStorage.getItem("break-duration");
		return saved ? parseInt(saved) : 5;
	});

	const [autoAdvanceFlashcards, setAutoAdvanceFlashcards] = useState(() => {
		const saved = localStorage.getItem("auto-advance-flashcards");
		return saved !== null ? JSON.parse(saved) : false;
	});

	const [fontSize, setFontSize] = useState(() => {
		const saved = localStorage.getItem("font-size");
		return saved || "medium";
	});

	const [animationsEnabled, setAnimationsEnabled] = useState(() => {
		const saved = localStorage.getItem("animations-enabled");
		return saved !== null ? JSON.parse(saved) : true;
	});

	// Save settings to localStorage
	useEffect(() => {
		soundManager.setEnabled(soundEnabled);
	}, [soundEnabled]);

	useEffect(() => {
		soundManager.setVolume(soundVolume / 100);
	}, [soundVolume]);

	useEffect(() => {
		localStorage.setItem("notifications-enabled", JSON.stringify(notificationsEnabled));
	}, [notificationsEnabled]);

	useEffect(() => {
		localStorage.setItem("study-session-duration", studySessionDuration.toString());
	}, [studySessionDuration]);

	useEffect(() => {
		localStorage.setItem("break-duration", breakDuration.toString());
	}, [breakDuration]);

	useEffect(() => {
		localStorage.setItem("auto-advance-flashcards", JSON.stringify(autoAdvanceFlashcards));
	}, [autoAdvanceFlashcards]);

	useEffect(() => {
		localStorage.setItem("font-size", fontSize);
		// Apply font size to document
		document.documentElement.style.fontSize = fontSize === "small" ? "14px" : fontSize === "large" ? "18px" : "16px";
	}, [fontSize]);

	useEffect(() => {
		localStorage.setItem("animations-enabled", JSON.stringify(animationsEnabled));
		// Apply animation preference
		if (!animationsEnabled) {
			document.documentElement.style.setProperty("--animation-duration", "0s");
		} else {
			document.documentElement.style.removeProperty("--animation-duration");
		}
	}, [animationsEnabled]);

	const themes: { value: BackgroundTheme; label: string; preview: string; category: string }[] = [
		// Plain Themes
		{
			value: "focuscore-light",
			label: "Plain Light",
			preview: "bg-white border border-gray-200",
			category: "Plain",
		},
		{
			value: "focuscore-dark",
			label: "Plain Dark",
			preview: "bg-black",
			category: "Plain",
		},
		// Gradient Themes
		{
			value: "gradient",
			label: "Default Gradient",
			preview: "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50",
			category: "Gradient",
		},
		{
			value: "forest",
			label: "Forest",
			preview: "bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50",
			category: "Gradient",
		},
		{
			value: "ocean",
			label: "Ocean",
			preview: "bg-gradient-to-br from-blue-50 via-cyan-50 to-sky-50",
			category: "Gradient",
		},
		{
			value: "sunset",
			label: "Sunset",
			preview: "bg-gradient-to-br from-orange-50 via-rose-50 to-pink-50",
			category: "Gradient",
		},
		{
			value: "beach",
			label: "Beach",
			preview: "bg-gradient-to-br from-amber-50 via-orange-50 to-cyan-100",
			category: "Gradient",
		},
		{
			value: "night-sky",
			label: "Night Sky",
			preview: "bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950",
			category: "Gradient",
		},
		{
			value: "space",
			label: "Space",
			preview: "bg-gradient-to-br from-black via-slate-900 to-indigo-950",
			category: "Gradient",
		},
		// Picture Themes
		{
			value: "nature-mountains",
			label: "Mountain View",
			preview: "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJza3kiIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMCUiIHkyPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdHlsZT0ic3RvcC1jb2xvcjojODdDRUVCO3N0b3Atb3BhY2l0eToxIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojRTBGMkZFO3N0b3Atb3BhY2l0eToxIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSJ1cmwoI3NreSkiLz48cG9seWdvbiBwb2ludHM9IjAsMzAwIDIwMCw0MDAgNTAwLDIwMCA3MDAsNDAwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjNEE1NTY4Ii8+PHBvbHlnb24gcG9pbnRzPSIxMDAsMzUwIDMwMCw0NTAgNjAwLDI1MCA4MDAsNDUwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjNjM3NDhCIi8+PHBvbHlnb24gcG9pbnRzPSIyMDAsMzgwIDQwMCw0ODAgNzAwLDI4MCA5MDAsNDgwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjOEI5NUE2Ii8+PC9zdmc+')] bg-cover bg-center",
			category: "Picture",
		},
		{
			value: "nature-forest",
			label: "Forest Scene",
			preview: "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJmb3Jlc3QiIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMCUiIHkyPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMzQ0RTQxO3N0b3Atb3BhY2l0eToxIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojNkY5MTdEO3N0b3Atb3BhY2l0eToxIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSJ1cmwoI2ZvcmVzdCkiLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxNTAiIHI9IjgwIiBmaWxsPSIjMjI1YTMzIiBvcGFjaXR5PSIwLjYiLz48Y2lyY2xlIGN4PSIzMDAiIGN5PSIyMDAiIHI9IjEwMCIgZmlsbD0iIzFhNGQyZSIgb3BhY2l0eT0iMC42Ii8+PGNpcmNsZSBjeD0iNTUwIiBjeT0iMTgwIiByPSI5MCIgZmlsbD0iIzJmNmUzZiIgb3BhY2l0eT0iMC42Ii8+PGNpcmNsZSBjeD0iNzUwIiBjeT0iMjIwIiByPSIxMTAiIGZpbGw9IiMxYzQ2MmIiIG9wYWNpdHk9IjAuNiIvPjxjaXJjbGUgY3g9IjkwMCIgY3k9IjE2MCIgcj0iNzAiIGZpbGw9IiMyODVhMzgiIG9wYWNpdHk9IjAuNiIvPjwvc3ZnPg==')] bg-cover bg-center",
			category: "Picture",
		},
		{
			value: "abstract-waves",
			label: "Ocean Waves",
			preview: "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJ3YXZlcyIgeDE9IjAlIiB5MT0iMCUiIHgyPSIxMDAlIiB5Mj0iMTAwJSI+PHN0b3Agb2Zmc2V0PSIwJSIgc3R5bGU9InN0b3AtY29sb3I6IzY2NjZmZjtzdG9wLW9wYWNpdHk6MSIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3R5bGU9InN0b3AtY29sb3I6I2NjY2NmZjtzdG9wLW9wYWNpdHk6MSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAwIiBoZWlnaHQ9IjYwMCIgZmlsbD0idXJsKCN3YXZlcykiLz48cGF0aCBkPSJNMCAxMDAgUTI1MCA1MCw1MDAgMTAwIFQxMDAwIDEwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiM5OTk5ZmYiIG9wYWNpdHk9IjAuMyIvPjxwYXRoIGQ9Ik0wIDIwMCBRMjUwIDE1MCw1MDAgMjAwIFQxMDAwIDIwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiNiYmJiZmYiIG9wYWNpdHk9IjAuMyIvPjxwYXRoIGQ9Ik0wIDMwMCBRMjUwIDI1MCw1MDAgMzAwIFQxMDAwIDMwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiNkZGRkZmYiIG9wYWNpdHk9IjAuMyIvPjwvc3ZnPg==')] bg-cover bg-center",
			category: "Picture",
		},
		{
			value: "abstract-geometry",
			label: "Geometric Art",
			preview: "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjZjNlNWY1Ii8+PHBvbHlnb24gcG9pbnRzPSIwLDAgMjAwLDAgMTAwLDIwMCIgZmlsbD0iI2U5Y2RmMSIgb3BhY2l0eT0iMC43Ii8+PHBvbHlnb24gcG9pbnRzPSI0MDAsMCA2MDAsMCA1MDAsNDAwIiBmaWxsPSIjZDhiZGU3IiBvcGFjaXR5PSIwLjciLz48cG9seWdvbiBwb2ludHM9IjgwMCwwIDEwMDAsMCA5MDAsNDAwIiBmaWxsPSIjYzdhZGRkIiBvcGFjaXR5PSIwLjciLz48cG9seWdvbiBwb2ludHM9IjAsMzAwIDMwMCwzMDAgMTUwLDYwMCIgZmlsbD0iI2I2OWRjMyIgb3BhY2l0eT0iMC43Ii8+PHBvbHlnb24gcG9pbnRzPSI1MDAsMjAwIDgwMCwyMDAgNjUwLDYwMCIgZmlsbD0iI2E1OGRiOSIgb3BhY2l0eT0iMC43Ii8+PC9zdmc+')] bg-cover bg-center",
			category: "Picture",
		},
		{
			value: "minimalist-lines",
			label: "Minimal Lines",
			preview: "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjZmFmYWZhIi8+PGxpbmUgeDE9IjAiIHkxPSIxMDAiIHgyPSIxMDAwIiB5Mj0iMTAwIiBzdHJva2U9IiNlMGUwZTAiIHN0cm9rZS13aWR0aD0iMiIvPjxsaW5lIHgxPSIwIiB5MT0iMjAwIiB4Mj0iMTAwMCIgeTI9IjIwMCIgc3Ryb2tlPSIjZTBlMGUwIiBzdHJva2Utd2lkdGg9IjIiLz48bGluZSB4MT0iMCIgeTE9IjMwMCIgeDI9IjEwMDAiIHkyPSIzMDAiIHN0cm9rZT0iI2UwZTBlMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PGxpbmUgeDE9IjAiIHkxPSI0MDAiIHgyPSIxMDAwIiB5Mj0iNDAwIiBzdHJva2U9IiNlMGUwZTAiIHN0cm9rZS13aWR0aD0iMiIvPjxsaW5lIHgxPSIwIiB5MT0iNTAwIiB4Mj0iMTAwMCIgeTI9IjUwMCIgc3Ryb2tlPSIjZTBlMGUwIiBzdHJva2Utd2lkdGg9IjIiLz48L3N2Zz4=')] bg-cover bg-center",
			category: "Picture",
		},
	];

	return (
		<div className="space-y-6">
			{/* Study Preferences */}
			<Card>
				<CardHeader>
					<CardTitle className="flex items-center gap-2">
						<Clock className="h-5 w-5" />
						Study Preferences
					</CardTitle>
					<CardDescription>Configure your study sessions and focus time</CardDescription>
				</CardHeader>
				<CardContent className="space-y-6">
					<div className="space-y-4">
						<div className="flex items-center justify-between">
							<div className="space-y-0.5">
								<Label className="text-base">Study Session Duration</Label>
								<p className="text-sm text-gray-600">Length of focused study sessions (Pomodoro)</p>
							</div>
							<div className="text-right">
								<span className="text-2xl font-bold text-indigo-600">{studySessionDuration}</span>
								<span className="text-sm text-gray-500 ml-1">min</span>
							</div>
						</div>
						<Slider
							value={[studySessionDuration]}
							onValueChange={(value) => setStudySessionDuration(value[0])}
							min={5}
							max={60}
							step={5}
							className="w-full"
						/>
					</div>

					<div className="space-y-4">
						<div className="flex items-center justify-between">
							<div className="space-y-0.5">
								<Label className="text-base">Break Duration</Label>
								<p className="text-sm text-gray-600">Length of breaks between study sessions</p>
							</div>
							<div className="text-right">
								<span className="text-2xl font-bold text-emerald-600">{breakDuration}</span>
								<span className="text-sm text-gray-500 ml-1">min</span>
							</div>
						</div>
						<Slider
							value={[breakDuration]}
							onValueChange={(value) => setBreakDuration(value[0])}
							min={1}
							max={30}
							step={1}
							className="w-full"
						/>
					</div>

					<div className="flex items-center justify-between pt-2 border-t">
						<div className="space-y-0.5">
							<Label className="text-base">Auto-advance Flashcards</Label>
							<p className="text-sm text-gray-600">Automatically move to next card after answering</p>
						</div>
						<Switch
							checked={autoAdvanceFlashcards}
							onCheckedChange={(checked) => {
								setAutoAdvanceFlashcards(checked);
								playSound(SoundEffect.Click);
							}}
						/>
					</div>
				</CardContent>
			</Card>

			{/* Interface Settings */}
			<Card>
				<CardHeader>
					<CardTitle className="flex items-center gap-2">
						<Zap className="h-5 w-5" />
						Interface Settings
					</CardTitle>
					<CardDescription>Customize how the platform looks and feels</CardDescription>
				</CardHeader>
				<CardContent className="space-y-6">
					<div className="flex items-center justify-between">
						<div className="space-y-0.5">
							<Label className="text-base flex items-center gap-2">
								<Volume2 className="h-4 w-4" />
								Sound Effects
							</Label>
							<p className="text-sm text-gray-600">Play sounds for interactions and notifications</p>
						</div>
						<Switch
							checked={soundEnabled}
							onCheckedChange={(checked) => {
								setSoundEnabled(checked);
								if (checked) playSound(SoundEffect.Success);
							}}
						/>
					</div>

					{soundEnabled && (
						<div className="space-y-4 pl-6 border-l-2 border-indigo-200">
							<div className="space-y-3">
								<div className="flex items-center justify-between">
									<Label className="text-sm font-medium">Volume</Label>
									<div className="flex items-center gap-2">
										{soundVolume === 0 ? (
											<VolumeX className="h-4 w-4 text-gray-400" />
										) : soundVolume < 50 ? (
											<Volume1 className="h-4 w-4 text-gray-600" />
										) : (
											<Volume2 className="h-4 w-4 text-indigo-600" />
										)}
										<span className="text-sm font-semibold text-indigo-600 w-10 text-right">
											{soundVolume}%
										</span>
									</div>
								</div>
								<Slider
									value={[soundVolume]}
									onValueChange={(value) => setSoundVolume(value[0])}
									min={0}
									max={100}
									step={5}
									className="w-full"
								/>
							</div>

							<div className="space-y-2">
								<Label className="text-sm font-medium">Test Sounds</Label>
								<div className="grid grid-cols-2 gap-2">
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.Click)}
										className="text-xs"
									>
										Click
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.Success)}
										className="text-xs"
									>
										Success
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.Error)}
										className="text-xs"
									>
										Error
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.Notification)}
										className="text-xs"
									>
										Notification
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.FlashcardFlip)}
										className="text-xs"
									>
										Flashcard
									</Button>
									<Button
										size="sm"
										variant="outline"
										onClick={() => soundManager.play(SoundEffect.Achievement)}
										className="text-xs"
									>
										Achievement
									</Button>
								</div>
							</div>
						</div>
					)}

					<div className="flex items-center justify-between">
						<div className="space-y-0.5">
							<Label className="text-base flex items-center gap-2">
								<Bell className="h-4 w-4" />
								Notifications
							</Label>
							<p className="text-sm text-gray-600">Show reminders and study alerts</p>
						</div>
						<Switch
							checked={notificationsEnabled}
							onCheckedChange={(checked) => {
								setNotificationsEnabled(checked);
								playSound(SoundEffect.Click);
							}}
						/>
					</div>

					<div className="flex items-center justify-between">
						<div className="space-y-0.5">
							<Label className="text-base">Animations</Label>
							<p className="text-sm text-gray-600">Enable UI animations and transitions</p>
						</div>
						<Switch
							checked={animationsEnabled}
							onCheckedChange={(checked) => {
								setAnimationsEnabled(checked);
								playSound(SoundEffect.Click);
							}}
						/>
					</div>

					<div className="space-y-3 pt-2 border-t">
						<Label className="text-base">Font Size</Label>
						<Select
							value={fontSize}
							onValueChange={(value) => {
								setFontSize(value);
								playSound(SoundEffect.Click);
							}}
						>
							<SelectTrigger className="w-full">
								<SelectValue placeholder="Select font size" />
							</SelectTrigger>
							<SelectContent>
								<SelectItem value="small">Small (14px)</SelectItem>
								<SelectItem value="medium">Medium (16px)</SelectItem>
								<SelectItem value="large">Large (18px)</SelectItem>
							</SelectContent>
						</Select>
					</div>
				</CardContent>
			</Card>

			{/* Background Theme */}
			<Card>
				<CardHeader>
					<CardTitle>Background Theme</CardTitle>
					<CardDescription>Choose a background theme that helps you focus best</CardDescription>
				</CardHeader>
				<CardContent className="space-y-6">
					{/* Plain Section */}
					<div className="space-y-3">
						<h3 className="text-sm font-semibold text-gray-700">Plain</h3>
						<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
								{themes
									.filter((t) => t.category === "Plain")
									.map((themeOption) => (
										<button
											key={themeOption.value}
											onClick={() => setTheme(themeOption.value)}
											className={`relative rounded-lg border-2 transition-all overflow-hidden ${
												theme === themeOption.value
													? "border-indigo-600 ring-2 ring-indigo-200"
													: "border-gray-200 hover:border-gray-300"
											}`}
										>
											<div className={`h-32 ${themeOption.preview}`} />
											<div className="p-3 bg-white">
												<div className="flex items-center justify-between">
													<span className="font-medium text-sm">{themeOption.label}</span>
													{theme === themeOption.value && (
														<Check className="h-4 w-4 text-indigo-600" />
													)}
												</div>
											</div>
										</button>
									))}
						</div>
					</div>

					{/* Picture Themes Section */}
					<div className="space-y-3">
						<h3 className="text-sm font-semibold text-gray-700 mt-6">Picture Themes</h3>
						<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
							{themes
								.filter((t) => t.category === "Picture")
								.map((themeOption) => (
									<button
										key={themeOption.value}
										onClick={() => {
											setTheme(themeOption.value);
											playSound(SoundEffect.Click);
										}}
										className={`relative rounded-lg border-2 transition-all overflow-hidden ${
											theme === themeOption.value
												? "border-indigo-600 ring-2 ring-indigo-200"
												: "border-gray-200 hover:border-gray-300"
										}`}
									>
										<div className={`h-32 ${themeOption.preview}`} />
										<div className="p-3 bg-white">
											<div className="flex items-center justify-between">
												<span className="font-medium text-sm">{themeOption.label}</span>
												{theme === themeOption.value && (
													<Check className="h-4 w-4 text-indigo-600" />
												)}
											</div>
										</div>
									</button>
								))}
						</div>
					</div>

					{/* Gradient Themes Section */}
					<div className="space-y-3">
						<h3 className="text-sm font-semibold text-gray-700 mt-6">Color Gradients</h3>
						<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
							{themes
								.filter((t) => t.category === "Gradient")
								.map((themeOption) => (
									<button
										key={themeOption.value}
										onClick={() => {
											setTheme(themeOption.value);
											playSound(SoundEffect.Click);
										}}
										className={`relative rounded-lg border-2 transition-all overflow-hidden ${
											theme === themeOption.value
												? "border-indigo-600 ring-2 ring-indigo-200"
												: "border-gray-200 hover:border-gray-300"
										}`}
									>
										<div className={`h-32 ${themeOption.preview}`} />
										<div className="p-3 bg-white">
											<div className="flex items-center justify-between">
												<span className="font-medium text-sm">{themeOption.label}</span>
												{theme === themeOption.value && (
													<Check className="h-4 w-4 text-indigo-600" />
												)}
											</div>
										</div>
									</button>
								))}
						</div>
					</div>

					<div className="pt-4 border-t">
						<Button
							onClick={() => {
								setTheme("gradient");
								playSound(SoundEffect.Success);
							}}
							variant="outline"
							className="w-full"
						>
							Reset to Default
						</Button>
					</div>
				</CardContent>
			</Card>
		</div>
	);
}
