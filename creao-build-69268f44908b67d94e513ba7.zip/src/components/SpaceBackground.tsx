import { useEffect, useRef } from "react";

interface Star {
	x: number;
	y: number;
	size: number;
	opacity: number;
	speed: number;
	glowIntensity: number;
}

export function SpaceBackground() {
	const canvasRef = useRef<HTMLCanvasElement>(null);

	useEffect(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;

		const ctx = canvas.getContext("2d");
		if (!ctx) return;

		// Set canvas size to match window
		const resizeCanvas = () => {
			canvas.width = window.innerWidth;
			canvas.height = window.innerHeight;
		};
		resizeCanvas();
		window.addEventListener("resize", resizeCanvas);

		// Create stars
		const stars: Star[] = [];
		const starCount = 150;

		for (let i = 0; i < starCount; i++) {
			stars.push({
				x: Math.random() * canvas.width,
				y: Math.random() * canvas.height,
				size: Math.random() * 2 + 0.5,
				opacity: Math.random() * 0.5 + 0.3,
				speed: Math.random() * 0.3 + 0.1,
				glowIntensity: Math.random() * 0.5 + 0.5,
			});
		}

		let animationFrameId: number;

		// Animation loop
		const animate = () => {
			// Clear canvas with space background
			ctx.fillStyle = "#000000";
			ctx.fillRect(0, 0, canvas.width, canvas.height);

			// Draw and update stars
			stars.forEach((star) => {
				// Pulsing glow effect
				star.glowIntensity += star.speed * 0.05;
				const glow = Math.sin(star.glowIntensity) * 0.3 + 0.7;

				// Create gradient for glow effect
				const gradient = ctx.createRadialGradient(
					star.x,
					star.y,
					0,
					star.x,
					star.y,
					star.size * 4 * glow
				);

				// Color variations - mostly white/blue with some purple/pink
				const colorRand = Math.random();
				let color1, color2;

				if (colorRand < 0.7) {
					// White/blue stars
					color1 = `rgba(200, 220, 255, ${star.opacity * glow})`;
					color2 = "rgba(200, 220, 255, 0)";
				} else if (colorRand < 0.85) {
					// Purple stars
					color1 = `rgba(180, 150, 255, ${star.opacity * glow})`;
					color2 = "rgba(180, 150, 255, 0)";
				} else {
					// Pink stars
					color1 = `rgba(255, 150, 200, ${star.opacity * glow})`;
					color2 = "rgba(255, 150, 200, 0)";
				}

				gradient.addColorStop(0, color1);
				gradient.addColorStop(1, color2);

				// Draw glowing dot
				ctx.fillStyle = gradient;
				ctx.beginPath();
				ctx.arc(star.x, star.y, star.size * 4 * glow, 0, Math.PI * 2);
				ctx.fill();

				// Draw bright center
				ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity * glow})`;
				ctx.beginPath();
				ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
				ctx.fill();

				// Slow vertical float
				star.y -= star.speed * 0.2;

				// Wrap around when stars go off screen
				if (star.y < -10) {
					star.y = canvas.height + 10;
					star.x = Math.random() * canvas.width;
				}
			});

			animationFrameId = requestAnimationFrame(animate);
		};

		animate();

		return () => {
			window.removeEventListener("resize", resizeCanvas);
			cancelAnimationFrame(animationFrameId);
		};
	}, []);

	return (
		<canvas
			ref={canvasRef}
			className="fixed inset-0 w-full h-full pointer-events-none"
			style={{ zIndex: 0 }}
		/>
	);
}
