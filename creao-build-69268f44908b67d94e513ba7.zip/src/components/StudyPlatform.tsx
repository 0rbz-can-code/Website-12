import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dashboard } from "./study/Dashboard";
import { AISummaryMode } from "./study/AISummaryMode";
import { StudyPlans } from "./study/StudyPlans";
import { TestMaker } from "./study/TestMaker";
import { FlashcardGenerator } from "./study/FlashcardGenerator";
import { Citations } from "./study/Citations";
import { Formulas } from "./study/Formulas";
import { Settings } from "./Settings";
import { SpaceBackground } from "./SpaceBackground";
import { Sparkles, CalendarDays, BookOpen, FileQuestion, LayoutDashboard, SettingsIcon, BookMarked, Calculator } from "lucide-react";
import { BackgroundProvider, useBackground, getBackgroundClass, shouldShowSpaceBackground } from "@/contexts/BackgroundContext";
import logo from "@/assets/cheatex-logo.svg";
import { playSound, SoundEffect } from "@/lib/sounds";

function StudyPlatformContent() {
	const [activeTab, setActiveTab] = useState("dashboard");
	const { theme } = useBackground();

	const handleTabChange = (value: string) => {
		playSound(SoundEffect.TabSwitch);
		setActiveTab(value);
	};

	return (
		<div className={`min-h-screen ${getBackgroundClass(theme)} transition-colors duration-500 relative`}>
			{shouldShowSpaceBackground(theme) && <SpaceBackground />}
			<div className="container mx-auto px-4 py-6 relative z-10">
				<header className="text-center mb-8">
					<div className="flex items-center justify-center gap-4 mb-3">
						<img
							src={logo}
							alt="CheatEX Logo"
							className="w-16 h-16 animate-pulse-slow"
						/>
						<h1
							className={`text-5xl font-extrabold ${shouldShowSpaceBackground(theme) || theme === 'focuscore-dark' || theme === 'night-sky' ? "text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]" : "text-gray-900"} animate-pulse-slow`}
						>
							CheatEX
						</h1>
					</div>
					<p className={`text-lg font-medium ${shouldShowSpaceBackground(theme) ? "text-gray-300" : "text-gray-600"}`}>
						The best app for cheating in 2025
					</p>
					<div className="mt-3 flex items-center justify-center gap-2">
						<div className="h-1 w-12 rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500" />
						<div className="h-1 w-8 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600" />
						<div className="h-1 w-4 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600" />
					</div>
				</header>

				<Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
					<TabsList className="grid w-full grid-cols-8 mb-6 h-auto p-1.5 bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800 shadow-lg rounded-xl">
						<TabsTrigger
							value="dashboard"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-indigo-600 data-[state=active]:to-indigo-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<LayoutDashboard className="h-5 w-5" />
							<span className="text-xs font-semibold">Dashboard</span>
						</TabsTrigger>
						<TabsTrigger
							value="ai-summary"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-purple-600 data-[state=active]:to-purple-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<Sparkles className="h-5 w-5" />
							<span className="text-xs font-semibold">AI Summary</span>
						</TabsTrigger>
						<TabsTrigger
							value="study-plans"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-pink-600 data-[state=active]:to-pink-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<CalendarDays className="h-5 w-5" />
							<span className="text-xs font-semibold">Study Plans</span>
						</TabsTrigger>
						<TabsTrigger
							value="flashcards"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-cyan-600 data-[state=active]:to-cyan-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<BookOpen className="h-5 w-5" />
							<span className="text-xs font-semibold">Flashcards</span>
						</TabsTrigger>
						<TabsTrigger
							value="quiz"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-green-600 data-[state=active]:to-green-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<FileQuestion className="h-5 w-5" />
							<span className="text-xs font-semibold">Test</span>
						</TabsTrigger>
						<TabsTrigger
							value="citations"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<BookMarked className="h-5 w-5" />
							<span className="text-xs font-semibold">Citations</span>
						</TabsTrigger>
						<TabsTrigger
							value="formulas"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-emerald-600 data-[state=active]:to-emerald-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<Calculator className="h-5 w-5" />
							<span className="text-xs font-semibold">Formulas</span>
						</TabsTrigger>
						<TabsTrigger
							value="settings"
							className="flex flex-col gap-1.5 py-3 rounded-lg transition-all duration-300 data-[state=active]:bg-gradient-to-br data-[state=active]:from-gray-600 data-[state=active]:to-gray-700 data-[state=active]:text-white data-[state=active]:shadow-xl data-[state=active]:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800"
						>
							<SettingsIcon className="h-5 w-5" />
							<span className="text-xs font-semibold">Settings</span>
						</TabsTrigger>
					</TabsList>

					<TabsContent value="dashboard" className="mt-0">
						<Dashboard onNavigate={setActiveTab} />
					</TabsContent>

					<TabsContent value="ai-summary" className="mt-0">
						<AISummaryMode />
					</TabsContent>

					<TabsContent value="study-plans" className="mt-0">
						<StudyPlans />
					</TabsContent>

					<TabsContent value="flashcards" className="mt-0">
						<FlashcardGenerator />
					</TabsContent>

					<TabsContent value="quiz" className="mt-0">
						<TestMaker />
					</TabsContent>

					<TabsContent value="citations" className="mt-0">
						<Citations />
					</TabsContent>

					<TabsContent value="formulas" className="mt-0">
						<Formulas />
					</TabsContent>

					<TabsContent value="settings" className="mt-0">
						<Settings />
					</TabsContent>
				</Tabs>
			</div>
		</div>
	);
}

export function StudyPlatform() {
	return (
		<BackgroundProvider>
			<StudyPlatformContent />
		</BackgroundProvider>
	);
}
