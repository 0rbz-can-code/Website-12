import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import "@testing-library/jest-dom";
import { AISummaryMode } from "./AISummaryMode";

// Mock toast
vi.mock("sonner", () => ({
	toast: {
		success: vi.fn(),
		error: vi.fn(),
	},
}));

describe("AISummaryMode", () => {
	beforeEach(() => {
		vi.clearAllMocks();
	});

	it("should render the component with all initial elements", () => {
		render(<AISummaryMode />);

		expect(screen.getByText("AI Summary Mode")).toBeInTheDocument();
		expect(screen.getByLabelText("Your Text to Summarize")).toBeInTheDocument();
		expect(screen.getByLabelText("Summary Style")).toBeInTheDocument();
		expect(screen.getByLabelText("Focus On")).toBeInTheDocument();
		expect(screen.getByRole("button", { name: /Generate Summary/i })).toBeInTheDocument();
	});

	it("should display character and word count correctly", () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, { target: { value: "Hello world test" } });

		expect(screen.getByText(/16 characters/)).toBeInTheDocument();
		expect(screen.getByText(/3 words/)).toBeInTheDocument();
	});

	it("should show clear button when text is entered", () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, { target: { value: "Test text" } });

		const clearButton = screen.getByRole("button", { name: /Clear/i });
		expect(clearButton).toBeInTheDocument();

		fireEvent.click(clearButton);
		expect(textarea).toHaveValue("");
	});

	it("should disable generate button when input is empty", () => {
		render(<AISummaryMode />);

		const generateButton = screen.getByRole("button", { name: /Generate Summary/i });
		expect(generateButton).toBeDisabled();
	});

	it("should enable generate button when input has text", () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		const generateButton = screen.getByRole("button", { name: /Generate Summary/i });

		fireEvent.change(textarea, { target: { value: "Some text to summarize" } });

		expect(generateButton).not.toBeDisabled();
	});

	it("should generate a summary when button is clicked", async () => {
		const { toast } = await import("sonner");

		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, {
			target: {
				value:
					"Artificial intelligence is the simulation of human intelligence processes by machines. Machine learning is a subset of artificial intelligence. Deep learning is a subset of machine learning.",
			},
		});

		const generateButton = screen.getByRole("button", { name: /Generate Summary/i });
		fireEvent.click(generateButton);

		// Should show loading state
		expect(screen.getByText(/Generating Summary/i)).toBeInTheDocument();

		// Wait for summary to be generated
		await waitFor(
			() => {
				expect(screen.getByText("Generated Summary")).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		expect(toast.success).toHaveBeenCalledWith("Summary generated successfully!");
	});

	it("should display summary statistics after generation", async () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, {
			target: { value: "Machine learning is a method of data analysis that automates analytical model building." },
		});

		const generateButton = screen.getByRole("button", { name: /Generate Summary/i });
		fireEvent.click(generateButton);

		await waitFor(
			() => {
				expect(screen.getByText(/Summary Statistics:/)).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		expect(screen.getByText(/Original word count:/)).toBeInTheDocument();
		expect(screen.getByText(/Summary reduction:/)).toBeInTheDocument();
		expect(screen.getByText(/Key terms identified:/)).toBeInTheDocument();
	});

	it("should allow copying summary to clipboard", async () => {
		// Mock clipboard API
		Object.assign(navigator, {
			clipboard: {
				writeText: vi.fn(),
			},
		});

		const { toast } = await import("sonner");

		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, { target: { value: "Test content for summary generation and testing clipboard functionality." } });

		const generateButton = screen.getByRole("button", { name: /Generate Summary/i });
		fireEvent.click(generateButton);

		await waitFor(
			() => {
				expect(screen.getByText("Generated Summary")).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		const copyButton = screen.getByRole("button", { name: /Copy/i });
		fireEvent.click(copyButton);

		expect(navigator.clipboard.writeText).toHaveBeenCalled();
		expect(toast.success).toHaveBeenCalledWith("Summary copied to clipboard!");
	});

	it("should show history section when multiple summaries are generated", async () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");

		// Generate first summary
		fireEvent.change(textarea, { target: { value: "First test content for summary." } });
		fireEvent.click(screen.getByRole("button", { name: /Generate Summary/i }));

		await waitFor(
			() => {
				expect(screen.getByText("Generated Summary")).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		// Clear and generate second summary
		fireEvent.change(textarea, { target: { value: "Second test content for another summary." } });
		fireEvent.click(screen.getByRole("button", { name: /Generate Summary/i }));

		await waitFor(
			() => {
				expect(screen.getByText(/Summary History \(2\)/)).toBeInTheDocument();
			},
			{ timeout: 5000 }
		);
	});

	it("should allow clearing all summaries", async () => {
		const { toast } = await import("sonner");

		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");

		// Generate two summaries
		fireEvent.change(textarea, { target: { value: "First summary content." } });
		fireEvent.click(screen.getByRole("button", { name: /Generate Summary/i }));

		await waitFor(
			() => {
				expect(screen.getByText("Generated Summary")).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		fireEvent.change(textarea, { target: { value: "Second summary content." } });
		fireEvent.click(screen.getByRole("button", { name: /Generate Summary/i }));

		await waitFor(
			() => {
				expect(screen.getByText(/Summary History/)).toBeInTheDocument();
			},
			{ timeout: 5000 }
		);

		// Clear all summaries
		const clearAllButton = screen.getByRole("button", { name: /Clear All/i });
		fireEvent.click(clearAllButton);

		expect(toast.success).toHaveBeenCalledWith("All summaries cleared");
		expect(screen.queryByText(/Summary History/)).not.toBeInTheDocument();
		expect(screen.queryByText("Generated Summary")).not.toBeInTheDocument();
	});

	it("should change summary style via select dropdown", () => {
		render(<AISummaryMode />);

		const styleSelect = screen.getByLabelText("Summary Style");
		expect(styleSelect).toBeInTheDocument();

		// Verify the select is interactable
		fireEvent.click(styleSelect);
	});

	it("should change focus type via select dropdown", () => {
		render(<AISummaryMode />);

		const focusSelect = screen.getByLabelText("Focus On");
		expect(focusSelect).toBeInTheDocument();

		// Verify the select is interactable
		fireEvent.click(focusSelect);
	});

	it("should extract important terms from text", async () => {
		render(<AISummaryMode />);

		const textarea = screen.getByLabelText("Your Text to Summarize");
		fireEvent.change(textarea, {
			target: {
				value:
					"Photosynthesis is the process by which plants convert light energy into chemical energy. Chlorophyll is essential for photosynthesis. Plants use photosynthesis to produce glucose.",
			},
		});

		fireEvent.click(screen.getByRole("button", { name: /Generate Summary/i }));

		await waitFor(
			() => {
				expect(screen.getByText(/Key terms identified:/)).toBeInTheDocument();
			},
			{ timeout: 3000 }
		);

		// The summary should contain the statistics
		const summaryText = screen.getByText(/Key terms identified:/).textContent;
		expect(summaryText).toBeTruthy();
	});
});
