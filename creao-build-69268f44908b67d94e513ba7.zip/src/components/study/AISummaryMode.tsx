import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Copy, Download, Trash2, FileText } from "lucide-react";
import { toast } from "sonner";
import { SummaryORM, SummaryStyle, SummaryFocus, type SummaryModel } from "@/components/data/orm/orm_summary";
import { APP_CONFIG } from "@/main";

type SummaryStyleKey = "concise" | "detailed" | "bullet-points" | "study-guide";
type SummaryFocusKey = "key-concepts" | "definitions" | "main-ideas" | "comprehensive";

// Map string keys to enum values
const styleToEnum: Record<SummaryStyleKey, SummaryStyle> = {
	"concise": SummaryStyle.Concise,
	"detailed": SummaryStyle.Detailed,
	"bullet-points": SummaryStyle.BulletPoints,
	"study-guide": SummaryStyle.StudyGuide,
};

const focusToEnum: Record<SummaryFocusKey, SummaryFocus> = {
	"key-concepts": SummaryFocus.KeyConcepts,
	"definitions": SummaryFocus.Definitions,
	"main-ideas": SummaryFocus.MainIdeas,
	"comprehensive": SummaryFocus.Comprehensive,
};

const enumToStyleKey: Record<SummaryStyle, SummaryStyleKey> = {
	[SummaryStyle.Unspecified]: "concise",
	[SummaryStyle.Concise]: "concise",
	[SummaryStyle.Detailed]: "detailed",
	[SummaryStyle.BulletPoints]: "bullet-points",
	[SummaryStyle.StudyGuide]: "study-guide",
};

const enumToFocusKey: Record<SummaryFocus, SummaryFocusKey> = {
	[SummaryFocus.Unspecified]: "key-concepts",
	[SummaryFocus.KeyConcepts]: "key-concepts",
	[SummaryFocus.Definitions]: "definitions",
	[SummaryFocus.MainIdeas]: "main-ideas",
	[SummaryFocus.Comprehensive]: "comprehensive",
};

export function AISummaryMode() {
	const [inputText, setInputText] = useState("");
	const [summaryStyle, setSummaryStyle] = useState<SummaryStyleKey>("concise");
	const [summaryFocus, setSummaryFocus] = useState<SummaryFocusKey>("key-concepts");
	const [isGenerating, setIsGenerating] = useState(false);
	const [generatedSummaries, setGeneratedSummaries] = useState<SummaryModel[]>([]);
	const [activeSummary, setActiveSummary] = useState<SummaryModel | null>(null);

	const userId = APP_CONFIG.userId || "demo-user";

	// Load saved summaries on mount
	useEffect(() => {
		const loadSummaries = async () => {
			try {
				const summaryOrm = SummaryORM.getInstance();
				const summaries = await summaryOrm.getSummaryByUserId(userId);
				setGeneratedSummaries(summaries);
				if (summaries.length > 0) {
					setActiveSummary(summaries[0]);
				}
			} catch (error) {
				console.error("Error loading summaries:", error);
			}
		};
		loadSummaries();
	}, [userId]);

	const generateSummary = async () => {
		if (!inputText.trim()) {
			toast.error("Please enter some text to summarize");
			return;
		}

		setIsGenerating(true);

		try {
			// Simulate AI processing with realistic delay
			await new Promise(resolve => setTimeout(resolve, 2000));

			// Generate a structured summary based on the input
			const summaryText = createStructuredSummary(inputText, summaryStyle, summaryFocus);

			// Save to database
			const summaryOrm = SummaryORM.getInstance();
			const newSummaryData: Partial<SummaryModel> = {
				user_id: userId,
				original_text: inputText,
				summary: summaryText,
				style: styleToEnum[summaryStyle],
				focus: focusToEnum[summaryFocus],
			};

			const [savedSummary] = await summaryOrm.insertSummary([newSummaryData as SummaryModel]);

			setGeneratedSummaries(prev => [savedSummary, ...prev]);
			setActiveSummary(savedSummary);
			toast.success("Summary generated and saved successfully!");
		} catch (error) {
			console.error("Error generating summary:", error);
			toast.error("Failed to generate summary");
		} finally {
			setIsGenerating(false);
		}
	};

	const createStructuredSummary = (text: string, style: SummaryStyleKey, focus: SummaryFocusKey): string => {
		// Extract key information from the text
		const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
		const words = text.toLowerCase().split(/\s+/);
		const wordCount = words.length;

		// Identify important terms (simplified approach)
		const importantTerms = extractImportantTerms(text);

		let summary = "";

		if (style === "bullet-points") {
			summary = generateBulletPoints(sentences, importantTerms, focus);
		} else if (style === "study-guide") {
			summary = generateStudyGuide(sentences, importantTerms, focus);
		} else if (style === "detailed") {
			summary = generateDetailedSummary(sentences, importantTerms, focus);
		} else {
			summary = generateConciseSummary(sentences, importantTerms, focus);
		}

		summary += `\n\n---\n**Summary Statistics:**\n- Original word count: ${wordCount}\n- Summary reduction: ${Math.round((1 - summary.split(/\s+/).length / wordCount) * 100)}%\n- Key terms identified: ${importantTerms.length}`;

		return summary;
	};

	const extractImportantTerms = (text: string): string[] => {
		// Expanded stop words list
		const stopWords = new Set([
			'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'as',
			'is', 'was', 'are', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
			'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those', 'it', 'its',
			'their', 'there', 'they', 'them', 'what', 'when', 'where', 'who', 'which', 'how', 'why', 'all', 'each',
			'every', 'both', 'few', 'more', 'most', 'other', 'some', 'such', 'only', 'own', 'same', 'than', 'too',
			'very', 'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under',
			'again', 'once', 'here', 'when', 'where', 'many', 'much', 'made', 'make', 'well', 'also', 'around',
			'another', 'came', 'come', 'work', 'because', 'become', 'became', 'over', 'people', 'mean', 'talk',
			'feel', 'phrase', 'usually', 'refers', 'time', 'users', 'often', 'argue', 'believe', 'argue'
		]);

		const termScores = new Map<string, number>();

		// Extract capitalized words and proper nouns (likely important named entities)
		const properNouns = text.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b/g) || [];
		properNouns.forEach(noun => {
			const lower = noun.toLowerCase();
			if (!stopWords.has(lower)) {
				// Proper nouns get extra weight
				termScores.set(noun, (termScores.get(noun) || 0) + 3);
			}
		});

		// Extract quoted terms (often definitions or key concepts)
		const quotedTerms = text.match(/"([^"]+)"/g) || [];
		quotedTerms.forEach(quoted => {
			const term = quoted.replace(/"/g, '').trim();
			if (term.length > 3) {
				termScores.set(term, (termScores.get(term) || 0) + 4);
			}
		});

		// Extract multi-word phrases (2-3 words, likely compound concepts)
		const phrases = text.match(/\b[a-z]+(?:-[a-z]+)+\b/gi) || []; // hyphenated terms
		phrases.forEach(phrase => {
			const lower = phrase.toLowerCase();
			if (!stopWords.has(lower) && phrase.length > 5) {
				termScores.set(phrase, (termScores.get(phrase) || 0) + 2.5);
			}
		});

		// Look for 2-3 word technical phrases
		const words = text.split(/\s+/);
		for (let i = 0; i < words.length - 1; i++) {
			const twoWord = `${words[i]} ${words[i + 1]}`.toLowerCase().replace(/[^a-z\s-]/g, '');
			const twoWordParts = twoWord.split(/\s+/).filter(w => w.length > 2);

			if (twoWordParts.length === 2 && !twoWordParts.some(w => stopWords.has(w))) {
				termScores.set(twoWord.trim(), (termScores.get(twoWord.trim()) || 0) + 1.5);
			}

			// Three word phrases
			if (i < words.length - 2) {
				const threeWord = `${words[i]} ${words[i + 1]} ${words[i + 2]}`.toLowerCase().replace(/[^a-z\s-]/g, '');
				const threeWordParts = threeWord.split(/\s+/).filter(w => w.length > 2);

				if (threeWordParts.length === 3 && !threeWordParts.some(w => stopWords.has(w))) {
					termScores.set(threeWord.trim(), (termScores.get(threeWord.trim()) || 0) + 2);
				}
			}
		}

		// Extract individual meaningful words with frequency scoring
		const individualWords = text.toLowerCase().match(/\b[a-z]{5,}\b/g) || [];
		const wordFreq = new Map<string, number>();

		individualWords.forEach(word => {
			if (!stopWords.has(word)) {
				wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
			}
		});

		// Add words that appear 2+ times (but not too frequently - likely filler if >15%)
		const totalWords = individualWords.length;
		wordFreq.forEach((freq, word) => {
			const percentage = freq / totalWords;
			if (freq >= 2 && percentage < 0.15) {
				// Score based on frequency but penalize over-used words
				const score = freq * (1 - percentage);
				termScores.set(word, (termScores.get(word) || 0) + score);
			}
		});

		// Boost terms that appear in questions (Q: or Q&A context)
		const questionPattern = /[Qq](?::|\?)\s*([^?.\n]+)/g;
		let questionMatch;
		while ((questionMatch = questionPattern.exec(text)) !== null) {
			const questionText = questionMatch[1];
			const questionWords = questionText.toLowerCase().match(/\b[a-z]{5,}\b/g) || [];
			questionWords.forEach(word => {
				if (!stopWords.has(word)) {
					termScores.set(word, (termScores.get(word) || 0) + 2);
				}
			});
		}

		// Sort by score and return top terms
		return Array.from(termScores.entries())
			.sort((a, b) => b[1] - a[1])
			.slice(0, 15)
			.map(([term]) => term);
	};

	const generateBulletPoints = (sentences: string[], terms: string[], focus: SummaryFocusKey): string => {
		const numPoints = Math.min(sentences.length, focus === "comprehensive" ? 8 : 5);
		let points = "## Key Points\n\n";

		for (let i = 0; i < numPoints && i < sentences.length; i++) {
			const sentence = sentences[i].trim();
			if (sentence) {
				points += `• ${sentence}\n\n`;
			}
		}

		if (focus === "definitions" || focus === "key-concepts") {
			points += "\n## Important Terms\n\n";
			terms.slice(0, 5).forEach(term => {
				points += `• **${term.charAt(0).toUpperCase() + term.slice(1)}**\n`;
			});
		}

		return points;
	};

	const generateStudyGuide = (sentences: string[], terms: string[], focus: SummaryFocusKey): string => {
		let guide = "# Study Guide\n\n";

		guide += "## Overview\n";
		guide += sentences.slice(0, 2).map(s => s.trim()).filter(s => s).join(". ") + ".\n\n";

		guide += "## Key Concepts\n\n";
		const conceptCount = focus === "comprehensive" ? 6 : 4;
		terms.slice(0, conceptCount).forEach((term, idx) => {
			guide += `${idx + 1}. **${term.charAt(0).toUpperCase() + term.slice(1)}**: `;
			const relevantSentence = sentences.find(s => s.toLowerCase().includes(term));
			guide += relevantSentence ? relevantSentence.trim() : "Important concept to review";
			guide += "\n\n";
		});

		guide += "## Review Questions\n\n";
		guide += `1. What are the main ideas discussed in this material?\n`;
		guide += `2. How do the key concepts relate to each other?\n`;
		guide += `3. What are the practical applications of these concepts?\n`;

		return guide;
	};

	const generateDetailedSummary = (sentences: string[], terms: string[], focus: SummaryFocusKey): string => {
		let summary = "## Detailed Summary\n\n";

		const sentenceCount = focus === "comprehensive" ? sentences.length : Math.min(sentences.length, 6);

		summary += "### Main Content\n\n";
		for (let i = 0; i < sentenceCount && i < sentences.length; i++) {
			const sentence = sentences[i].trim();
			if (sentence) {
				summary += `${sentence}. `;
			}
		}

		summary += "\n\n### Important Definitions\n\n";
		terms.slice(0, 5).forEach(term => {
			summary += `**${term.charAt(0).toUpperCase() + term.slice(1)}**: Key term that appears frequently in the source material.\n\n`;
		});

		return summary;
	};

	const generateConciseSummary = (sentences: string[], terms: string[], focus: SummaryFocusKey): string => {
		const summaryLength = focus === "main-ideas" ? 3 : 2;
		const mainSentences = sentences.slice(0, summaryLength).map(s => s.trim()).filter(s => s);

		let summary = "## Summary\n\n";
		summary += mainSentences.join(". ") + ".";

		if (focus === "key-concepts") {
			summary += "\n\n**Key terms:** " + terms.slice(0, 5).join(", ");
		}

		return summary;
	};

	const copySummary = (summary: string) => {
		navigator.clipboard.writeText(summary);
		toast.success("Summary copied to clipboard!");
	};

	const downloadSummary = (summaryModel: SummaryModel) => {
		const styleKey = enumToStyleKey[summaryModel.style];
		const focusKey = enumToFocusKey[summaryModel.focus];
		const timestamp = new Date(parseInt(summaryModel.create_time) * 1000);

		const content = `# AI Generated Summary\n\nGenerated: ${timestamp.toLocaleString()}\nStyle: ${styleKey}\nFocus: ${focusKey}\n\n${summaryModel.summary}`;
		const blob = new Blob([content], { type: "text/markdown" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `summary-${summaryModel.create_time}.md`;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
		toast.success("Summary downloaded!");
	};

	const clearSummaries = async () => {
		try {
			const summaryOrm = SummaryORM.getInstance();
			await summaryOrm.deleteSummaryByUserId(userId);
			setGeneratedSummaries([]);
			setActiveSummary(null);
			toast.success("All summaries cleared");
		} catch (error) {
			console.error("Error clearing summaries:", error);
			toast.error("Failed to clear summaries");
		}
	};

	return (
		<div className="space-y-6 animate-fade-in">
			<Card className="shadow-xl border-2 border-purple-200 dark:border-purple-800 bg-gradient-to-br from-white via-purple-50 to-white dark:from-gray-900 dark:via-purple-950 dark:to-gray-900">
				<CardHeader>
					<CardTitle className="flex items-center gap-3 text-2xl font-bold">
						<div className="p-2 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg shadow-lg">
							<Sparkles className="h-6 w-6 text-white" />
						</div>
						AI Summary Mode
					</CardTitle>
					<CardDescription className="text-base mt-2">
						Transform large, overwhelming texts into clear, structured summaries. Paste your notes, articles, or research papers and get organized, accurate summaries focused on what matters.
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					{/* Input Section */}
					<div className="space-y-2">
						<Label htmlFor="input-text" className="text-base font-medium">
							Your Text to Summarize
						</Label>
						<Textarea
							id="input-text"
							placeholder="Paste your notes, article, textbook chapter, or research paper here... The AI will identify key concepts, definitions, and important ideas while removing filler content."
							value={inputText}
							onChange={(e) => setInputText(e.target.value)}
							className="min-h-[200px] resize-y"
							disabled={isGenerating}
						/>
						<div className="flex items-center justify-between text-xs text-gray-500">
							<span>{inputText.length} characters • {inputText.split(/\s+/).filter(w => w).length} words</span>
							{inputText.length > 0 && (
								<Button
									variant="ghost"
									size="sm"
									onClick={() => setInputText("")}
									className="h-auto p-0 text-xs"
								>
									Clear
								</Button>
							)}
						</div>
					</div>

					{/* Configuration */}
					<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div className="space-y-2">
							<Label htmlFor="summary-style" className="text-base font-medium">
								Summary Style
							</Label>
							<Select
								value={summaryStyle}
								onValueChange={(value) => setSummaryStyle(value as SummaryStyleKey)}
								disabled={isGenerating}
							>
								<SelectTrigger id="summary-style">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="concise">Concise - Quick overview</SelectItem>
									<SelectItem value="detailed">Detailed - Comprehensive</SelectItem>
									<SelectItem value="bullet-points">Bullet Points - Easy to scan</SelectItem>
									<SelectItem value="study-guide">Study Guide - Exam prep</SelectItem>
								</SelectContent>
							</Select>
						</div>

						<div className="space-y-2">
							<Label htmlFor="summary-focus" className="text-base font-medium">
								Focus On
							</Label>
							<Select
								value={summaryFocus}
								onValueChange={(value) => setSummaryFocus(value as SummaryFocusKey)}
								disabled={isGenerating}
							>
								<SelectTrigger id="summary-focus">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="key-concepts">Key Concepts</SelectItem>
									<SelectItem value="definitions">Definitions</SelectItem>
									<SelectItem value="main-ideas">Main Ideas</SelectItem>
									<SelectItem value="comprehensive">Comprehensive</SelectItem>
								</SelectContent>
							</Select>
						</div>
					</div>

					{/* Generate Button */}
					<Button
						onClick={generateSummary}
						disabled={isGenerating || !inputText.trim()}
						className="w-full bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:via-indigo-700 hover:to-purple-800 shadow-xl hover:shadow-2xl transition-all duration-300 text-lg font-semibold"
						size="lg"
					>
						{isGenerating ? (
							<>
								<Sparkles className="h-6 w-6 mr-2 animate-spin" />
								Generating Summary...
							</>
						) : (
							<>
								<Sparkles className="h-6 w-6 mr-2" />
								Generate Summary
							</>
						)}
					</Button>
				</CardContent>
			</Card>

			{/* Generated Summary Display */}
			{activeSummary && (
				<Card>
					<CardHeader>
						<div className="flex items-center justify-between">
							<CardTitle className="flex items-center gap-2">
								<FileText className="h-5 w-5 text-indigo-600" />
								Generated Summary
							</CardTitle>
							<div className="flex gap-2">
								<Button
									variant="outline"
									size="sm"
									onClick={() => copySummary(activeSummary.summary)}
								>
									<Copy className="h-4 w-4 mr-1" />
									Copy
								</Button>
								<Button
									variant="outline"
									size="sm"
									onClick={() => downloadSummary(activeSummary)}
								>
									<Download className="h-4 w-4 mr-1" />
									Download
								</Button>
							</div>
						</div>
						<CardDescription>
							Style: {enumToStyleKey[activeSummary.style]} • Focus: {enumToFocusKey[activeSummary.focus]} • Generated {new Date(parseInt(activeSummary.create_time) * 1000).toLocaleTimeString()}
						</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="prose prose-sm max-w-none dark:prose-invert">
							<div className="whitespace-pre-wrap bg-gray-50 dark:bg-gray-900 p-4 rounded-lg border">
								{activeSummary.summary}
							</div>
						</div>
					</CardContent>
				</Card>
			)}

			{/* History */}
			{generatedSummaries.length > 1 && (
				<Card>
					<CardHeader>
						<div className="flex items-center justify-between">
							<CardTitle>Summary History ({generatedSummaries.length})</CardTitle>
							<Button
								variant="outline"
								size="sm"
								onClick={clearSummaries}
							>
								<Trash2 className="h-4 w-4 mr-1" />
								Clear All
							</Button>
						</div>
					</CardHeader>
					<CardContent>
						<div className="space-y-2">
							{generatedSummaries.map((summary) => {
								const timestamp = new Date(parseInt(summary.create_time) * 1000);
								const styleKey = enumToStyleKey[summary.style];
								const focusKey = enumToFocusKey[summary.focus];

								return (
									<Button
										key={summary.id}
										variant={activeSummary?.id === summary.id ? "default" : "outline"}
										className="w-full justify-start h-auto py-3"
										onClick={() => setActiveSummary(summary)}
									>
										<div className="flex flex-col items-start gap-1">
											<div className="font-medium">
												{styleKey} • {focusKey}
											</div>
											<div className="text-xs opacity-70">
												{timestamp.toLocaleString()} • {summary.original_text.slice(0, 50)}...
											</div>
										</div>
									</Button>
								);
							})}
						</div>
					</CardContent>
				</Card>
			)}
		</div>
	);
}
