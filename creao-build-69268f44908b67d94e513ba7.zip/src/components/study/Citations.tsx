import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { BookMarked, Copy, Download, Trash2, Plus, Quote, FileText } from "lucide-react";
import { toast } from "sonner";

type CitationStyle = "apa" | "mla" | "chicago" | "harvard";
type SourceType = "book" | "article" | "website" | "journal";

interface Citation {
	id: string;
	title: string;
	author: string;
	year: string;
	sourceType: SourceType;
	publisher?: string;
	url?: string;
	pages?: string;
	journal?: string;
	volume?: string;
	issue?: string;
	accessDate?: string;
	notes?: string;
	formattedCitation: {
		apa: string;
		mla: string;
		chicago: string;
		harvard: string;
	};
	createdAt: Date;
}

export function Citations() {
	const [citations, setCitations] = useState<Citation[]>([]);
	const [isAdding, setIsAdding] = useState(false);
	const [selectedStyle, setSelectedStyle] = useState<CitationStyle>("apa");

	// Form state
	const [title, setTitle] = useState("");
	const [author, setAuthor] = useState("");
	const [year, setYear] = useState("");
	const [sourceType, setSourceType] = useState<SourceType>("book");
	const [publisher, setPublisher] = useState("");
	const [url, setUrl] = useState("");
	const [pages, setPages] = useState("");
	const [journal, setJournal] = useState("");
	const [volume, setVolume] = useState("");
	const [issue, setIssue] = useState("");
	const [accessDate, setAccessDate] = useState("");
	const [notes, setNotes] = useState("");

	// Load citations from localStorage
	useEffect(() => {
		const saved = localStorage.getItem("cheatex-citations");
		if (saved) {
			try {
				const parsed = JSON.parse(saved);
				setCitations(parsed.map((c: Citation) => ({ ...c, createdAt: new Date(c.createdAt) })));
			} catch (error) {
				console.error("Error loading citations:", error);
			}
		}
	}, []);

	// Save citations to localStorage
	useEffect(() => {
		if (citations.length > 0) {
			localStorage.setItem("cheatex-citations", JSON.stringify(citations));
		}
	}, [citations]);

	const generateCitations = (data: Omit<Citation, "id" | "formattedCitation" | "createdAt">): Citation["formattedCitation"] => {
		const { title, author, year, sourceType, publisher, url, pages, journal, volume, issue, accessDate } = data;

		// APA Format
		let apa = "";
		if (sourceType === "book") {
			apa = `${author} (${year}). ${title}. ${publisher}.`;
		} else if (sourceType === "article" || sourceType === "journal") {
			apa = `${author} (${year}). ${title}. ${journal}${volume ? `, ${volume}` : ""}${issue ? `(${issue})` : ""}${pages ? `, ${pages}` : ""}.`;
		} else if (sourceType === "website") {
			apa = `${author} (${year}). ${title}. Retrieved ${accessDate || "date"}, from ${url}`;
		}

		// MLA Format
		let mla = "";
		if (sourceType === "book") {
			mla = `${author}. ${title}. ${publisher}, ${year}.`;
		} else if (sourceType === "article" || sourceType === "journal") {
			mla = `${author}. "${title}." ${journal}${volume ? ` ${volume}` : ""}${issue ? `.${issue}` : ""} (${year})${pages ? `: ${pages}` : ""}.`;
		} else if (sourceType === "website") {
			mla = `${author}. "${title}." ${publisher || "Web"}, ${year}. ${url}. Accessed ${accessDate || "date"}.`;
		}

		// Chicago Format
		let chicago = "";
		if (sourceType === "book") {
			chicago = `${author}. ${title}. ${publisher}, ${year}.`;
		} else if (sourceType === "article" || sourceType === "journal") {
			chicago = `${author}. "${title}." ${journal} ${volume}${issue ? `, no. ${issue}` : ""} (${year})${pages ? `: ${pages}` : ""}.`;
		} else if (sourceType === "website") {
			chicago = `${author}. "${title}." Accessed ${accessDate || "date"}. ${url}.`;
		}

		// Harvard Format
		let harvard = "";
		if (sourceType === "book") {
			harvard = `${author} (${year}) ${title}. ${publisher}.`;
		} else if (sourceType === "article" || sourceType === "journal") {
			harvard = `${author} (${year}) '${title}', ${journal}${volume ? `, ${volume}` : ""}${issue ? `(${issue})` : ""}${pages ? `, pp. ${pages}` : ""}.`;
		} else if (sourceType === "website") {
			harvard = `${author} (${year}) ${title}, available at: ${url} (Accessed: ${accessDate || "date"}).`;
		}

		return { apa, mla, chicago, harvard };
	};

	const addCitation = () => {
		if (!title.trim() || !author.trim() || !year.trim()) {
			toast.error("Please fill in title, author, and year");
			return;
		}

		const formattedCitation = generateCitations({
			title,
			author,
			year,
			sourceType,
			publisher,
			url,
			pages,
			journal,
			volume,
			issue,
			accessDate,
			notes,
		});

		const newCitation: Citation = {
			id: Date.now().toString(),
			title,
			author,
			year,
			sourceType,
			publisher,
			url,
			pages,
			journal,
			volume,
			issue,
			accessDate,
			notes,
			formattedCitation,
			createdAt: new Date(),
		};

		setCitations([newCitation, ...citations]);

		// Reset form
		setTitle("");
		setAuthor("");
		setYear("");
		setPublisher("");
		setUrl("");
		setPages("");
		setJournal("");
		setVolume("");
		setIssue("");
		setAccessDate("");
		setNotes("");
		setIsAdding(false);

		toast.success("Citation added successfully!");
	};

	const deleteCitation = (id: string) => {
		setCitations(citations.filter(c => c.id !== id));
		toast.success("Citation deleted");
	};

	const copyCitation = (citation: string) => {
		navigator.clipboard.writeText(citation);
		toast.success("Citation copied to clipboard!");
	};

	const downloadBibliography = () => {
		const bibliography = citations.map((c, index) => {
			return `${index + 1}. ${c.formattedCitation[selectedStyle]}\n`;
		}).join("\n");

		const blob = new Blob([`Bibliography (${selectedStyle.toUpperCase()})\n\n${bibliography}`], { type: "text/plain" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `bibliography-${selectedStyle}.txt`;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
		toast.success("Bibliography downloaded!");
	};

	const clearAll = () => {
		if (confirm("Are you sure you want to delete all citations?")) {
			setCitations([]);
			localStorage.removeItem("cheatex-citations");
			toast.success("All citations cleared");
		}
	};

	return (
		<div className="space-y-6 animate-fade-in">
			<Card className="shadow-xl border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-white via-blue-50 to-white dark:from-gray-900 dark:via-blue-950 dark:to-gray-900">
				<CardHeader>
					<CardTitle className="flex items-center gap-3 text-2xl font-bold">
						<div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg shadow-lg">
							<BookMarked className="h-6 w-6 text-white" />
						</div>
						Citation Manager
					</CardTitle>
					<CardDescription className="text-base mt-2">
						Organize your research sources and automatically generate citations in multiple formats (APA, MLA, Chicago, Harvard). Never lose track of your sources again.
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					<div className="flex items-center justify-between">
						<Button
							onClick={() => setIsAdding(!isAdding)}
							className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
						>
							<Plus className="h-5 w-5 mr-2" />
							{isAdding ? "Cancel" : "Add New Citation"}
						</Button>

						{citations.length > 0 && (
							<div className="flex gap-2">
								<Label htmlFor="citation-style" className="sr-only">Citation Style</Label>
								<Select value={selectedStyle} onValueChange={(value) => setSelectedStyle(value as CitationStyle)}>
									<SelectTrigger id="citation-style" className="w-32">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="apa">APA</SelectItem>
										<SelectItem value="mla">MLA</SelectItem>
										<SelectItem value="chicago">Chicago</SelectItem>
										<SelectItem value="harvard">Harvard</SelectItem>
									</SelectContent>
								</Select>
								<Button variant="outline" onClick={downloadBibliography}>
									<Download className="h-4 w-4 mr-2" />
									Export
								</Button>
								<Button variant="outline" onClick={clearAll}>
									<Trash2 className="h-4 w-4 mr-2" />
									Clear All
								</Button>
							</div>
						)}
					</div>

					{/* Add Citation Form */}
					{isAdding && (
						<Card className="border-2 border-blue-300 dark:border-blue-700">
							<CardHeader>
								<CardTitle className="text-lg">New Citation</CardTitle>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
									<div className="space-y-2">
										<Label htmlFor="source-type">Source Type</Label>
										<Select value={sourceType} onValueChange={(value) => setSourceType(value as SourceType)}>
											<SelectTrigger id="source-type">
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="book">Book</SelectItem>
												<SelectItem value="article">Article</SelectItem>
												<SelectItem value="journal">Journal</SelectItem>
												<SelectItem value="website">Website</SelectItem>
											</SelectContent>
										</Select>
									</div>
									<div className="space-y-2">
										<Label htmlFor="year">Year</Label>
										<Input
											id="year"
											placeholder="2024"
											value={year}
											onChange={(e) => setYear(e.target.value)}
										/>
									</div>
								</div>

								<div className="space-y-2">
									<Label htmlFor="title">Title *</Label>
									<Input
										id="title"
										placeholder="Enter the title"
										value={title}
										onChange={(e) => setTitle(e.target.value)}
									/>
								</div>

								<div className="space-y-2">
									<Label htmlFor="author">Author(s) *</Label>
									<Input
										id="author"
										placeholder="Last Name, First Name"
										value={author}
										onChange={(e) => setAuthor(e.target.value)}
									/>
								</div>

								{(sourceType === "book" || sourceType === "article") && (
									<div className="space-y-2">
										<Label htmlFor="publisher">Publisher</Label>
										<Input
											id="publisher"
											placeholder="Publisher name"
											value={publisher}
											onChange={(e) => setPublisher(e.target.value)}
										/>
									</div>
								)}

								{(sourceType === "article" || sourceType === "journal") && (
									<>
										<div className="space-y-2">
											<Label htmlFor="journal">Journal Name</Label>
											<Input
												id="journal"
												placeholder="Journal name"
												value={journal}
												onChange={(e) => setJournal(e.target.value)}
											/>
										</div>
										<div className="grid grid-cols-3 gap-4">
											<div className="space-y-2">
												<Label htmlFor="volume">Volume</Label>
												<Input
													id="volume"
													placeholder="12"
													value={volume}
													onChange={(e) => setVolume(e.target.value)}
												/>
											</div>
											<div className="space-y-2">
												<Label htmlFor="issue">Issue</Label>
												<Input
													id="issue"
													placeholder="3"
													value={issue}
													onChange={(e) => setIssue(e.target.value)}
												/>
											</div>
											<div className="space-y-2">
												<Label htmlFor="pages">Pages</Label>
												<Input
													id="pages"
													placeholder="12-25"
													value={pages}
													onChange={(e) => setPages(e.target.value)}
												/>
											</div>
										</div>
									</>
								)}

								{sourceType === "website" && (
									<>
										<div className="space-y-2">
											<Label htmlFor="url">URL</Label>
											<Input
												id="url"
												placeholder="https://example.com"
												value={url}
												onChange={(e) => setUrl(e.target.value)}
											/>
										</div>
										<div className="space-y-2">
											<Label htmlFor="access-date">Access Date</Label>
											<Input
												id="access-date"
												type="date"
												value={accessDate}
												onChange={(e) => setAccessDate(e.target.value)}
											/>
										</div>
									</>
								)}

								<div className="space-y-2">
									<Label htmlFor="notes">Notes (optional)</Label>
									<Textarea
										id="notes"
										placeholder="Add any notes about this source..."
										value={notes}
										onChange={(e) => setNotes(e.target.value)}
										rows={2}
									/>
								</div>

								<Button onClick={addCitation} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600">
									<Plus className="h-5 w-5 mr-2" />
									Add Citation
								</Button>
							</CardContent>
						</Card>
					)}
				</CardContent>
			</Card>

			{/* Citations List */}
			{citations.length > 0 && (
				<Card>
					<CardHeader>
						<div className="flex items-center justify-between">
							<div>
								<CardTitle className="flex items-center gap-2">
									<FileText className="h-5 w-5 text-blue-600" />
									Your Citations ({citations.length})
								</CardTitle>
								<CardDescription>
									Viewing in {selectedStyle.toUpperCase()} format
								</CardDescription>
							</div>
						</div>
					</CardHeader>
					<CardContent>
						<div className="space-y-3">
							{citations.map((citation) => (
								<Card key={citation.id} className="border-2 hover:border-blue-300 transition-colors">
									<CardContent className="pt-4">
										<div className="flex items-start justify-between gap-4">
											<div className="flex-1 space-y-2">
												<div className="flex items-center gap-2 flex-wrap">
													<Badge variant="outline" className="font-mono text-xs">
														{citation.sourceType.toUpperCase()}
													</Badge>
													<Badge variant="secondary" className="text-xs">
														{citation.year}
													</Badge>
													<span className="text-xs text-gray-500">
														Added {citation.createdAt.toLocaleDateString()}
													</span>
												</div>

												<div className="font-medium text-lg">{citation.title}</div>
												<div className="text-sm text-gray-600">{citation.author}</div>

												<div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg border">
													<div className="flex items-start gap-2">
														<Quote className="h-4 w-4 text-gray-400 mt-1 flex-shrink-0" />
														<p className="text-sm font-mono leading-relaxed">
															{citation.formattedCitation[selectedStyle]}
														</p>
													</div>
												</div>

												{citation.notes && (
													<div className="text-sm text-gray-600 italic">
														Note: {citation.notes}
													</div>
												)}
											</div>

											<div className="flex flex-col gap-2">
												<Button
													variant="outline"
													size="sm"
													onClick={() => copyCitation(citation.formattedCitation[selectedStyle])}
												>
													<Copy className="h-4 w-4" />
												</Button>
												<Button
													variant="ghost"
													size="sm"
													onClick={() => deleteCitation(citation.id)}
													className="text-red-600 hover:text-red-700"
												>
													<Trash2 className="h-4 w-4" />
												</Button>
											</div>
										</div>
									</CardContent>
								</Card>
							))}
						</div>
					</CardContent>
				</Card>
			)}

			{citations.length === 0 && !isAdding && (
				<Card className="border-dashed border-2">
					<CardContent className="py-12 text-center">
						<BookMarked className="h-12 w-12 text-gray-400 mx-auto mb-4" />
						<h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
							No citations yet
						</h3>
						<p className="text-gray-600 dark:text-gray-400 mb-4">
							Start building your bibliography by adding your first source
						</p>
						<Button onClick={() => setIsAdding(true)} variant="outline">
							<Plus className="h-5 w-5 mr-2" />
							Add Your First Citation
						</Button>
					</CardContent>
				</Card>
			)}
		</div>
	);
}
