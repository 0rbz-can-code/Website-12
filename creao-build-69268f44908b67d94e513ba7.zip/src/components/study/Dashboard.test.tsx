import { render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import "@testing-library/jest-dom";
import { Dashboard } from "./Dashboard";
import { FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";

// Mock the ORM modules
vi.mock("@/components/data/orm/orm_study_session", () => ({
	StudySessionORM: {
		getInstance: vi.fn(() => ({
			getStudySessionByUserId: vi.fn().mockResolvedValue([
				{
					id: "1",
					user_id: "demo-user",
					duration: 45,
					focus_mode: "Deep Focus",
					create_time: "1700000000",
					update_time: "1700000000",
				},
				{
					id: "2",
					user_id: "demo-user",
					duration: 30,
					focus_mode: "Standard",
					create_time: "1700100000",
					update_time: "1700100000",
				},
			]),
		})),
	},
}));

vi.mock("@/components/data/orm/orm_flashcard", () => ({
	FlashcardORM: {
		getInstance: vi.fn(() => ({
			getFlashcardByUserId: vi.fn().mockResolvedValue([
				{
					id: "1",
					user_id: "demo-user",
					front: "Question 1",
					back: "Answer 1",
					topic: "Math",
					mastery_level: "mastered",
					create_time: "1700000000",
					update_time: "1700000000",
				},
				{
					id: "2",
					user_id: "demo-user",
					front: "Question 2",
					back: "Answer 2",
					topic: "Science",
					mastery_level: "learning",
					create_time: "1700000000",
					update_time: "1700000000",
				},
				{
					id: "3",
					user_id: "demo-user",
					front: "Question 3",
					back: "Answer 3",
					topic: "History",
					mastery_level: "not_seen",
					create_time: "1700000000",
					update_time: "1700000000",
				},
			]),
		})),
	},
	FlashcardMasteryLevel: {
		Mastered: "mastered",
		Learning: "learning",
		NotSeen: "not_seen",
	},
}));

vi.mock("@/components/data/orm/orm_test", () => ({
	TestORM: {
		getInstance: vi.fn(() => ({
			getTestByUserId: vi.fn().mockResolvedValue([
				{
					id: "1",
					user_id: "demo-user",
					title: "Math Test",
					topic: "Algebra",
					score: 85,
					completed_at: "1700000000",
					create_time: "1700000000",
					update_time: "1700000000",
				},
				{
					id: "2",
					user_id: "demo-user",
					title: "Science Quiz",
					topic: "Biology",
					score: 92,
					completed_at: "1700100000",
					create_time: "1700100000",
					update_time: "1700100000",
				},
			]),
		})),
	},
}));

vi.mock("@/components/data/orm/orm_performance_metric", () => ({
	PerformanceMetricORM: {
		getInstance: vi.fn(() => ({
			getPerformanceMetricByUserId: vi.fn().mockResolvedValue([]),
		})),
	},
}));

vi.mock("@/main", () => ({
	APP_CONFIG: {
		userId: "demo-user",
	},
}));

describe("Dashboard", () => {
	const mockOnNavigate = vi.fn();

	beforeEach(() => {
		vi.clearAllMocks();
	});

	it("should render the dashboard with all stat cards", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("Total Study Time")).toBeInTheDocument();
			expect(screen.getByText("Flashcards")).toBeInTheDocument();
			expect(screen.getByText("Study Plans")).toBeInTheDocument();
			expect(screen.getByText("Average Score")).toBeInTheDocument();
		});
	});

	it("should display correct total study time", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			// 45 + 30 = 75 minutes = 1h 15m
			expect(screen.getByText("1h 15m")).toBeInTheDocument();
			expect(screen.getByText("2 sessions")).toBeInTheDocument();
		});
	});

	it("should display correct flashcard counts", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("3")).toBeInTheDocument(); // Total flashcards
			expect(screen.getByText("1 mastered")).toBeInTheDocument();
			expect(screen.getByText("1 learning")).toBeInTheDocument();
		});
	});

	it("should calculate average score correctly", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			// (85 + 92) / 2 = 88.5, rounded to 89
			expect(screen.getByText("89%")).toBeInTheDocument();
		});
	});

	it("should display learning progress section", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("Learning Progress")).toBeInTheDocument();
			expect(screen.getByText("Overall Mastery")).toBeInTheDocument();
		});
	});

	it("should display correct mastery breakdown", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			const newCardsElements = screen.getAllByText("1");
			const masteredCardsElements = screen.getAllByText("1");

			expect(newCardsElements.length).toBeGreaterThan(0);
			expect(masteredCardsElements.length).toBeGreaterThan(0);
		});
	});

	it("should render quick action buttons", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("Summarize Text")).toBeInTheDocument();
			expect(screen.getByText("Create Study Plan")).toBeInTheDocument();
			expect(screen.getByText("Practice Flashcards")).toBeInTheDocument();
		});
	});

	it("should call onNavigate when quick action buttons are clicked", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			const summarizeButton = screen.getByText("Summarize Text");
			summarizeButton.click();
			expect(mockOnNavigate).toHaveBeenCalledWith("ai-summary");
		});

		const createPlanButton = screen.getByText("Create Study Plan");
		createPlanButton.click();
		expect(mockOnNavigate).toHaveBeenCalledWith("study-plans");

		const practiceButton = screen.getByText("Practice Flashcards");
		practiceButton.click();
		expect(mockOnNavigate).toHaveBeenCalledWith("flashcards");
	});

	it("should display recent study sessions", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("Recent Study Sessions")).toBeInTheDocument();
			expect(screen.getByText("Deep Focus Mode")).toBeInTheDocument();
			expect(screen.getByText("Standard Mode")).toBeInTheDocument();
		});
	});

	it("should display recent tests", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("Recent Tests")).toBeInTheDocument();
			expect(screen.getByText("Math Test")).toBeInTheDocument();
			expect(screen.getByText("Science Quiz")).toBeInTheDocument();
			expect(screen.getByText("Algebra")).toBeInTheDocument();
			expect(screen.getByText("Biology")).toBeInTheDocument();
		});
	});

	it("should display test scores with correct badges", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("85%")).toBeInTheDocument();
			expect(screen.getByText("92%")).toBeInTheDocument();
		});
	});

	it("should handle empty data gracefully", async () => {
		// Override mocks to return empty arrays
		const { StudySessionORM } = await import("@/components/data/orm/orm_study_session");
		const { FlashcardORM } = await import("@/components/data/orm/orm_flashcard");
		const { TestORM } = await import("@/components/data/orm/orm_test");

		vi.mocked(StudySessionORM.getInstance).mockReturnValue({
			getStudySessionByUserId: vi.fn().mockResolvedValue([]),
		} as never);

		vi.mocked(FlashcardORM.getInstance).mockReturnValue({
			getFlashcardByUserId: vi.fn().mockResolvedValue([]),
		} as never);

		vi.mocked(TestORM.getInstance).mockReturnValue({
			getTestByUserId: vi.fn().mockResolvedValue([]),
		} as never);

		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			expect(screen.getByText("No study sessions yet")).toBeInTheDocument();
			expect(screen.getByText("No tests taken yet")).toBeInTheDocument();
		});
	});

	it("should display mastery progress", async () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(() => {
			// Should show overall mastery section
			expect(screen.getByText("Overall Mastery")).toBeInTheDocument();
			// Should have progress displayed (1 mastered out of 3 total)
			const progressElements = screen.getAllByText(/\d+%/);
			expect(progressElements.length).toBeGreaterThan(0);
		});
	});

	it("should handle loading state", () => {
		render(<Dashboard onNavigate={mockOnNavigate} />);

		// Component should render even in loading state
		expect(screen.getByText("Total Study Time")).toBeInTheDocument();
	});

	it("should handle errors gracefully", async () => {
		const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});

		const { StudySessionORM } = await import("@/components/data/orm/orm_study_session");
		const { FlashcardORM } = await import("@/components/data/orm/orm_flashcard");
		const { TestORM } = await import("@/components/data/orm/orm_test");
		const { PerformanceMetricORM } = await import("@/components/data/orm/orm_performance_metric");

		vi.mocked(StudySessionORM.getInstance).mockReturnValue({
			getStudySessionByUserId: vi.fn().mockRejectedValue(new Error("Database error")),
		} as never);

		vi.mocked(FlashcardORM.getInstance).mockReturnValue({
			getFlashcardByUserId: vi.fn().mockRejectedValue(new Error("Database error")),
		} as never);

		vi.mocked(TestORM.getInstance).mockReturnValue({
			getTestByUserId: vi.fn().mockRejectedValue(new Error("Database error")),
		} as never);

		vi.mocked(PerformanceMetricORM.getInstance).mockReturnValue({
			getPerformanceMetricByUserId: vi.fn().mockRejectedValue(new Error("Database error")),
		} as never);

		render(<Dashboard onNavigate={mockOnNavigate} />);

		await waitFor(
			() => {
				expect(consoleSpy).toHaveBeenCalled();
			},
			{ timeout: 3000 }
		);

		consoleSpy.mockRestore();
	});
});
