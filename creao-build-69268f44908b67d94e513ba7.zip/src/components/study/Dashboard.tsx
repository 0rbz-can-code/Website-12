import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Sparkles, CalendarDays, BookOpen, TrendingUp, Clock, Target, FileQuestion } from "lucide-react";
import { StudySessionORM, type StudySessionModel } from "@/components/data/orm/orm_study_session";
import { FlashcardORM, type FlashcardModel, FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";
import { TestORM, type TestModel } from "@/components/data/orm/orm_test";
import { PerformanceMetricORM, type PerformanceMetricModel } from "@/components/data/orm/orm_performance_metric";
import { APP_CONFIG } from "@/main";
import { playSound, SoundEffect } from "@/lib/sounds";

interface DashboardProps {
	onNavigate: (tab: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
	const [sessions, setSessions] = useState<StudySessionModel[]>([]);
	const [flashcards, setFlashcards] = useState<FlashcardModel[]>([]);
	const [tests, setTests] = useState<TestModel[]>([]);
	const [metrics, setMetrics] = useState<PerformanceMetricModel[]>([]);
	const [loading, setLoading] = useState(true);

	const userId = APP_CONFIG.userId || "demo-user";

	useEffect(() => {
		loadDashboardData();
	}, []);

	const loadDashboardData = async () => {
		try {
			setLoading(true);
			const sessionOrm = StudySessionORM.getInstance();
			const flashcardOrm = FlashcardORM.getInstance();
			const testOrm = TestORM.getInstance();
			const metricOrm = PerformanceMetricORM.getInstance();

			const [sessionsData, flashcardsData, testsData, metricsData] = await Promise.all([
				sessionOrm.getStudySessionByUserId(userId),
				flashcardOrm.getFlashcardByUserId(userId),
				testOrm.getTestByUserId(userId),
				metricOrm.getPerformanceMetricByUserId(userId),
			]);

			setSessions(sessionsData);
			setFlashcards(flashcardsData);
			setTests(testsData);
			setMetrics(metricsData);
		} catch (error) {
			console.error("Error loading dashboard data:", error);
		} finally {
			setLoading(false);
		}
	};

	const completedTests = tests.filter((t) => t.completed_at).length;
	const testsWithScores = tests.filter((t) => t.score !== null && t.completed_at);
	const averageScore =
		testsWithScores.length > 0
			? testsWithScores.reduce((acc, t) => acc + (t.score || 0), 0) / testsWithScores.length
			: 0;

	// Calculate score trend (improving, declining, stable)
	const getScoreTrend = (): { trend: 'improving' | 'declining' | 'stable'; color: string; bgColor: string; message: string } => {
		if (testsWithScores.length < 2) {
			return { trend: 'stable', color: 'text-gray-100', bgColor: 'from-gray-500 via-gray-600 to-gray-700', message: 'Not enough data' };
		}

		// Sort by completion time
		const sortedTests = [...testsWithScores].sort((a, b) => {
			const timeA = a.completed_at ? parseInt(a.completed_at) : 0;
			const timeB = b.completed_at ? parseInt(b.completed_at) : 0;
			return timeA - timeB;
		});

		// Split into two halves: earlier and recent
		const midpoint = Math.floor(sortedTests.length / 2);
		const earlierTests = sortedTests.slice(0, midpoint);
		const recentTests = sortedTests.slice(midpoint);

		const earlierAvg = earlierTests.reduce((acc, t) => acc + (t.score || 0), 0) / earlierTests.length;
		const recentAvg = recentTests.reduce((acc, t) => acc + (t.score || 0), 0) / recentTests.length;

		const difference = recentAvg - earlierAvg;

		// Use a 3% threshold to determine significant change
		if (difference > 3) {
			return {
				trend: 'improving',
				color: 'text-green-100',
				bgColor: 'from-green-500 via-green-600 to-green-700',
				message: `Up ${difference.toFixed(1)}% from earlier tests`
			};
		} else if (difference < -3) {
			return {
				trend: 'declining',
				color: 'text-red-100',
				bgColor: 'from-red-500 via-red-600 to-red-700',
				message: `Down ${Math.abs(difference).toFixed(1)}% from earlier tests`
			};
		} else {
			return {
				trend: 'stable',
				color: 'text-yellow-100',
				bgColor: 'from-yellow-500 via-yellow-600 to-yellow-700',
				message: 'Consistent performance'
			};
		}
	};

	const scoreTrend = getScoreTrend();

	const masteredCards = flashcards.filter((f) => f.mastery_level === FlashcardMasteryLevel.Mastered).length;
	const learningCards = flashcards.filter((f) => f.mastery_level === FlashcardMasteryLevel.Learning).length;
	const newCards = flashcards.filter((f) => f.mastery_level === FlashcardMasteryLevel.NotSeen).length;

	const cardProgress = flashcards.length > 0 ? (masteredCards / flashcards.length) * 100 : 0;

	const recentSessions = sessions.slice(-5).reverse();
	const recentTests = tests.slice(-3).reverse();

	return (
		<div className="space-y-6 animate-fade-in">
			{/* Stats Overview */}
			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
				<Card className="border-0 bg-gradient-to-br from-indigo-500 via-indigo-600 to-indigo-700 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-indigo-100 flex items-center gap-2">
							<Clock className="h-5 w-5" />
							Sessions Completed
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-4xl font-extrabold">
							{sessions.length}
						</div>
						<p className="text-xs text-indigo-200 mt-2">Study time sessions</p>
					</CardContent>
				</Card>

				<Card className="border-0 bg-gradient-to-br from-pink-500 via-pink-600 to-pink-700 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-pink-100 flex items-center gap-2">
							<CalendarDays className="h-5 w-5" />
							Active Plans
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-4xl font-extrabold">0</div>
						<p className="text-xs text-pink-200 mt-2">Study plans</p>
					</CardContent>
				</Card>

				<Card className="border-0 bg-gradient-to-br from-purple-500 via-purple-600 to-purple-700 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
					<CardHeader className="pb-2">
						<CardTitle className="text-sm font-medium text-purple-100 flex items-center gap-2">
							<BookOpen className="h-5 w-5" />
							Flashcards
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-4xl font-extrabold">{flashcards.length}</div>
						<div className="flex gap-2 mt-2">
							<Badge variant="secondary" className="text-xs bg-purple-400 text-white border-0">
								{masteredCards} mastered
							</Badge>
							<Badge variant="outline" className="text-xs bg-purple-800 text-white border-0">
								{learningCards} learning
							</Badge>
						</div>
					</CardContent>
				</Card>

				<Card className={`border-0 bg-gradient-to-br ${scoreTrend.bgColor} text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105`}>
					<CardHeader className="pb-2">
						<CardTitle className={`text-sm font-medium ${scoreTrend.color} flex items-center gap-2`}>
							<TrendingUp className="h-5 w-5" />
							Average Score
						</CardTitle>
					</CardHeader>
					<CardContent>
						<div className="text-4xl font-extrabold">{averageScore.toFixed(0)}%</div>
						<p className={`text-xs ${scoreTrend.color} mt-2`}>{scoreTrend.message}</p>
					</CardContent>
				</Card>
			</div>

			{/* Progress Section */}
			<Card>
				<CardHeader>
					<CardTitle className="flex items-center gap-2">
						<Target className="h-5 w-5 text-indigo-600" />
						Learning Progress
					</CardTitle>
					<CardDescription>Your mastery progress across all flashcards</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					<div>
						<div className="flex justify-between text-sm mb-2">
							<span className="font-medium">Overall Mastery</span>
							<span className="text-gray-600">{cardProgress.toFixed(0)}%</span>
						</div>
						<Progress value={cardProgress} className="h-3" />
					</div>
					<div className="grid grid-cols-3 gap-4 pt-2">
						<div className="text-center p-3 bg-gray-50 rounded-lg">
							<div className="text-2xl font-bold text-gray-600">{newCards}</div>
							<div className="text-xs text-gray-500 mt-1">New</div>
						</div>
						<div className="text-center p-3 bg-blue-50 rounded-lg">
							<div className="text-2xl font-bold text-blue-600">{learningCards}</div>
							<div className="text-xs text-gray-500 mt-1">Learning</div>
						</div>
						<div className="text-center p-3 bg-green-50 rounded-lg">
							<div className="text-2xl font-bold text-green-600">{masteredCards}</div>
							<div className="text-xs text-gray-500 mt-1">Mastered</div>
						</div>
					</div>
				</CardContent>
			</Card>

			{/* Quick Actions */}
			<Card className="shadow-lg border-2 border-gray-200 dark:border-gray-700">
				<CardHeader>
					<CardTitle className="text-2xl font-bold">Quick Actions</CardTitle>
					<CardDescription className="text-base">Jump into your study routine</CardDescription>
				</CardHeader>
				<CardContent>
					<div className="grid grid-cols-2 md:grid-cols-4 gap-4">
						<Button
							type="button"
							onClick={(e) => {
								e.preventDefault();
								playSound(SoundEffect.Click);
								onNavigate("ai-summary");
							}}
							className="h-28 flex flex-col gap-3 bg-gradient-to-br from-indigo-500 to-indigo-700 hover:from-indigo-600 hover:to-indigo-800 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-base font-semibold"
						>
							<Sparkles className="h-7 w-7" />
							<span>Summarize Text</span>
						</Button>
						<Button
							type="button"
							onClick={(e) => {
								e.preventDefault();
								playSound(SoundEffect.Click);
								onNavigate("study-plans");
							}}
							className="h-28 flex flex-col gap-3 bg-gradient-to-br from-purple-500 to-purple-700 hover:from-purple-600 hover:to-purple-800 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-base font-semibold"
						>
							<CalendarDays className="h-7 w-7" />
							<span>Create Study Plan</span>
						</Button>
						<Button
							type="button"
							onClick={(e) => {
								e.preventDefault();
								playSound(SoundEffect.Click);
								onNavigate("flashcards");
							}}
							className="h-28 flex flex-col gap-3 bg-gradient-to-br from-pink-500 to-pink-700 hover:from-pink-600 hover:to-pink-800 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-base font-semibold"
						>
							<BookOpen className="h-7 w-7" />
							<span>Practice Flashcards</span>
						</Button>
						<Button
							type="button"
							onClick={(e) => {
								e.preventDefault();
								playSound(SoundEffect.Click);
								onNavigate("quiz");
							}}
							className="h-28 flex flex-col gap-3 bg-gradient-to-br from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 text-base font-semibold"
						>
							<FileQuestion className="h-7 w-7" />
							<span>Take a Test</span>
						</Button>
					</div>
				</CardContent>
			</Card>

			{/* Recent Activity */}
			<div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
				<Card>
					<CardHeader>
						<CardTitle className="text-lg">Recent Study Sessions</CardTitle>
					</CardHeader>
					<CardContent>
						{recentSessions.length === 0 ? (
							<p className="text-gray-500 text-sm text-center py-8">No study sessions yet</p>
						) : (
							<div className="space-y-3">
								{recentSessions.map((session) => (
									<div
										key={session.id}
										className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
									>
										<div>
											<div className="font-medium text-sm">
												{session.focus_mode || "Standard"} Mode
											</div>
											<div className="text-xs text-gray-500">
												{new Date(parseInt(session.create_time) * 1000).toLocaleDateString()}
											</div>
										</div>
										<Badge variant="outline">{session.duration} min</Badge>
									</div>
								))}
							</div>
						)}
					</CardContent>
				</Card>

				<Card>
					<CardHeader>
						<CardTitle className="text-lg">Recent Tests</CardTitle>
					</CardHeader>
					<CardContent>
						{recentTests.length === 0 ? (
							<p className="text-gray-500 text-sm text-center py-8">No tests taken yet</p>
						) : (
							<div className="space-y-3">
								{recentTests.map((test) => (
									<div
										key={test.id}
										className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
									>
										<div>
											<div className="font-medium text-sm">{test.title}</div>
											<div className="text-xs text-gray-500">{test.topic}</div>
										</div>
										{test.score !== null && test.score !== undefined && (
											<Badge
												className={
													test.score >= 80
														? "bg-green-100 text-green-700"
														: test.score >= 60
															? "bg-yellow-100 text-yellow-700"
															: "bg-red-100 text-red-700"
												}
											>
												{test.score}%
											</Badge>
										)}
									</div>
								))}
							</div>
						)}
					</CardContent>
				</Card>
			</div>
		</div>
	);
}
