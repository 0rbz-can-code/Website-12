import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Sparkles, BookOpen } from "lucide-react";
import { FlashcardORM, type FlashcardModel, FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";
import { SummaryORM, SummaryStyle, SummaryFocus } from "@/components/data/orm/orm_summary";
import { APP_CONFIG } from "@/main";
import { toast } from "sonner";

interface FlashcardCreateProps {
	onViewSets: () => void;
}

type SummaryStyleKey = "concise" | "detailed" | "bullet-points" | "study-guide";
type SummaryFocusKey = "key-concepts" | "definitions" | "main-ideas" | "comprehensive";

// Map string keys to enum values
const styleToEnum: Record<SummaryStyleKey, SummaryStyle> = {
	"concise": SummaryStyle.Concise,
	"detailed": SummaryStyle.Detailed,
	"bullet-points": SummaryStyle.BulletPoints,
	"study-guide": SummaryStyle.StudyGuide,
};

const focusToEnum: Record<SummaryFocusKey, SummaryFocus> = {
	"key-concepts": SummaryFocus.KeyConcepts,
	"definitions": SummaryFocus.Definitions,
	"main-ideas": SummaryFocus.MainIdeas,
	"comprehensive": SummaryFocus.Comprehensive,
};

export function FlashcardCreate({ onViewSets }: FlashcardCreateProps) {
	const [inputText, setInputText] = useState("");
	const [topic, setTopic] = useState("");
	const [generating, setGenerating] = useState(false);
	const [summaryStyle, setSummaryStyle] = useState<SummaryStyleKey>("concise");
	const [summaryFocus, setSummaryFocus] = useState<SummaryFocusKey>("key-concepts");

	const userId = APP_CONFIG.userId || "demo-user";

	const generateFlashcards = async () => {
		if (!inputText.trim() || !topic.trim()) {
			toast.error("Please provide both text and set name");
			return;
		}

		setGenerating(true);
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const newCards: Partial<FlashcardModel>[] = [];

			// Strategy 1: Try to parse structured Q&A format (Q: ... A: ...)
			// This handles formats like:
			// - "Q: question A: answer" (on same line or different lines)
			// - "q: question A: answer" (case insensitive)
			// - Multiple Q&A pairs separated by newlines or blank lines

			// First, normalize the text by removing extra whitespace but preserving structure
			const normalizedText = inputText.replace(/\r\n/g, '\n').trim();

			// Look for Q:/q: followed by A: pattern
			const qaPatternRegex = /[Qq]\s*:\s*([^]*?)(?=\s*[Aa]\s*:|$)/g;
			const answerPatternRegex = /[Aa]\s*:\s*([^]*?)(?=\s*[Qq]\s*:|$)/g;

			// Try to extract using Q: ... A: ... format
			const questions: string[] = [];
			const answers: string[] = [];

			let qMatch;
			while ((qMatch = qaPatternRegex.exec(normalizedText)) !== null) {
				const question = qMatch[1].trim();
				if (question) {
					questions.push(question);
				}
			}

			let aMatch;
			while ((aMatch = answerPatternRegex.exec(normalizedText)) !== null) {
				const answer = aMatch[1].trim();
				if (answer) {
					answers.push(answer);
				}
			}

			// If we found matching Q&A pairs using the Q: A: format
			if (questions.length > 0 && questions.length === answers.length) {
				for (let i = 0; i < questions.length; i++) {
					newCards.push({
						user_id: userId,
						front: questions[i],
						back: answers[i],
						topic: topic,
						mastery_level: FlashcardMasteryLevel.NotSeen,
						is_favorite: false,
						last_reviewed: null,
						next_review_date: null,
					});
				}
			} else {
				// Strategy 2: Try ||| separator or simple Q/q separator (line by line)
				const lines = inputText.split("\n").filter((line) => line.trim());

				for (const line of lines) {
					// Check for ||| separator first
					if (line.includes('|||')) {
						const parts = line.split('|||');
						const question = parts[0]?.trim();
						const answer = parts[1]?.trim();

						if (question && answer) {
							newCards.push({
								user_id: userId,
								front: question,
								back: answer,
								topic: topic,
								mastery_level: FlashcardMasteryLevel.NotSeen,
								is_favorite: false,
								last_reviewed: null,
								next_review_date: null,
							});
						}
					}
					// Try simple Q or q separator (but only if not using Q: A: format)
					else if (/\s+[Qq]\s+/.test(line)) {
						const parts = line.split(/\s+[Qq]\s+/);
						const question = parts[0]?.trim();
						const answer = parts[1]?.trim();

						if (question && answer) {
							newCards.push({
								user_id: userId,
								front: question,
								back: answer,
								topic: topic,
								mastery_level: FlashcardMasteryLevel.NotSeen,
								is_favorite: false,
								last_reviewed: null,
								next_review_date: null,
							});
						}
					}
				}
			}

			// If no Q&A pairs were found, fall back to sentence-based generation
			if (newCards.length === 0) {
				// Split text into sentences
				const sentences = inputText
					.split(/[.!?]+/)
					.map((s) => s.trim())
					.filter((s) => s.length > 15);

				if (sentences.length === 0) {
					toast.error(
						"Please provide longer text with complete sentences or use 'Q' or '|||' to separate Q&A pairs",
					);
					setGenerating(false);
					return;
				}

				// Strategy 1: Look for definition-style sentences
				for (const sentence of sentences) {
					if (newCards.length >= 10) break;

					// Check for definition patterns
					const definitionMatch = sentence.match(
						/(.+?)\s+(is|are|means|refers to|defined as)\s+(.+)/i,
					);
					if (definitionMatch) {
						const subject = definitionMatch[1].trim();
						const definition = definitionMatch[3].trim();
						newCards.push({
							user_id: userId,
							front: `What ${definitionMatch[2]} ${subject}?`,
							back: definition,
							topic: topic,
							mastery_level: FlashcardMasteryLevel.NotSeen,
							is_favorite: false,
							last_reviewed: null,
							next_review_date: null,
						});
						continue;
					}

					// Check for key concept sentences
					const hasKeyIndicator = [
						/\b(first|second|third|finally|importantly|main|primary|key)\b/i,
						/\b(because|therefore|thus|hence|consequently)\b/i,
						/\b(important|significant|critical|crucial|essential)\b/i,
					].some((pattern) => pattern.test(sentence));

					if (hasKeyIndicator && sentence.split(" ").length >= 8) {
						// Extract first 5-7 words as question context
						const words = sentence.split(" ");
						const questionContext = words
							.slice(0, Math.min(6, Math.floor(words.length / 2)))
							.join(" ");

						newCards.push({
							user_id: userId,
							front: `Complete the following about ${topic}: "${questionContext}..."`,
							back: sentence,
							topic: topic,
							mastery_level: FlashcardMasteryLevel.NotSeen,
							is_favorite: false,
							last_reviewed: null,
							next_review_date: null,
						});
					}
				}

				// If we still don't have enough cards, create generic ones from substantial sentences
				if (newCards.length < 3) {
					const substantialSentences = sentences
						.filter((s) => s.split(" ").length >= 8)
						.slice(0, 5);

					for (const sentence of substantialSentences) {
						if (newCards.length >= 10) break;

						newCards.push({
							user_id: userId,
							front: `What is mentioned about ${topic}?`,
							back: sentence,
							topic: topic,
							mastery_level: FlashcardMasteryLevel.NotSeen,
							is_favorite: false,
							last_reviewed: null,
							next_review_date: null,
						});
					}
				}
			}

			if (newCards.length === 0) {
				toast.error(
					"Could not generate flashcards. Use 'Q' or '|||' to separate questions and answers, or provide longer text.",
				);
				setGenerating(false);
				return;
			}

			await flashcardOrm.insertFlashcard(newCards as FlashcardModel[]);
			toast.success(
				`Generated ${newCards.length} flashcard${newCards.length > 1 ? "s" : ""} in set "${topic}"!`,
			);
			setInputText("");
			setTopic("");
		} catch (error) {
			console.error("Error generating flashcards:", error);
			toast.error(
				`Failed to generate flashcards: ${error instanceof Error ? error.message : "Unknown error"}`,
			);
		} finally {
			setGenerating(false);
		}
	};

	const addManualCard = async () => {
		if (!inputText.trim() || !topic.trim()) {
			toast.error("Please provide both question/answer and set name");
			return;
		}

		try {
			const flashcardOrm = FlashcardORM.getInstance();

			let front = "";
			let back = "";

			// Try Q: A: format first
			const qaMatch = inputText.match(/[Qq]\s*:\s*(.+?)\s*[Aa]\s*:\s*(.+)/s);
			if (qaMatch) {
				front = qaMatch[1].trim();
				back = qaMatch[2].trim();
			} else if (inputText.includes('|||')) {
				// Try ||| separator
				const parts = inputText.split('|||');
				front = parts[0]?.trim() || "";
				back = parts[1]?.trim() || "";
			} else if (/\s+[Qq]\s+/.test(inputText)) {
				// Try simple Q separator
				const parts = inputText.split(/\s+[Qq]\s+/);
				front = parts[0]?.trim() || "";
				back = parts[1]?.trim() || "";
			}

			if (!front || !back) {
				toast.error(
					'Use "Q: ... A: ..." or "Q" or "|||" to separate question and answer (e.g., "Q: What is...? A: Answer")',
				);
				return;
			}

			const newCard: Partial<FlashcardModel> = {
				user_id: userId,
				front,
				back,
				topic,
				mastery_level: FlashcardMasteryLevel.NotSeen,
				is_favorite: false,
				last_reviewed: null,
				next_review_date: null,
			};

			await flashcardOrm.insertFlashcard([newCard as FlashcardModel]);
			toast.success(`Flashcard added to set "${topic}"!`);
			setInputText("");
		} catch (error) {
			console.error("Error adding flashcard:", error);
			toast.error("Failed to add flashcard");
		}
	};

	return (
		<div className="space-y-6">
			<Card>
				<CardHeader>
					<div className="flex items-center justify-between">
						<div>
							<CardTitle>Create Flashcards</CardTitle>
							<CardDescription>
								Generate cards from text or add them manually to a set
							</CardDescription>
						</div>
						<Button onClick={onViewSets} variant="outline" className="gap-2">
							<BookOpen className="h-4 w-4" />
							View My Sets
						</Button>
					</div>
				</CardHeader>
				<CardContent className="space-y-6">
					<Tabs defaultValue="generate">
						<TabsList className="grid w-full grid-cols-2">
							<TabsTrigger value="generate">AI Generate</TabsTrigger>
							<TabsTrigger value="manual">Manual Entry</TabsTrigger>
						</TabsList>

						<TabsContent value="generate" className="space-y-4 mt-6">
							<div className="space-y-2">
								<Label htmlFor="topic-gen">Set Name (required)</Label>
								<Input
									id="topic-gen"
									placeholder="e.g., Biology - Cell Structure, Math - Fractions"
									value={topic}
									onChange={(e) => setTopic(e.target.value)}
								/>
								<p className="text-xs text-gray-500">
									This creates a new flashcard set or adds to an existing one
								</p>
							</div>

							{/* Summary Style and Focus On */}
							<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
								<div className="space-y-2">
									<Label htmlFor="summary-style-gen">Summary Style</Label>
									<Select
										value={summaryStyle}
										onValueChange={(value) => setSummaryStyle(value as SummaryStyleKey)}
										disabled={generating}
									>
										<SelectTrigger id="summary-style-gen">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="concise">Concise - Quick overview</SelectItem>
											<SelectItem value="detailed">Detailed - Comprehensive</SelectItem>
											<SelectItem value="bullet-points">Bullet Points - Easy to scan</SelectItem>
											<SelectItem value="study-guide">Study Guide - Exam prep</SelectItem>
										</SelectContent>
									</Select>
								</div>

								<div className="space-y-2">
									<Label htmlFor="summary-focus-gen">Focus On</Label>
									<Select
										value={summaryFocus}
										onValueChange={(value) => setSummaryFocus(value as SummaryFocusKey)}
										disabled={generating}
									>
										<SelectTrigger id="summary-focus-gen">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="key-concepts">Key Concepts</SelectItem>
											<SelectItem value="definitions">Definitions</SelectItem>
											<SelectItem value="main-ideas">Main Ideas</SelectItem>
											<SelectItem value="comprehensive">Comprehensive</SelectItem>
										</SelectContent>
									</Select>
								</div>
							</div>

							<div className="space-y-2">
								<Label htmlFor="text-gen">Paste your notes or Q&A pairs</Label>
								<Textarea
									id="text-gen"
									placeholder="Format: Q: question A: answer (multiple pairs supported)&#10;&#10;Q: What is AI? A: A field of computer science focused on creating intelligent systems&#10;&#10;Q: How do AI systems learn? A: By analyzing large datasets with algorithms&#10;&#10;You can also use ||| or just Q as separators"
									value={inputText}
									onChange={(e) => setInputText(e.target.value)}
									rows={12}
								/>
								<p className="text-xs text-gray-500">
									Supported formats: "Q: ... A: ...", "Q" separator, or "|||" separator. Multiple pairs supported.
								</p>
							</div>
							<Button
								onClick={generateFlashcards}
								disabled={generating}
								className="w-full gap-2"
							>
								<Sparkles className="h-4 w-4" />
								{generating ? "Generating..." : "Generate Flashcards"}
							</Button>
						</TabsContent>

						<TabsContent value="manual" className="space-y-4 mt-6">
							<div className="space-y-2">
								<Label htmlFor="topic-manual">Set Name (required)</Label>
								<Input
									id="topic-manual"
									placeholder="e.g., Mathematics - Algebra, History - WWII"
									value={topic}
									onChange={(e) => setTopic(e.target.value)}
								/>
								<p className="text-xs text-gray-500">
									This creates a new flashcard set or adds to an existing one
								</p>
							</div>
							<div className="space-y-2">
								<Label htmlFor="text-manual">
									Question and Answer
								</Label>
								<Textarea
									id="text-manual"
									placeholder="Q: What is photosynthesis? A: The process by which plants convert light energy into chemical energy..."
									value={inputText}
									onChange={(e) => setInputText(e.target.value)}
									rows={8}
								/>
								<p className="text-xs text-gray-500">
									Use "Q: ... A: ...", "Q", or "|||" to separate question from answer
								</p>
							</div>
							<Button onClick={addManualCard} className="w-full gap-2">
								<Plus className="h-4 w-4" />
								Add Flashcard
							</Button>
						</TabsContent>
					</Tabs>
				</CardContent>
			</Card>
		</div>
	);
}
