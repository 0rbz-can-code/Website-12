import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import "@testing-library/jest-dom";
import { FlashcardGenerator } from "./FlashcardGenerator";

// Mock the child components
vi.mock("./FlashcardCreate", () => ({
	FlashcardCreate: ({ onViewSets }: { onViewSets: () => void }) => (
		<div>
			<div>FlashcardCreate Component</div>
			<button onClick={onViewSets}>View Sets</button>
		</div>
	),
}));

vi.mock("./FlashcardSetList", () => ({
	FlashcardSetList: ({ onSelectSet, onCreateNew }: { onSelectSet: (topic: string) => void; onCreateNew: () => void }) => (
		<div>
			<div>FlashcardSetList Component</div>
			<button onClick={() => onSelectSet("Test Topic")}>Select Set</button>
			<button onClick={onCreateNew}>Create New</button>
		</div>
	),
}));

vi.mock("./FlashcardSetView", () => ({
	FlashcardSetView: ({ topic, onBack }: { topic: string; onBack: () => void }) => (
		<div>
			<div>FlashcardSetView Component</div>
			<div>Topic: {topic}</div>
			<button onClick={onBack}>Back</button>
		</div>
	),
}));

describe("FlashcardGenerator", () => {
	it("should render FlashcardCreate component by default", () => {
		render(<FlashcardGenerator />);

		expect(screen.getByText("FlashcardCreate Component")).toBeInTheDocument();
	});

	it("should have proper component structure", () => {
		const { container } = render(<FlashcardGenerator />);
		expect(container.firstChild).toBeTruthy();
	});

	it("should render child components based on view mode", () => {
		render(<FlashcardGenerator />);

		// Initially should show create view
		expect(screen.getByText("FlashcardCreate Component")).toBeInTheDocument();
		expect(screen.queryByText("FlashcardSetList Component")).not.toBeInTheDocument();
		expect(screen.queryByText("FlashcardSetView Component")).not.toBeInTheDocument();
	});
});
