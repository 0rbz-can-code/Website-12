import { useState } from "react";
import { FlashcardCreate } from "./FlashcardCreate";
import { FlashcardSetList } from "./FlashcardSetList";
import { FlashcardSetView } from "./FlashcardSetView";

type ViewMode = "create" | "setList" | "setView";

export function FlashcardGenerator() {
	const [viewMode, setViewMode] = useState<ViewMode>("create");
	const [selectedTopic, setSelectedTopic] = useState<string>("");

	const handleSelectSet = (topic: string) => {
		setSelectedTopic(topic);
		setViewMode("setView");
	};

	const handleBackToSetList = () => {
		setViewMode("setList");
		setSelectedTopic("");
	};

	const handleViewSets = () => {
		setViewMode("setList");
	};

	const handleCreateNew = () => {
		setViewMode("create");
	};

	return (
		<div>
			{viewMode === "create" && <FlashcardCreate onViewSets={handleViewSets} />}
			{viewMode === "setList" && (
				<FlashcardSetList onSelectSet={handleSelectSet} onCreateNew={handleCreateNew} />
			)}
			{viewMode === "setView" && (
				<FlashcardSetView topic={selectedTopic} onBack={handleBackToSetList} />
			)}
		</div>
	);
}
