import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Edit, Trash2, Copy, ChevronRight } from "lucide-react";
import { FlashcardORM, type FlashcardModel, FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";
import { APP_CONFIG } from "@/main";
import { toast } from "sonner";
import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogFooter,
	AlertDialogHeader,
	AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@/components/ui/dialog";

interface FlashcardSet {
	topic: string;
	cardCount: number;
	masteredCount: number;
	learningCount: number;
	newCount: number;
}

interface FlashcardSetListProps {
	onSelectSet: (topic: string) => void;
	onCreateNew: () => void;
}

export function FlashcardSetList({ onSelectSet, onCreateNew }: FlashcardSetListProps) {
	const [sets, setSets] = useState<FlashcardSet[]>([]);
	const [loading, setLoading] = useState(true);
	const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
	const [renameDialogOpen, setRenameDialogOpen] = useState(false);
	const [selectedTopic, setSelectedTopic] = useState<string>("");
	const [newTopicName, setNewTopicName] = useState<string>("");

	const userId = APP_CONFIG.userId || "demo-user";

	useEffect(() => {
		loadSets();
	}, []);

	const loadSets = async () => {
		try {
			setLoading(true);
			const flashcardOrm = FlashcardORM.getInstance();
			const allCards = await flashcardOrm.getFlashcardByUserId(userId);

			// Group cards by topic
			const topicMap = new Map<string, FlashcardModel[]>();
			allCards.forEach((card) => {
				if (!topicMap.has(card.topic)) {
					topicMap.set(card.topic, []);
				}
				topicMap.get(card.topic)?.push(card);
			});

			// Convert to FlashcardSet array
			const setsArray: FlashcardSet[] = Array.from(topicMap.entries()).map(([topic, cards]) => {
				const masteredCount = cards.filter(
					(c) => c.mastery_level === FlashcardMasteryLevel.Mastered,
				).length;
				const learningCount = cards.filter(
					(c) => c.mastery_level === FlashcardMasteryLevel.Learning,
				).length;
				const newCount = cards.filter((c) => c.mastery_level === FlashcardMasteryLevel.NotSeen).length;

				return {
					topic,
					cardCount: cards.length,
					masteredCount,
					learningCount,
					newCount,
				};
			});

			setSets(setsArray);
		} catch (error) {
			console.error("Error loading flashcard sets:", error);
			toast.error("Failed to load flashcard sets");
		} finally {
			setLoading(false);
		}
	};

	const handleDeleteSet = async () => {
		if (!selectedTopic) return;

		try {
			const flashcardOrm = FlashcardORM.getInstance();
			await flashcardOrm.deleteFlashcardByTopicUserId(selectedTopic, userId);
			toast.success("Flashcard set deleted");
			setDeleteDialogOpen(false);
			setSelectedTopic("");
			loadSets();
		} catch (error) {
			console.error("Error deleting set:", error);
			toast.error("Failed to delete set");
		}
	};

	const handleRenameSet = async () => {
		if (!selectedTopic || !newTopicName.trim()) {
			toast.error("Please enter a new name");
			return;
		}

		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const cards = await flashcardOrm.getFlashcardByTopicUserId(selectedTopic, userId);

			// Update each card's topic
			for (const card of cards) {
				const updated: FlashcardModel = {
					...card,
					topic: newTopicName.trim(),
				};
				await flashcardOrm.setFlashcardById(card.id, updated);
			}

			toast.success("Set renamed successfully");
			setRenameDialogOpen(false);
			setSelectedTopic("");
			setNewTopicName("");
			loadSets();
		} catch (error) {
			console.error("Error renaming set:", error);
			toast.error("Failed to rename set");
		}
	};

	const handleDuplicateSet = async (topic: string) => {
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const cards = await flashcardOrm.getFlashcardByTopicUserId(topic, userId);

			const duplicatedCards = cards.map((card) => ({
				user_id: userId,
				front: card.front,
				back: card.back,
				topic: `${topic} (Copy)`,
				mastery_level: FlashcardMasteryLevel.NotSeen,
				is_favorite: false,
				last_reviewed: null,
				next_review_date: null,
			}));

			await flashcardOrm.insertFlashcard(duplicatedCards as FlashcardModel[]);
			toast.success(`Duplicated ${cards.length} cards to "${topic} (Copy)"`);
			loadSets();
		} catch (error) {
			console.error("Error duplicating set:", error);
			toast.error("Failed to duplicate set");
		}
	};

	const openDeleteDialog = (topic: string) => {
		setSelectedTopic(topic);
		setDeleteDialogOpen(true);
	};

	const openRenameDialog = (topic: string) => {
		setSelectedTopic(topic);
		setNewTopicName(topic);
		setRenameDialogOpen(true);
	};

	return (
		<div className="space-y-6">
			<Card>
				<CardHeader>
					<div className="flex items-center justify-between">
						<div>
							<CardTitle>My Flashcard Sets</CardTitle>
							<CardDescription>Organize your flashcards by subject or topic</CardDescription>
						</div>
						<Button onClick={onCreateNew} className="gap-2">
							<BookOpen className="h-4 w-4" />
							Create Cards
						</Button>
					</div>
				</CardHeader>
				<CardContent>
					{loading ? (
						<div className="text-center py-12 text-gray-500">Loading sets...</div>
					) : sets.length === 0 ? (
						<div className="text-center py-12">
							<BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
							<p className="text-gray-600 mb-4">No flashcard sets yet</p>
							<Button onClick={onCreateNew}>Create your first flashcard set</Button>
						</div>
					) : (
						<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
							{sets.map((set) => (
								<Card
									key={set.topic}
									className="border-2 hover:border-indigo-300 transition-colors cursor-pointer"
									onClick={() => onSelectSet(set.topic)}
								>
									<CardHeader className="pb-3">
										<CardTitle className="text-lg flex items-center justify-between">
											<span className="truncate">{set.topic}</span>
											<ChevronRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
										</CardTitle>
										<CardDescription>{set.cardCount} cards</CardDescription>
									</CardHeader>
									<CardContent className="space-y-3">
										<div className="flex gap-2 flex-wrap">
											<Badge variant="default" className="bg-green-100 text-green-700">
												{set.masteredCount} mastered
											</Badge>
											<Badge variant="secondary">{set.learningCount} learning</Badge>
											<Badge variant="outline">{set.newCount} new</Badge>
										</div>
										<div className="flex gap-2 pt-2" onClick={(e) => e.stopPropagation()}>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => openRenameDialog(set.topic)}
												className="flex-1"
											>
												<Edit className="h-4 w-4" />
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => handleDuplicateSet(set.topic)}
												className="flex-1"
											>
												<Copy className="h-4 w-4" />
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => openDeleteDialog(set.topic)}
												className="flex-1 text-red-600 hover:text-red-700"
											>
												<Trash2 className="h-4 w-4" />
											</Button>
										</div>
									</CardContent>
								</Card>
							))}
						</div>
					)}
				</CardContent>
			</Card>

			{/* Delete Confirmation Dialog */}
			<AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
				<AlertDialogContent>
					<AlertDialogHeader>
						<AlertDialogTitle>Delete Flashcard Set</AlertDialogTitle>
						<AlertDialogDescription>
							Are you sure you want to delete "{selectedTopic}"? This will permanently delete all
							flashcards in this set. This action cannot be undone.
						</AlertDialogDescription>
					</AlertDialogHeader>
					<AlertDialogFooter>
						<AlertDialogCancel>Cancel</AlertDialogCancel>
						<AlertDialogAction onClick={handleDeleteSet} className="bg-red-600 hover:bg-red-700">
							Delete
						</AlertDialogAction>
					</AlertDialogFooter>
				</AlertDialogContent>
			</AlertDialog>

			{/* Rename Dialog */}
			<Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Rename Flashcard Set</DialogTitle>
						<DialogDescription>
							Enter a new name for "{selectedTopic}"
						</DialogDescription>
					</DialogHeader>
					<div className="space-y-2 py-4">
						<Label htmlFor="new-topic-name">New Set Name</Label>
						<Input
							id="new-topic-name"
							value={newTopicName}
							onChange={(e) => setNewTopicName(e.target.value)}
							placeholder="e.g., Biology - Cells"
						/>
					</div>
					<DialogFooter>
						<Button variant="outline" onClick={() => setRenameDialogOpen(false)}>
							Cancel
						</Button>
						<Button onClick={handleRenameSet}>Rename</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}
