import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
	ChevronLeft,
	ChevronRight,
	Heart,
	RotateCcw,
	Shuffle,
	Check,
	X,
	ArrowLeft,
} from "lucide-react";
import { FlashcardORM, type FlashcardModel, FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";
import { APP_CONFIG } from "@/main";
import { toast } from "sonner";

interface FlashcardSetViewProps {
	topic: string;
	onBack: () => void;
}

export function FlashcardSetView({ topic, onBack }: FlashcardSetViewProps) {
	const [flashcards, setFlashcards] = useState<FlashcardModel[]>([]);
	const [currentIndex, setCurrentIndex] = useState(0);
	const [isFlipped, setIsFlipped] = useState(false);
	const [studyMode, setStudyMode] = useState<"all" | "learning" | "new">("all");

	const userId = APP_CONFIG.userId || "demo-user";

	useEffect(() => {
		loadFlashcards();
	}, [studyMode, topic]);

	const loadFlashcards = async () => {
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const allCardsInSet = await flashcardOrm.getFlashcardByTopicUserId(topic, userId);

			let filtered: FlashcardModel[] = [];

			if (studyMode === "all") {
				filtered = allCardsInSet;
			} else if (studyMode === "learning") {
				filtered = allCardsInSet.filter((c) => c.mastery_level === FlashcardMasteryLevel.Learning);
			} else if (studyMode === "new") {
				filtered = allCardsInSet.filter((c) => c.mastery_level === FlashcardMasteryLevel.NotSeen);
			}

			setFlashcards(filtered);
			if (filtered.length > 0 && currentIndex >= filtered.length) {
				setCurrentIndex(0);
			}
		} catch (error) {
			console.error("Error loading flashcards:", error);
		}
	};

	const toggleFavorite = async () => {
		if (flashcards.length === 0) return;

		const current = flashcards[currentIndex];
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const updated: FlashcardModel = {
				...current,
				is_favorite: !current.is_favorite,
			};
			await flashcardOrm.setFlashcardById(current.id, updated);
			loadFlashcards();
		} catch (error) {
			console.error("Error updating favorite:", error);
		}
	};

	const markMastery = async (level: FlashcardMasteryLevel) => {
		if (flashcards.length === 0) return;

		const current = flashcards[currentIndex];
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const now = new Date();
			const nextReview = new Date();

			// Spaced repetition intervals
			if (level === FlashcardMasteryLevel.Learning) {
				nextReview.setDate(now.getDate() + 1); // Review tomorrow
			} else if (level === FlashcardMasteryLevel.Mastered) {
				nextReview.setDate(now.getDate() + 7); // Review in a week
			}

			const updated: FlashcardModel = {
				...current,
				mastery_level: level,
				last_reviewed: now.toISOString(),
				next_review_date:
					level !== FlashcardMasteryLevel.NotSeen ? nextReview.toISOString() : null,
			};

			await flashcardOrm.setFlashcardById(current.id, updated);
			toast.success(
				level === FlashcardMasteryLevel.Mastered
					? "Marked as mastered!"
					: level === FlashcardMasteryLevel.Learning
						? "Marked as learning"
						: "Reset to new",
			);

			// Move to next card
			if (currentIndex < flashcards.length - 1) {
				setCurrentIndex(currentIndex + 1);
			} else {
				setCurrentIndex(0);
			}
			setIsFlipped(false);
			loadFlashcards();
		} catch (error) {
			console.error("Error updating mastery:", error);
		}
	};

	const shuffleCards = () => {
		const shuffled = [...flashcards].sort(() => Math.random() - 0.5);
		setFlashcards(shuffled);
		setCurrentIndex(0);
		setIsFlipped(false);
		toast.success("Cards shuffled");
	};

	const nextCard = () => {
		if (currentIndex < flashcards.length - 1) {
			setCurrentIndex(currentIndex + 1);
			setIsFlipped(false);
		}
	};

	const prevCard = () => {
		if (currentIndex > 0) {
			setCurrentIndex(currentIndex - 1);
			setIsFlipped(false);
		}
	};

	const currentCard = flashcards[currentIndex];

	const masteredCount = flashcards.filter((c) => c.mastery_level === FlashcardMasteryLevel.Mastered)
		.length;
	const learningCount = flashcards.filter((c) => c.mastery_level === FlashcardMasteryLevel.Learning)
		.length;
	const newCount = flashcards.filter((c) => c.mastery_level === FlashcardMasteryLevel.NotSeen).length;

	return (
		<div className="space-y-6">
			<Card>
				<CardHeader>
					<div className="flex items-center justify-between">
						<div className="flex items-center gap-3">
							<Button variant="ghost" size="icon" onClick={onBack}>
								<ArrowLeft className="h-5 w-5" />
							</Button>
							<div>
								<CardTitle>{topic}</CardTitle>
								<CardDescription>Practice mode - Track your progress</CardDescription>
							</div>
						</div>
					</div>
				</CardHeader>
				<CardContent className="space-y-6">
					{/* Study Mode Selector */}
					<Tabs value={studyMode} onValueChange={(v) => setStudyMode(v as any)}>
						<TabsList className="grid w-full grid-cols-3">
							<TabsTrigger value="all">All Cards</TabsTrigger>
							<TabsTrigger value="new">New ({newCount})</TabsTrigger>
							<TabsTrigger value="learning">Learning ({learningCount})</TabsTrigger>
						</TabsList>
					</Tabs>

					{flashcards.length === 0 ? (
						<div className="text-center py-12">
							<p className="text-gray-600 mb-4">
								{studyMode === "all"
									? "No flashcards in this set"
									: studyMode === "new"
										? "No new cards to study"
										: "No cards in learning mode"}
							</p>
							<Button onClick={onBack}>Back to Sets</Button>
						</div>
					) : (
						<>
							{/* Stats */}
							<div className="grid grid-cols-3 gap-4">
								<div className="text-center p-3 bg-green-50 rounded-lg">
									<div className="text-2xl font-bold text-green-600">{masteredCount}</div>
									<div className="text-xs text-gray-500">Mastered</div>
								</div>
								<div className="text-center p-3 bg-blue-50 rounded-lg">
									<div className="text-2xl font-bold text-blue-600">{learningCount}</div>
									<div className="text-xs text-gray-500">Learning</div>
								</div>
								<div className="text-center p-3 bg-gray-50 rounded-lg">
									<div className="text-2xl font-bold text-gray-600">{newCount}</div>
									<div className="text-xs text-gray-500">New</div>
								</div>
							</div>

							{/* Flashcard Display */}
							<div
								className="relative h-80 cursor-pointer"
								onClick={() => setIsFlipped(!isFlipped)}
							>
								<div
									className={`absolute inset-0 transition-all duration-500 transform ${
										isFlipped ? "rotate-y-180 opacity-0" : ""
									}`}
								>
									<Card className="h-full border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50">
										<CardContent className="h-full flex flex-col items-center justify-center p-8">
											<Badge className="mb-4">Question</Badge>
											<p className="text-2xl font-medium text-center">
												{currentCard?.front}
											</p>
											<p className="text-sm text-gray-500 mt-6">
												Click to reveal answer
											</p>
										</CardContent>
									</Card>
								</div>
								<div
									className={`absolute inset-0 transition-all duration-500 transform ${
										!isFlipped ? "rotate-y-180 opacity-0" : ""
									}`}
								>
									<Card className="h-full border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
										<CardContent className="h-full flex flex-col items-center justify-center p-8">
											<Badge variant="secondary" className="mb-4">
												Answer
											</Badge>
											<p className="text-xl text-center">{currentCard?.back}</p>
										</CardContent>
									</Card>
								</div>
							</div>

							{/* Card Info */}
							<div className="flex items-center justify-between">
								<div className="flex items-center gap-2">
									<Badge
										variant={
											currentCard?.mastery_level ===
											FlashcardMasteryLevel.Mastered
												? "default"
												: "outline"
										}
									>
										{currentCard?.mastery_level ===
										FlashcardMasteryLevel.Mastered
											? "Mastered"
											: currentCard?.mastery_level ===
												  FlashcardMasteryLevel.Learning
												? "Learning"
												: "New"}
									</Badge>
									{currentCard?.is_favorite && (
										<Heart className="h-4 w-4 fill-red-500 text-red-500" />
									)}
								</div>
								<span className="text-sm text-gray-600">
									{currentIndex + 1} / {flashcards.length}
								</span>
							</div>

							{/* Navigation */}
							<div className="flex items-center justify-between gap-4">
								<Button
									onClick={prevCard}
									disabled={currentIndex === 0}
									variant="outline"
									size="icon"
								>
									<ChevronLeft className="h-4 w-4" />
								</Button>

								<div className="flex gap-2">
									<Button onClick={toggleFavorite} variant="outline" size="sm">
										<Heart
											className={`h-4 w-4 ${currentCard?.is_favorite ? "fill-red-500 text-red-500" : ""}`}
										/>
									</Button>
									<Button onClick={shuffleCards} variant="outline" size="sm">
										<Shuffle className="h-4 w-4" />
									</Button>
								</div>

								<Button
									onClick={nextCard}
									disabled={currentIndex === flashcards.length - 1}
									variant="outline"
									size="icon"
								>
									<ChevronRight className="h-4 w-4" />
								</Button>
							</div>

							{/* Mastery Controls */}
							{isFlipped && (
								<div className="flex gap-3 justify-center pt-4">
									<Button
										onClick={() =>
											markMastery(FlashcardMasteryLevel.NotSeen)
										}
										variant="outline"
										size="sm"
										className="gap-2"
									>
										<RotateCcw className="h-4 w-4" />
										Reset
									</Button>
									<Button
										onClick={() =>
											markMastery(FlashcardMasteryLevel.Learning)
										}
										variant="outline"
										size="sm"
										className="gap-2"
									>
										<X className="h-4 w-4" />
										Still Learning
									</Button>
									<Button
										onClick={() =>
											markMastery(FlashcardMasteryLevel.Mastered)
										}
										className="gap-2 bg-green-600 hover:bg-green-700"
										size="sm"
									>
										<Check className="h-4 w-4" />
										Mastered
									</Button>
								</div>
							)}
						</>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
