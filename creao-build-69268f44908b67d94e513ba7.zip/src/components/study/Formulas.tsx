import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calculator, Copy, Trash2, Plus, Search, BookOpen, Star } from "lucide-react";
import { toast } from "sonner";

type FormulaCategory = "math" | "physics" | "chemistry" | "statistics" | "engineering" | "other";

interface Formula {
	id: string;
	name: string;
	formula: string;
	category: FormulaCategory;
	description: string;
	variables: string;
	example?: string;
	notes?: string;
	isFavorite: boolean;
	createdAt: Date;
}

export function Formulas() {
	const [formulas, setFormulas] = useState<Formula[]>([]);
	const [isAdding, setIsAdding] = useState(false);
	const [searchQuery, setSearchQuery] = useState("");
	const [filterCategory, setFilterCategory] = useState<FormulaCategory | "all">("all");
	const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

	// Form state
	const [name, setName] = useState("");
	const [formula, setFormula] = useState("");
	const [category, setCategory] = useState<FormulaCategory>("math");
	const [description, setDescription] = useState("");
	const [variables, setVariables] = useState("");
	const [example, setExample] = useState("");
	const [notes, setNotes] = useState("");

	// Load formulas from localStorage
	useEffect(() => {
		const saved = localStorage.getItem("cheatex-formulas");
		if (saved) {
			try {
				const parsed = JSON.parse(saved);
				setFormulas(parsed.map((f: Formula) => ({ ...f, createdAt: new Date(f.createdAt) })));
			} catch (error) {
				console.error("Error loading formulas:", error);
			}
		} else {
			// Load sample formulas
			loadSampleFormulas();
		}
	}, []);

	// Save formulas to localStorage
	useEffect(() => {
		if (formulas.length > 0) {
			localStorage.setItem("cheatex-formulas", JSON.stringify(formulas));
		}
	}, [formulas]);

	const loadSampleFormulas = () => {
		const samples: Formula[] = [
			{
				id: "1",
				name: "Quadratic Formula",
				formula: "x = (-b ± √(b² - 4ac)) / 2a",
				category: "math",
				description: "Solves quadratic equations of the form ax² + bx + c = 0",
				variables: "a, b, c are coefficients; x is the solution",
				example: "For x² - 5x + 6 = 0: a=1, b=-5, c=6 → x = 2 or x = 3",
				isFavorite: false,
				createdAt: new Date(),
			},
			{
				id: "2",
				name: "Pythagorean Theorem",
				formula: "a² + b² = c²",
				category: "math",
				description: "Relates the sides of a right triangle",
				variables: "a, b are legs; c is hypotenuse",
				example: "If a=3 and b=4, then c=5",
				isFavorite: false,
				createdAt: new Date(),
			},
			{
				id: "3",
				name: "Newton's Second Law",
				formula: "F = ma",
				category: "physics",
				description: "Force equals mass times acceleration",
				variables: "F = force (N), m = mass (kg), a = acceleration (m/s²)",
				example: "A 10kg object accelerating at 5m/s² experiences 50N of force",
				isFavorite: false,
				createdAt: new Date(),
			},
			{
				id: "4",
				name: "Kinetic Energy",
				formula: "KE = ½mv²",
				category: "physics",
				description: "Energy of motion",
				variables: "KE = kinetic energy (J), m = mass (kg), v = velocity (m/s)",
				example: "A 2kg object moving at 10m/s has KE = 100J",
				isFavorite: false,
				createdAt: new Date(),
			},
			{
				id: "5",
				name: "Ideal Gas Law",
				formula: "PV = nRT",
				category: "chemistry",
				description: "Relates pressure, volume, and temperature of an ideal gas",
				variables: "P = pressure, V = volume, n = moles, R = gas constant, T = temperature",
				example: "At STP: P=1atm, V=22.4L, n=1mol, T=273K",
				isFavorite: false,
				createdAt: new Date(),
			},
			{
				id: "6",
				name: "Standard Deviation",
				formula: "σ = √[Σ(x - μ)² / N]",
				category: "statistics",
				description: "Measures spread of data from the mean",
				variables: "σ = std dev, x = data point, μ = mean, N = sample size",
				notes: "For sample: divide by (N-1) instead of N",
				isFavorite: false,
				createdAt: new Date(),
			},
		];
		setFormulas(samples);
	};

	const addFormula = () => {
		if (!name.trim() || !formula.trim()) {
			toast.error("Please fill in name and formula");
			return;
		}

		const newFormula: Formula = {
			id: Date.now().toString(),
			name,
			formula,
			category,
			description,
			variables,
			example,
			notes,
			isFavorite: false,
			createdAt: new Date(),
		};

		setFormulas([newFormula, ...formulas]);

		// Reset form
		setName("");
		setFormula("");
		setDescription("");
		setVariables("");
		setExample("");
		setNotes("");
		setIsAdding(false);

		toast.success("Formula added successfully!");
	};

	const deleteFormula = (id: string) => {
		setFormulas(formulas.filter(f => f.id !== id));
		toast.success("Formula deleted");
	};

	const toggleFavorite = (id: string) => {
		setFormulas(formulas.map(f =>
			f.id === id ? { ...f, isFavorite: !f.isFavorite } : f
		));
	};

	const copyFormula = (formula: string) => {
		navigator.clipboard.writeText(formula);
		toast.success("Formula copied to clipboard!");
	};

	const clearAll = () => {
		if (confirm("Are you sure you want to delete all formulas? Sample formulas will be restored.")) {
			localStorage.removeItem("cheatex-formulas");
			loadSampleFormulas();
			toast.success("All formulas cleared, sample formulas restored");
		}
	};

	// Filter formulas
	const filteredFormulas = formulas.filter(f => {
		const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
			f.formula.toLowerCase().includes(searchQuery.toLowerCase()) ||
			f.description.toLowerCase().includes(searchQuery.toLowerCase());

		const matchesCategory = filterCategory === "all" || f.category === filterCategory;
		const matchesFavorite = !showFavoritesOnly || f.isFavorite;

		return matchesSearch && matchesCategory && matchesFavorite;
	});

	const getCategoryColor = (cat: FormulaCategory) => {
		const colors: Record<FormulaCategory, string> = {
			math: "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300",
			physics: "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300",
			chemistry: "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300",
			statistics: "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300",
			engineering: "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300",
			other: "bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300",
		};
		return colors[cat];
	};

	const favoriteCount = formulas.filter(f => f.isFavorite).length;

	return (
		<div className="space-y-6 animate-fade-in">
			<Card className="shadow-xl border-2 border-green-200 dark:border-green-800 bg-gradient-to-br from-white via-green-50 to-white dark:from-gray-900 dark:via-green-950 dark:to-gray-900">
				<CardHeader>
					<CardTitle className="flex items-center gap-3 text-2xl font-bold">
						<div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg shadow-lg">
							<Calculator className="h-6 w-6 text-white" />
						</div>
						Formula Reference Library
					</CardTitle>
					<CardDescription className="text-base mt-2">
						Build your personal collection of essential formulas for quick reference during study sessions. Includes math, physics, chemistry, and more.
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					<div className="flex items-center justify-between flex-wrap gap-4">
						<div className="flex items-center gap-2 flex-1 max-w-md">
							<div className="relative flex-1">
								<Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
								<Input
									placeholder="Search formulas..."
									value={searchQuery}
									onChange={(e) => setSearchQuery(e.target.value)}
									className="pl-10"
								/>
							</div>
						</div>

						<div className="flex items-center gap-2">
							<Label htmlFor="category-filter" className="sr-only">Filter by category</Label>
							<Select value={filterCategory} onValueChange={(value) => setFilterCategory(value as FormulaCategory | "all")}>
								<SelectTrigger id="category-filter" className="w-36">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="all">All Categories</SelectItem>
									<SelectItem value="math">Math</SelectItem>
									<SelectItem value="physics">Physics</SelectItem>
									<SelectItem value="chemistry">Chemistry</SelectItem>
									<SelectItem value="statistics">Statistics</SelectItem>
									<SelectItem value="engineering">Engineering</SelectItem>
									<SelectItem value="other">Other</SelectItem>
								</SelectContent>
							</Select>

							<Button
								variant={showFavoritesOnly ? "default" : "outline"}
								onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
								className="gap-2"
							>
								<Star className={`h-4 w-4 ${showFavoritesOnly ? "fill-current" : ""}`} />
								{favoriteCount}
							</Button>

							<Button
								onClick={() => setIsAdding(!isAdding)}
								className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
							>
								<Plus className="h-5 w-5 mr-2" />
								{isAdding ? "Cancel" : "Add Formula"}
							</Button>

							{formulas.length > 6 && (
								<Button variant="outline" onClick={clearAll}>
									<Trash2 className="h-4 w-4 mr-2" />
									Reset
								</Button>
							)}
						</div>
					</div>

					{/* Add Formula Form */}
					{isAdding && (
						<Card className="border-2 border-green-300 dark:border-green-700">
							<CardHeader>
								<CardTitle className="text-lg">New Formula</CardTitle>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
									<div className="space-y-2">
										<Label htmlFor="formula-name">Name *</Label>
										<Input
											id="formula-name"
											placeholder="e.g., Quadratic Formula"
											value={name}
											onChange={(e) => setName(e.target.value)}
										/>
									</div>
									<div className="space-y-2">
										<Label htmlFor="formula-category">Category</Label>
										<Select value={category} onValueChange={(value) => setCategory(value as FormulaCategory)}>
											<SelectTrigger id="formula-category">
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="math">Math</SelectItem>
												<SelectItem value="physics">Physics</SelectItem>
												<SelectItem value="chemistry">Chemistry</SelectItem>
												<SelectItem value="statistics">Statistics</SelectItem>
												<SelectItem value="engineering">Engineering</SelectItem>
												<SelectItem value="other">Other</SelectItem>
											</SelectContent>
										</Select>
									</div>
								</div>

								<div className="space-y-2">
									<Label htmlFor="formula-text">Formula *</Label>
									<Input
										id="formula-text"
										placeholder="e.g., x = (-b ± √(b² - 4ac)) / 2a"
										value={formula}
										onChange={(e) => setFormula(e.target.value)}
										className="font-mono"
									/>
								</div>

								<div className="space-y-2">
									<Label htmlFor="formula-description">Description</Label>
									<Textarea
										id="formula-description"
										placeholder="What does this formula calculate?"
										value={description}
										onChange={(e) => setDescription(e.target.value)}
										rows={2}
									/>
								</div>

								<div className="space-y-2">
									<Label htmlFor="formula-variables">Variables</Label>
									<Textarea
										id="formula-variables"
										placeholder="Define each variable (e.g., a = coefficient, x = solution)"
										value={variables}
										onChange={(e) => setVariables(e.target.value)}
										rows={2}
									/>
								</div>

								<div className="space-y-2">
									<Label htmlFor="formula-example">Example (optional)</Label>
									<Textarea
										id="formula-example"
										placeholder="Provide a worked example"
										value={example}
										onChange={(e) => setExample(e.target.value)}
										rows={2}
									/>
								</div>

								<div className="space-y-2">
									<Label htmlFor="formula-notes">Notes (optional)</Label>
									<Textarea
										id="formula-notes"
										placeholder="Any additional notes or tips"
										value={notes}
										onChange={(e) => setNotes(e.target.value)}
										rows={2}
									/>
								</div>

								<Button onClick={addFormula} className="w-full bg-gradient-to-r from-green-600 to-emerald-600">
									<Plus className="h-5 w-5 mr-2" />
									Add Formula
								</Button>
							</CardContent>
						</Card>
					)}
				</CardContent>
			</Card>

			{/* Formulas List */}
			{filteredFormulas.length > 0 ? (
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
					{filteredFormulas.map((f) => (
						<Card key={f.id} className="border-2 hover:border-green-300 transition-colors">
							<CardContent className="pt-4">
								<div className="space-y-3">
									<div className="flex items-start justify-between gap-4">
										<div className="flex-1">
											<div className="flex items-center gap-2 flex-wrap mb-2">
												<h3 className="font-bold text-lg">{f.name}</h3>
												<Badge className={getCategoryColor(f.category)}>
													{f.category}
												</Badge>
											</div>
										</div>
										<div className="flex items-center gap-1">
											<Button
												variant="ghost"
												size="sm"
												onClick={() => toggleFavorite(f.id)}
												className="p-1 h-auto"
											>
												<Star className={`h-5 w-5 ${f.isFavorite ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}`} />
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => copyFormula(f.formula)}
												className="p-1 h-auto"
											>
												<Copy className="h-4 w-4" />
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => deleteFormula(f.id)}
												className="p-1 h-auto text-red-600 hover:text-red-700"
											>
												<Trash2 className="h-4 w-4" />
											</Button>
										</div>
									</div>

									<div className="p-3 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 rounded-lg border-2 border-gray-200 dark:border-gray-700">
										<p className="text-xl font-mono font-bold text-center">{f.formula}</p>
									</div>

									{f.description && (
										<p className="text-sm text-gray-700 dark:text-gray-300">{f.description}</p>
									)}

									{f.variables && (
										<div className="text-sm">
											<div className="font-medium text-gray-700 dark:text-gray-300 mb-1">Variables:</div>
											<p className="text-gray-600 dark:text-gray-400">{f.variables}</p>
										</div>
									)}

									{f.example && (
										<div className="p-2 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800">
											<div className="flex items-start gap-2">
												<BookOpen className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
												<div className="text-sm">
													<div className="font-medium text-blue-700 dark:text-blue-300 mb-1">Example:</div>
													<p className="text-blue-600 dark:text-blue-400">{f.example}</p>
												</div>
											</div>
										</div>
									)}

									{f.notes && (
										<p className="text-xs text-gray-500 italic">Note: {f.notes}</p>
									)}
								</div>
							</CardContent>
						</Card>
					))}
				</div>
			) : (
				<Card className="border-dashed border-2">
					<CardContent className="py-12 text-center">
						<Calculator className="h-12 w-12 text-gray-400 mx-auto mb-4" />
						<h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
							{searchQuery || filterCategory !== "all" || showFavoritesOnly
								? "No formulas match your filters"
								: "No formulas yet"}
						</h3>
						<p className="text-gray-600 dark:text-gray-400 mb-4">
							{searchQuery || filterCategory !== "all" || showFavoritesOnly
								? "Try adjusting your search or filters"
								: "Start building your formula library"}
						</p>
						{!searchQuery && filterCategory === "all" && !showFavoritesOnly && (
							<Button onClick={() => setIsAdding(true)} variant="outline">
								<Plus className="h-5 w-5 mr-2" />
								Add Your First Formula
							</Button>
						)}
					</CardContent>
				</Card>
			)}

			{formulas.length > 0 && (
				<div className="text-center text-sm text-gray-500">
					Showing {filteredFormulas.length} of {formulas.length} formulas
					{favoriteCount > 0 && ` • ${favoriteCount} favorited`}
				</div>
			)}
		</div>
	);
}
