import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import "@testing-library/jest-dom";
import { StudyPlans } from "./StudyPlans";

// Mock toast
vi.mock("sonner", () => ({
	toast: {
		success: vi.fn(),
		error: vi.fn(),
	},
}));

describe("StudyPlans", () => {
	beforeEach(() => {
		vi.clearAllMocks();
	});

	describe("Plan Creation View", () => {
		it("should render the plan creation form initially", () => {
			render(<StudyPlans />);

			expect(screen.getByText("Create Auto-Generated Study Plan")).toBeInTheDocument();
			expect(screen.getByLabelText("Plan Name")).toBeInTheDocument();
			expect(screen.getByLabelText("Study Goal")).toBeInTheDocument();
			expect(screen.getByLabelText("Deadline")).toBeInTheDocument();
			expect(screen.getByLabelText("Daily Study Time")).toBeInTheDocument();
			expect(screen.getByLabelText("Difficulty Level")).toBeInTheDocument();
		});

		it("should allow entering a plan name", () => {
			render(<StudyPlans />);

			const planNameInput = screen.getByLabelText("Plan Name") as HTMLInputElement;
			fireEvent.change(planNameInput, { target: { value: "Final Exam Prep" } });

			expect(planNameInput.value).toBe("Final Exam Prep");
		});

		it("should allow setting a deadline", () => {
			render(<StudyPlans />);

			const deadlineInput = screen.getByLabelText("Deadline") as HTMLInputElement;
			const futureDate = "2025-12-31";
			fireEvent.change(deadlineInput, { target: { value: futureDate } });

			expect(deadlineInput.value).toBe(futureDate);
		});

		it("should allow adding subjects", async () => {
			const { toast } = await import("sonner");

			render(<StudyPlans />);

			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			const addButton = screen.getByRole("button", { name: "" }); // Plus button

			fireEvent.change(subjectInput, { target: { value: "Mathematics" } });
			fireEvent.click(addButton);

			expect(toast.success).toHaveBeenCalledWith("Added Mathematics");
			expect(screen.getByText("Mathematics")).toBeInTheDocument();
			expect(screen.getByText("medium priority")).toBeInTheDocument();
		});

		it("should display added subjects with priority", async () => {
			const { toast } = await import("sonner");

			render(<StudyPlans />);

			// Add a subject
			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			const addButton = screen.getByRole("button", { name: "" });

			fireEvent.change(subjectInput, { target: { value: "Physics" } });
			fireEvent.click(addButton);

			// Verify Physics was added
			expect(toast.success).toHaveBeenCalledWith("Added Physics");
			expect(screen.getByText("Physics")).toBeInTheDocument();
			expect(screen.getByText("medium priority")).toBeInTheDocument();
		});

		it("should disable generate button when required fields are missing", () => {
			render(<StudyPlans />);

			const generateButton = screen.getByRole("button", { name: /Generate Study Plan/i });
			expect(generateButton).toBeDisabled();
		});

		it("should enable generate button when all required fields are filled", () => {
			render(<StudyPlans />);

			const planNameInput = screen.getByLabelText("Plan Name");
			fireEvent.change(planNameInput, { target: { value: "Test Plan" } });

			const deadlineInput = screen.getByLabelText("Deadline");
			fireEvent.change(deadlineInput, { target: { value: "2025-12-31" } });

			// Add a subject
			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			const addButton = screen.getByRole("button", { name: "" });
			fireEvent.change(subjectInput, { target: { value: "Science" } });
			fireEvent.click(addButton);

			const generateButton = screen.getByRole("button", { name: /Generate Study Plan/i });
			expect(generateButton).not.toBeDisabled();
		});

		it("should generate a study plan successfully", async () => {
			const { toast } = await import("sonner");

			render(<StudyPlans />);

			// Fill in plan name
			const planNameInput = screen.getByLabelText("Plan Name");
			fireEvent.change(planNameInput, { target: { value: "SAT Prep" } });

			// Set deadline
			const deadlineInput = screen.getByLabelText("Deadline");
			fireEvent.change(deadlineInput, { target: { value: "2025-12-31" } });

			// Add a subject
			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			const addButton = screen.getByRole("button", { name: "" });
			fireEvent.change(subjectInput, { target: { value: "Math" } });
			fireEvent.click(addButton);

			// Generate plan
			const generateButton = screen.getByRole("button", { name: /Generate Study Plan/i });
			fireEvent.click(generateButton);

			// Should show generating state
			expect(screen.getByText(/Generating Your Study Plan/i)).toBeInTheDocument();

			// Wait for plan to be generated
			await waitFor(
				() => {
					expect(screen.getByText("SAT Prep")).toBeInTheDocument();
				},
				{ timeout: 3000 }
			);

			expect(toast.success).toHaveBeenCalledWith("Study plan generated successfully!");
		});
	});

	describe("Active Plan View", () => {
		const setupActivePlan = async () => {
			render(<StudyPlans />);

			// Create a plan
			fireEvent.change(screen.getByLabelText("Plan Name"), { target: { value: "Test Plan" } });
			fireEvent.change(screen.getByLabelText("Deadline"), { target: { value: "2025-12-31" } });

			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			fireEvent.change(subjectInput, { target: { value: "Science" } });
			fireEvent.click(screen.getByRole("button", { name: "" }));

			fireEvent.click(screen.getByRole("button", { name: /Generate Study Plan/i }));

			await waitFor(
				() => {
					expect(screen.getByText("Test Plan")).toBeInTheDocument();
				},
				{ timeout: 3000 }
			);
		};

		it("should display plan overview after generation", async () => {
			await setupActivePlan();

			expect(screen.getByText("Test Plan")).toBeInTheDocument();
			expect(screen.getByText("Overall Progress")).toBeInTheDocument();
			expect(screen.getByText("Current Day")).toBeInTheDocument();
			expect(screen.getByText("Days Left")).toBeInTheDocument();
			expect(screen.getByText("Subjects")).toBeInTheDocument();
			expect(screen.getByText("Weak Areas")).toBeInTheDocument();
		});

		it("should display today's tasks", async () => {
			await setupActivePlan();

			expect(screen.getByText("Today's Study Tasks")).toBeInTheDocument();
			expect(screen.getByText(/Complete/)).toBeInTheDocument();
		});

		it("should allow toggling task completion", async () => {
			await setupActivePlan();

			// Find all circle buttons (task completion toggles)
			const taskButtons = screen.getAllByRole("button").filter((btn) => {
				const svg = btn.querySelector("svg");
				return svg && (svg.classList.contains("lucide-circle") || svg.classList.contains("lucide-check-circle-2"));
			});

			if (taskButtons.length > 0) {
				const initialCompletedCount = screen.getByText(/completed/).textContent?.match(/(\d+) completed/)?.[1];

				fireEvent.click(taskButtons[0]);

				// Progress should update
				await waitFor(() => {
					const newCompletedCount = screen.getByText(/completed/).textContent?.match(/(\d+) completed/)?.[1];
					expect(newCompletedCount).not.toBe(initialCompletedCount);
				});
			}
		});

		it("should display subject mastery section", async () => {
			await setupActivePlan();

			expect(screen.getByText("Subject Mastery")).toBeInTheDocument();
			// Science appears in multiple places (badge and subject name)
			const scienceElements = screen.getAllByText("Science");
			expect(scienceElements.length).toBeGreaterThan(0);
		});

		it("should show completion message when all tasks are done", async () => {
			await setupActivePlan();

			// Complete all tasks
			const taskButtons = screen.getAllByRole("button").filter((btn) => {
				const svg = btn.querySelector("svg");
				return svg && svg.classList.contains("lucide-circle");
			});

			// Click all incomplete tasks
			for (const button of taskButtons) {
				fireEvent.click(button);
			}

			// Should show completion message
			await waitFor(() => {
				const completionMessage = screen.queryByText(/All tasks completed/i);
				if (completionMessage) {
					expect(completionMessage).toBeInTheDocument();
				}
			});
		});

		it("should allow creating a new plan from active view", async () => {
			await setupActivePlan();

			const newPlanButton = screen.getByRole("button", { name: /New Plan/i });
			fireEvent.click(newPlanButton);

			// Should return to creation view
			expect(screen.getByText("Create Auto-Generated Study Plan")).toBeInTheDocument();
		});

		it("should display weak areas when subjects have low mastery", async () => {
			await setupActivePlan();

			// The initial mastery is 0, so all subjects should be in weak areas
			const weakAreasSection = screen.queryByText("Areas Needing Focus");

			// Weak areas should appear if any subjects have mastery < 50%
			if (weakAreasSection) {
				expect(weakAreasSection).toBeInTheDocument();
			}
		});
	});

	describe("Subject Priority", () => {
		it("should display priority indicators correctly", async () => {
			render(<StudyPlans />);

			// Add subjects with different priorities
			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			const addButton = screen.getByRole("button", { name: "" });

			fireEvent.change(subjectInput, { target: { value: "High Priority Subject" } });
			fireEvent.click(addButton);

			// Should show priority badge
			expect(screen.getByText(/priority/)).toBeInTheDocument();
		});
	});

	describe("Task Types", () => {
		it("should generate tasks with subjects", async () => {
			render(<StudyPlans />);

			fireEvent.change(screen.getByLabelText("Plan Name"), { target: { value: "Chemistry Plan" } });
			fireEvent.change(screen.getByLabelText("Deadline"), { target: { value: "2025-12-31" } });

			const subjectInput = screen.getByPlaceholderText(/Mathematics, Biology, History/);
			fireEvent.change(subjectInput, { target: { value: "Chemistry" } });
			fireEvent.click(screen.getByRole("button", { name: "" }));

			fireEvent.click(screen.getByRole("button", { name: /Generate Study Plan/i }));

			await waitFor(
				() => {
					expect(screen.getByText("Chemistry Plan")).toBeInTheDocument();
				},
				{ timeout: 3000 }
			);

			// Tasks should be generated (they have types like study, practice, review, test)
			// We can verify that tasks exist by checking for the subject name in the tasks
			const chemistryElements = screen.getAllByText("Chemistry");
			expect(chemistryElements.length).toBeGreaterThan(0);
		});
	});
});
