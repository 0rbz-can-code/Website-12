import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, BookOpen, Target, CheckCircle2, Circle, TrendingUp, Sparkles, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { StudyPlanORM, type StudyPlanModel, StudyPlanGoal } from "@/components/data/orm/orm_study_plan";
import { StudyPlanTaskORM, type StudyPlanTaskModel, StudyPlanTaskTaskType } from "@/components/data/orm/orm_study_plan_task";
import { APP_CONFIG } from "@/main";

type DifficultyLevel = "beginner" | "intermediate" | "advanced";
type StudyGoal = "exam-prep" | "new-subject" | "review" | "daily-practice";

interface Subject {
	id: string;
	name: string;
	priority: "high" | "medium" | "low";
	mastery: number;
}

interface DailyTask {
	id: string;
	subject: string;
	topic: string;
	duration: number;
	completed: boolean;
	type: "study" | "practice" | "review" | "test";
}

interface StudyPlan {
	id: string;
	name: string;
	goal: StudyGoal;
	deadline: string;
	subjects: Subject[];
	dailyTasks: Map<string, DailyTask[]>;
	currentDay: number;
	totalDays: number;
	overallProgress: number;
	weakAreas: string[];
	createdAt: Date;
}

// Map between UI types and ORM enums
const goalToEnum: Record<StudyGoal, StudyPlanGoal> = {
	"exam-prep": StudyPlanGoal.ExamPrep,
	"new-subject": StudyPlanGoal.NewSubject,
	"review": StudyPlanGoal.Review,
	"daily-practice": StudyPlanGoal.DailyPractice,
};

const enumToGoal: Record<StudyPlanGoal, StudyGoal> = {
	[StudyPlanGoal.Unspecified]: "exam-prep",
	[StudyPlanGoal.ExamPrep]: "exam-prep",
	[StudyPlanGoal.NewSubject]: "new-subject",
	[StudyPlanGoal.Review]: "review",
	[StudyPlanGoal.DailyPractice]: "daily-practice",
};

const taskTypeToEnum: Record<DailyTask["type"], StudyPlanTaskTaskType> = {
	"study": StudyPlanTaskTaskType.Study,
	"practice": StudyPlanTaskTaskType.Practice,
	"review": StudyPlanTaskTaskType.Review,
	"test": StudyPlanTaskTaskType.Test,
};

const enumToTaskType: Record<StudyPlanTaskTaskType, DailyTask["type"]> = {
	[StudyPlanTaskTaskType.Unspecified]: "study",
	[StudyPlanTaskTaskType.Study]: "study",
	[StudyPlanTaskTaskType.Practice]: "practice",
	[StudyPlanTaskTaskType.Review]: "review",
	[StudyPlanTaskTaskType.Test]: "test",
};

export function StudyPlans() {
	const [activePlan, setActivePlan] = useState<StudyPlan | null>(null);
	const [savedPlans, setSavedPlans] = useState<StudyPlanModel[]>([]);
	const [isCreating, setIsCreating] = useState(false);
	const [isGenerating, setIsGenerating] = useState(false);
	const [loading, setLoading] = useState(true);

	// Plan creation form state
	const [planName, setPlanName] = useState("");
	const [studyGoal, setStudyGoal] = useState<StudyGoal>("exam-prep");
	const [deadline, setDeadline] = useState("");
	const [subjects, setSubjects] = useState<Subject[]>([]);
	const [newSubjectName, setNewSubjectName] = useState("");
	const [subjectPriority, setSubjectPriority] = useState<"high" | "medium" | "low">("medium");
	const [dailyStudyTime, setDailyStudyTime] = useState("120");
	const [difficultyLevel, setDifficultyLevel] = useState<DifficultyLevel>("intermediate");

	const userId = APP_CONFIG.userId || "demo-user";

	// Load saved plans on mount
	useEffect(() => {
		loadSavedPlans();
	}, []);

	const loadSavedPlans = async () => {
		try {
			setLoading(true);
			const planOrm = StudyPlanORM.getInstance();
			const plans = await planOrm.getStudyPlanByUserId(userId);
			setSavedPlans(plans);

			// Auto-load most recent plan
			if (plans.length > 0 && !activePlan) {
				await loadPlan(plans[0]);
			}
		} catch (error) {
			console.error("Error loading study plans:", error);
		} finally {
			setLoading(false);
		}
	};

	const loadPlan = async (planModel: StudyPlanModel) => {
		try {
			const taskOrm = StudyPlanTaskORM.getInstance();
			const tasks = await taskOrm.getStudyPlanTaskByStudyPlanId(planModel.id);

			// Reconstruct the daily tasks map
			const dailyTasks = new Map<string, DailyTask[]>();
			tasks.forEach((task) => {
				const dayKey = `day-${task.day_number}`;
				if (!dailyTasks.has(dayKey)) {
					dailyTasks.set(dayKey, []);
				}
				dailyTasks.get(dayKey)!.push({
					id: task.id,
					subject: task.subject,
					topic: task.topic,
					duration: task.duration,
					completed: task.completed,
					type: enumToTaskType[task.task_type],
				});
			});

			const plan: StudyPlan = {
				id: planModel.id,
				name: planModel.name,
				goal: enumToGoal[planModel.goal],
				deadline: planModel.deadline,
				subjects: JSON.parse(planModel.subjects),
				dailyTasks,
				currentDay: planModel.current_day,
				totalDays: planModel.total_days,
				overallProgress: planModel.overall_progress,
				weakAreas: planModel.weak_areas ? JSON.parse(planModel.weak_areas) : [],
				createdAt: new Date(parseInt(planModel.create_time) * 1000),
			};

			setActivePlan(plan);
			setIsCreating(false);
		} catch (error) {
			console.error("Error loading plan:", error);
			toast.error("Failed to load plan");
		}
	};

	const addSubject = () => {
		if (!newSubjectName.trim()) {
			toast.error("Please enter a subject name");
			return;
		}

		const newSubject: Subject = {
			id: Date.now().toString(),
			name: newSubjectName,
			priority: subjectPriority,
			mastery: 0,
		};

		setSubjects([...subjects, newSubject]);
		setNewSubjectName("");
		toast.success(`Added ${newSubjectName}`);
	};

	const removeSubject = (id: string) => {
		setSubjects(subjects.filter(s => s.id !== id));
		toast.success("Subject removed");
	};

	const generateStudyPlan = async () => {
		if (!planName.trim()) {
			toast.error("Please enter a plan name");
			return;
		}

		if (!deadline) {
			toast.error("Please select a deadline");
			return;
		}

		if (subjects.length === 0) {
			toast.error("Please add at least one subject");
			return;
		}

		setIsGenerating(true);

		try {
			const daysUntilDeadline = Math.ceil((new Date(deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
			const dailyTasks = generateDailyTasks(subjects, daysUntilDeadline, parseInt(dailyStudyTime), studyGoal, difficultyLevel);

			// Save to database
			const planOrm = StudyPlanORM.getInstance();
			const taskOrm = StudyPlanTaskORM.getInstance();

			const newPlanData: Partial<StudyPlanModel> = {
				user_id: userId,
				name: planName,
				goal: goalToEnum[studyGoal],
				deadline,
				subjects: JSON.stringify(subjects),
				current_day: 1,
				total_days: daysUntilDeadline,
				overall_progress: 0,
				weak_areas: JSON.stringify(identifyWeakAreas(subjects)),
			};

			const [createdPlan] = await planOrm.insertStudyPlan([newPlanData as StudyPlanModel]);

			// Save all tasks
			const tasksToInsert: Partial<StudyPlanTaskModel>[] = [];
			dailyTasks.forEach((dayTasks, dayKey) => {
				const dayNumber = parseInt(dayKey.replace("day-", ""));
				dayTasks.forEach((task) => {
					tasksToInsert.push({
						study_plan_id: createdPlan.id,
						user_id: userId,
						day_number: dayNumber,
						subject: task.subject,
						topic: task.topic,
						duration: task.duration,
						completed: false,
						task_type: taskTypeToEnum[task.type],
					});
				});
			});

			await taskOrm.insertStudyPlanTask(tasksToInsert as StudyPlanTaskModel[]);

			toast.success("Study plan generated and saved successfully!");

			// Load the newly created plan
			await loadSavedPlans();
			await loadPlan(createdPlan);

			// Reset form
			setPlanName("");
			setSubjects([]);
			setDeadline("");
		} catch (error) {
			console.error("Error generating study plan:", error);
			toast.error("Failed to generate study plan");
		} finally {
			setIsGenerating(false);
		}
	};

	const generateDailyTasks = (
		subjectList: Subject[],
		days: number,
		dailyMinutes: number,
		goal: StudyGoal,
		difficulty: DifficultyLevel
	): Map<string, DailyTask[]> => {
		const tasks = new Map<string, DailyTask[]>();

		// Sort subjects by priority
		const sortedSubjects = [...subjectList].sort((a, b) => {
			const priorityOrder = { high: 0, medium: 1, low: 2 };
			return priorityOrder[a.priority] - priorityOrder[b.priority];
		});

		for (let day = 1; day <= days; day++) {
			const dayTasks: DailyTask[] = [];
			let remainingMinutes = dailyMinutes;

			// Distribute time across subjects based on priority and day
			sortedSubjects.forEach((subject, index) => {
				if (remainingMinutes <= 0) return;

				// Determine task type based on day cycle
				let taskType: DailyTask["type"];
				const dayMod = day % 7;
				if (dayMod === 0 || dayMod === 6) {
					taskType = "review";
				} else if (dayMod === 5) {
					taskType = "test";
				} else if (day % 2 === 0) {
					taskType = "practice";
				} else {
					taskType = "study";
				}

				// Allocate time based on priority
				let taskDuration: number;
				if (subject.priority === "high") {
					taskDuration = Math.min(remainingMinutes, Math.floor(dailyMinutes * 0.4));
				} else if (subject.priority === "medium") {
					taskDuration = Math.min(remainingMinutes, Math.floor(dailyMinutes * 0.3));
				} else {
					taskDuration = Math.min(remainingMinutes, Math.floor(dailyMinutes * 0.2));
				}

				if (taskDuration >= 15) {
					const topic = generateTopicName(subject.name, taskType, day);
					dayTasks.push({
						id: `${day}-${subject.id}-${taskType}`,
						subject: subject.name,
						topic,
						duration: taskDuration,
						completed: false,
						type: taskType,
					});
					remainingMinutes -= taskDuration;
				}
			});

			// Add a break if there's remaining time
			if (remainingMinutes > 10) {
				dayTasks.push({
					id: `${day}-break`,
					subject: "Break",
					topic: "Rest and review notes",
					duration: Math.min(remainingMinutes, 15),
					completed: false,
					type: "review",
				});
			}

			tasks.set(`day-${day}`, dayTasks);
		}

		return tasks;
	};

	const generateTopicName = (subject: string, taskType: DailyTask["type"], day: number): string => {
		const topicTemplates = {
			study: [
				`Introduction to ${subject} concepts`,
				`Core principles of ${subject}`,
				`Advanced ${subject} theory`,
				`${subject} fundamentals review`,
			],
			practice: [
				`${subject} practice problems`,
				`Hands-on ${subject} exercises`,
				`Applied ${subject} scenarios`,
				`${subject} problem-solving`,
			],
			review: [
				`Review ${subject} key concepts`,
				`${subject} summary and notes`,
				`${subject} concept consolidation`,
				`Quick ${subject} refresher`,
			],
			test: [
				`${subject} practice test`,
				`${subject} self-assessment`,
				`${subject} knowledge check`,
				`${subject} mock test`,
			],
		};

		const templates = topicTemplates[taskType];
		const templateIndex = (day - 1) % templates.length;
		return templates[templateIndex];
	};

	const identifyWeakAreas = (subjectList: Subject[]): string[] => {
		return subjectList
			.filter(s => s.mastery < 50)
			.map(s => s.name);
	};

	const toggleTaskComplete = async (day: string, taskId: string) => {
		if (!activePlan) return;

		const dayTasks = activePlan.dailyTasks.get(day);
		if (!dayTasks) return;

		const task = dayTasks.find(t => t.id === taskId);
		if (!task) return;

		try {
			// Update in database
			const taskOrm = StudyPlanTaskORM.getInstance();
			const [dbTask] = await taskOrm.getStudyPlanTaskById(taskId);

			if (dbTask) {
				const updated: StudyPlanTaskModel = {
					...dbTask,
					completed: !dbTask.completed,
				};
				await taskOrm.setStudyPlanTaskById(taskId, updated);
			}

			// Update local state
			const updatedTasks = dayTasks.map(t =>
				t.id === taskId ? { ...t, completed: !t.completed } : t
			);

			const updatedDailyTasks = new Map(activePlan.dailyTasks);
			updatedDailyTasks.set(day, updatedTasks);

			// Calculate overall progress
			let totalTasks = 0;
			let completedTasks = 0;
			updatedDailyTasks.forEach(tasks => {
				totalTasks += tasks.length;
				completedTasks += tasks.filter(t => t.completed).length;
			});

			const progress = Math.round((completedTasks / totalTasks) * 100);

			// Update subject mastery
			const updatedSubjects = activePlan.subjects.map(subject => {
				const subjectTasks = Array.from(updatedDailyTasks.values())
					.flat()
					.filter(t => t.subject === subject.name);
				const completedCount = subjectTasks.filter(t => t.completed).length;
				const mastery = Math.round((completedCount / subjectTasks.length) * 100);
				return { ...subject, mastery };
			});

			// Update plan in database
			const planOrm = StudyPlanORM.getInstance();
			const updatedPlan: StudyPlan = {
				...activePlan,
				dailyTasks: updatedDailyTasks,
				overallProgress: progress,
				subjects: updatedSubjects,
				weakAreas: identifyWeakAreas(updatedSubjects),
			};

			const planModel: StudyPlanModel = {
				id: updatedPlan.id,
				user_id: userId,
				name: updatedPlan.name,
				goal: goalToEnum[updatedPlan.goal],
				deadline: updatedPlan.deadline,
				subjects: JSON.stringify(updatedPlan.subjects),
				current_day: updatedPlan.currentDay,
				total_days: updatedPlan.totalDays,
				overall_progress: updatedPlan.overallProgress,
				weak_areas: JSON.stringify(updatedPlan.weakAreas),
				data_creator: "", // Will be filled by backend
				data_updater: "",
				create_time: "",
				update_time: "",
			};

			await planOrm.setStudyPlanById(updatedPlan.id, planModel);
			setActivePlan(updatedPlan);
		} catch (error) {
			console.error("Error updating task:", error);
			toast.error("Failed to update task");
		}
	};

	const deletePlan = async (planId: string) => {
		try {
			const planOrm = StudyPlanORM.getInstance();
			const taskOrm = StudyPlanTaskORM.getInstance();

			// Delete all tasks (cascade should handle this, but being explicit)
			const tasks = await taskOrm.getStudyPlanTaskByStudyPlanId(planId);
			for (const task of tasks) {
				await taskOrm.deleteStudyPlanTaskById(task.id);
			}

			// Delete plan
			await planOrm.deleteStudyPlanById(planId);

			toast.success("Study plan deleted");

			if (activePlan?.id === planId) {
				setActivePlan(null);
			}

			await loadSavedPlans();
		} catch (error) {
			console.error("Error deleting plan:", error);
			toast.error("Failed to delete plan");
		}
	};

	const getTodaysTasks = (): DailyTask[] => {
		if (!activePlan) return [];
		return activePlan.dailyTasks.get(`day-${activePlan.currentDay}`) || [];
	};

	const getTaskIcon = (type: DailyTask["type"]) => {
		switch (type) {
			case "study": return <BookOpen className="h-4 w-4" />;
			case "practice": return <Target className="h-4 w-4" />;
			case "review": return <TrendingUp className="h-4 w-4" />;
			case "test": return <CheckCircle2 className="h-4 w-4" />;
		}
	};

	const getPriorityColor = (priority: "high" | "medium" | "low") => {
		switch (priority) {
			case "high": return "bg-red-500";
			case "medium": return "bg-yellow-500";
			case "low": return "bg-green-500";
		}
	};

	if (loading) {
		return (
			<div className="flex items-center justify-center py-12">
				<div className="text-center">
					<Sparkles className="h-8 w-8 text-indigo-600 animate-spin mx-auto mb-4" />
					<p className="text-gray-600">Loading your study plans...</p>
				</div>
			</div>
		);
	}

	if (isCreating || !activePlan) {
		return (
			<div className="space-y-6 animate-fade-in">
				<Card className="shadow-xl border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-br from-white via-pink-50 to-white dark:from-gray-900 dark:via-pink-950 dark:to-gray-900">
					<CardHeader>
						<CardTitle className="flex items-center gap-3 text-2xl font-bold">
							<div className="p-2 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg shadow-lg">
								<Sparkles className="h-6 w-6 text-white" />
							</div>
							Create Auto-Generated Study Plan
						</CardTitle>
						<CardDescription className="text-base mt-2">
							Build a personalized learning schedule that adapts to your goals and deadlines. The AI analyzes your subjects and creates a day-by-day plan with optimal study sessions.
						</CardDescription>
					</CardHeader>
					<CardContent className="space-y-4">
						{/* Plan Name */}
						<div className="space-y-2">
							<Label htmlFor="plan-name" className="text-base font-medium">
								Plan Name
							</Label>
							<Input
								id="plan-name"
								placeholder="e.g., Final Exam Preparation, Learn Python, SAT Prep"
								value={planName}
								onChange={(e) => setPlanName(e.target.value)}
								disabled={isGenerating}
							/>
						</div>

						{/* Goal and Deadline */}
						<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
							<div className="space-y-2">
								<Label htmlFor="study-goal" className="text-base font-medium">
									Study Goal
								</Label>
								<Select
									value={studyGoal}
									onValueChange={(value) => setStudyGoal(value as StudyGoal)}
									disabled={isGenerating}
								>
									<SelectTrigger id="study-goal">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="exam-prep">Exam Preparation</SelectItem>
										<SelectItem value="new-subject">Learn New Subject</SelectItem>
										<SelectItem value="review">Review & Refresh</SelectItem>
										<SelectItem value="daily-practice">Daily Practice</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="deadline" className="text-base font-medium">
									Deadline
								</Label>
								<Input
									id="deadline"
									type="date"
									value={deadline}
									onChange={(e) => setDeadline(e.target.value)}
									disabled={isGenerating}
									min={new Date().toISOString().split('T')[0]}
								/>
							</div>
						</div>

						{/* Study Time and Difficulty */}
						<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
							<div className="space-y-2">
								<Label htmlFor="daily-time" className="text-base font-medium">
									Daily Study Time
								</Label>
								<Select
									value={dailyStudyTime}
									onValueChange={setDailyStudyTime}
									disabled={isGenerating}
								>
									<SelectTrigger id="daily-time">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="30">30 minutes</SelectItem>
										<SelectItem value="60">1 hour</SelectItem>
										<SelectItem value="90">1.5 hours</SelectItem>
										<SelectItem value="120">2 hours</SelectItem>
										<SelectItem value="180">3 hours</SelectItem>
										<SelectItem value="240">4 hours</SelectItem>
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-2">
								<Label htmlFor="difficulty" className="text-base font-medium">
									Difficulty Level
								</Label>
								<Select
									value={difficultyLevel}
									onValueChange={(value) => setDifficultyLevel(value as DifficultyLevel)}
									disabled={isGenerating}
								>
									<SelectTrigger id="difficulty">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="beginner">Beginner</SelectItem>
										<SelectItem value="intermediate">Intermediate</SelectItem>
										<SelectItem value="advanced">Advanced</SelectItem>
									</SelectContent>
								</Select>
							</div>
						</div>

						{/* Subjects */}
						<div className="space-y-2">
							<Label className="text-base font-medium">
								Subjects to Study
							</Label>
							<div className="flex gap-2">
								<Input
									placeholder="e.g., Mathematics, Biology, History"
									value={newSubjectName}
									onChange={(e) => setNewSubjectName(e.target.value)}
									disabled={isGenerating}
									onKeyPress={(e) => e.key === 'Enter' && addSubject()}
								/>
								<Select
									value={subjectPriority}
									onValueChange={(value) => setSubjectPriority(value as "high" | "medium" | "low")}
									disabled={isGenerating}
								>
									<SelectTrigger className="w-32">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="high">High</SelectItem>
										<SelectItem value="medium">Medium</SelectItem>
										<SelectItem value="low">Low</SelectItem>
									</SelectContent>
								</Select>
								<Button onClick={addSubject} disabled={isGenerating} variant="outline">
									<Plus className="h-4 w-4" />
								</Button>
							</div>

							{subjects.length > 0 && (
								<div className="space-y-2 mt-3">
									{subjects.map(subject => (
										<div key={subject.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
											<div className="flex items-center gap-2">
												<div className={`w-2 h-2 rounded-full ${getPriorityColor(subject.priority)}`} />
												<span className="font-medium">{subject.name}</span>
												<Badge variant="outline" className="text-xs">
													{subject.priority} priority
												</Badge>
											</div>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => removeSubject(subject.id)}
												disabled={isGenerating}
											>
												<Trash2 className="h-4 w-4" />
											</Button>
										</div>
									))}
								</div>
							)}
						</div>

						{/* Generate Button */}
						<Button
							onClick={generateStudyPlan}
							disabled={isGenerating || !planName || !deadline || subjects.length === 0}
							className="w-full bg-gradient-to-r from-pink-600 via-purple-600 to-pink-700 hover:from-pink-700 hover:via-purple-700 hover:to-pink-800 shadow-xl hover:shadow-2xl transition-all duration-300 text-lg font-semibold"
							size="lg"
						>
							{isGenerating ? (
								<>
									<Sparkles className="h-6 w-6 mr-2 animate-spin" />
									Generating Your Study Plan...
								</>
							) : (
								<>
									<Sparkles className="h-6 w-6 mr-2" />
									Generate Study Plan
								</>
							)}
						</Button>

						{!activePlan && subjects.length === 0 && (
							<p className="text-sm text-center text-gray-500">
								Add at least one subject to get started
							</p>
						)}
					</CardContent>
				</Card>

				{/* Saved Plans */}
				{savedPlans.length > 0 && (
					<Card>
						<CardHeader>
							<CardTitle>Your Saved Plans</CardTitle>
							<CardDescription>Continue with an existing study plan</CardDescription>
						</CardHeader>
						<CardContent>
							<div className="space-y-2">
								{savedPlans.map((plan) => (
									<div
										key={plan.id}
										className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
									>
										<div className="flex-1 cursor-pointer" onClick={() => loadPlan(plan)}>
											<div className="font-medium">{plan.name}</div>
											<div className="text-sm text-gray-600">
												{plan.total_days} days • {plan.overall_progress}% complete
											</div>
										</div>
										<div className="flex gap-2">
											<Button
												variant="outline"
												size="sm"
												onClick={() => loadPlan(plan)}
											>
												Open
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => deletePlan(plan.id)}
												className="text-red-600 hover:text-red-700"
											>
												<Trash2 className="h-4 w-4" />
											</Button>
										</div>
									</div>
								))}
							</div>
						</CardContent>
					</Card>
				)}
			</div>
		);
	}

	// Active Plan View
	const todaysTasks = getTodaysTasks();
	const completedToday = todaysTasks.filter(t => t.completed).length;
	const totalToday = todaysTasks.length;
	const todayProgress = totalToday > 0 ? (completedToday / totalToday) * 100 : 0;

	return (
		<div className="space-y-4">
			{/* Plan Overview */}
			<Card>
				<CardHeader>
					<div className="flex items-center justify-between">
						<div>
							<CardTitle className="flex items-center gap-2">
								<Calendar className="h-5 w-5 text-indigo-600" />
								{activePlan.name}
							</CardTitle>
							<CardDescription>
								Day {activePlan.currentDay} of {activePlan.totalDays} • {activePlan.goal}
							</CardDescription>
						</div>
						<Button variant="outline" onClick={() => {
							setActivePlan(null);
							setIsCreating(true);
						}}>
							New Plan
						</Button>
					</div>
				</CardHeader>
				<CardContent className="space-y-4">
					<div className="space-y-2">
						<div className="flex items-center justify-between text-sm">
							<span>Overall Progress</span>
							<span className="font-medium">{activePlan.overallProgress}%</span>
						</div>
						<Progress value={activePlan.overallProgress} className="h-2" />
					</div>

					<div className="grid grid-cols-2 md:grid-cols-4 gap-4">
						<div className="text-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
							<div className="text-2xl font-bold text-indigo-600">{activePlan.currentDay}</div>
							<div className="text-xs text-gray-600 dark:text-gray-400">Current Day</div>
						</div>
						<div className="text-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
							<div className="text-2xl font-bold text-indigo-600">{activePlan.totalDays - activePlan.currentDay}</div>
							<div className="text-xs text-gray-600 dark:text-gray-400">Days Left</div>
						</div>
						<div className="text-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
							<div className="text-2xl font-bold text-indigo-600">{activePlan.subjects.length}</div>
							<div className="text-xs text-gray-600 dark:text-gray-400">Subjects</div>
						</div>
						<div className="text-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
							<div className="text-2xl font-bold text-indigo-600">{activePlan.weakAreas.length}</div>
							<div className="text-xs text-gray-600 dark:text-gray-400">Weak Areas</div>
						</div>
					</div>
				</CardContent>
			</Card>

			{/* Today's Tasks */}
			<Card>
				<CardHeader>
					<CardTitle className="flex items-center gap-2">
						<Clock className="h-5 w-5 text-indigo-600" />
						Today's Study Tasks
					</CardTitle>
					<CardDescription>
						Complete {totalToday} tasks • {completedToday} completed
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					<Progress value={todayProgress} className="h-2" />

					<div className="space-y-2">
						{todaysTasks.map(task => (
							<div
								key={task.id}
								className={`flex items-center gap-3 p-4 rounded-lg border transition-all ${
									task.completed
										? "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800"
										: "bg-white dark:bg-gray-950 hover:bg-gray-50 dark:hover:bg-gray-900"
								}`}
							>
								<Button
									variant="ghost"
									size="sm"
									onClick={() => toggleTaskComplete(`day-${activePlan.currentDay}`, task.id)}
									className="p-0 h-auto"
								>
									{task.completed ? (
										<CheckCircle2 className="h-6 w-6 text-green-600" />
									) : (
										<Circle className="h-6 w-6 text-gray-400" />
									)}
								</Button>

								<div className="flex-1">
									<div className="flex items-center gap-2">
										{getTaskIcon(task.type)}
										<span className={`font-medium ${task.completed ? "line-through text-gray-500" : ""}`}>
											{task.topic}
										</span>
									</div>
									<div className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2 mt-1">
										<Badge variant="outline" className="text-xs">{task.subject}</Badge>
										<span>•</span>
										<span>{task.duration} min</span>
										<span>•</span>
										<span className="capitalize">{task.type}</span>
									</div>
								</div>
							</div>
						))}
					</div>

					{completedToday === totalToday && totalToday > 0 && (
						<div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
							<p className="text-green-600 dark:text-green-400 font-medium">
								All tasks completed! Great work today!
							</p>
						</div>
					)}
				</CardContent>
			</Card>

			{/* Subject Progress */}
			<Card>
				<CardHeader>
					<CardTitle>Subject Mastery</CardTitle>
					<CardDescription>Track your progress across all subjects</CardDescription>
				</CardHeader>
				<CardContent>
					<div className="space-y-4">
						{activePlan.subjects.map(subject => (
							<div key={subject.id} className="space-y-2">
								<div className="flex items-center justify-between">
									<div className="flex items-center gap-2">
										<div className={`w-2 h-2 rounded-full ${getPriorityColor(subject.priority)}`} />
										<span className="font-medium">{subject.name}</span>
									</div>
									<span className="text-sm font-medium">{subject.mastery}%</span>
								</div>
								<Progress value={subject.mastery} className="h-2" />
							</div>
						))}
					</div>

					{activePlan.weakAreas.length > 0 && (
						<div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
							<div className="flex items-center gap-2 mb-2">
								<TrendingUp className="h-4 w-4 text-yellow-600" />
								<span className="font-medium text-yellow-600">Areas Needing Focus</span>
							</div>
							<div className="flex flex-wrap gap-2">
								{activePlan.weakAreas.map(area => (
									<Badge key={area} variant="outline" className="bg-yellow-100 dark:bg-yellow-900">
										{area}
									</Badge>
								))}
							</div>
						</div>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
