import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Play, Pause, Square, Moon, Sun, Volume2, VolumeX } from "lucide-react";
import { StudySessionORM, type StudySessionModel, StudySessionFocusMode } from "@/components/data/orm/orm_study_session";
import { APP_CONFIG } from "@/main";
import { toast } from "sonner";
import { MilestoneCelebration } from "@/components/MilestoneCelebration";

type AudioChoice = "none" | "rain" | "cafe" | "nature";

export function StudyRoom() {
	const [isActive, setIsActive] = useState(false);
	const [isPaused, setIsPaused] = useState(false);
	const [elapsedTime, setElapsedTime] = useState(0);
	const [focusMode, setFocusMode] = useState<StudySessionFocusMode>(StudySessionFocusMode.Day);
	const [audioChoice, setAudioChoice] = useState<AudioChoice>("none");
	const [targetMinutes, setTargetMinutes] = useState(25);
	const [sessionId, setSessionId] = useState<string | null>(null);
	const [showCelebration, setShowCelebration] = useState(false);
	const [celebratedAt15, setCelebratedAt15] = useState(false);

	const intervalRef = useRef<NodeJS.Timeout | null>(null);
	const startTimeRef = useRef<number>(0);
	const userId = APP_CONFIG.userId || "demo-user";

	useEffect(() => {
		if (isActive && !isPaused) {
			intervalRef.current = setInterval(() => {
				const newElapsedTime = Math.floor((Date.now() - startTimeRef.current) / 1000);
				setElapsedTime(newElapsedTime);

				// Check for 15-minute milestone (900 seconds)
				const minutes = Math.floor(newElapsedTime / 60);
				if (minutes >= 15 && !celebratedAt15) {
					setCelebratedAt15(true);
					setShowCelebration(true);
				}
			}, 1000);
		} else {
			if (intervalRef.current) {
				clearInterval(intervalRef.current);
			}
		}

		return () => {
			if (intervalRef.current) {
				clearInterval(intervalRef.current);
			}
		};
	}, [isActive, isPaused, celebratedAt15]);

	const startSession = async () => {
		setIsActive(true);
		setIsPaused(false);
		startTimeRef.current = Date.now();
		setElapsedTime(0);
		setCelebratedAt15(false);

		try {
			const sessionOrm = StudySessionORM.getInstance();
			const newSession: Partial<StudySessionModel> = {
				user_id: userId,
				start_time: new Date().toISOString(),
				focus_mode: focusMode,
				audio_choice: audioChoice,
				completed_successfully: false,
			};
			const [created] = await sessionOrm.insertStudySession([newSession as StudySessionModel]);
			setSessionId(created.id);
		} catch (error) {
			console.error("Error starting session:", error);
		}
	};

	const pauseSession = () => {
		setIsPaused(!isPaused);
	};

	const endSession = async () => {
		setIsActive(false);
		setIsPaused(false);

		const duration = Math.floor(elapsedTime / 60);

		if (sessionId) {
			try {
				const sessionOrm = StudySessionORM.getInstance();
				const [existing] = await sessionOrm.getStudySessionById(sessionId);
				if (existing) {
					const updated: StudySessionModel = {
						...existing,
						end_time: new Date().toISOString(),
						duration,
						completed_successfully: duration >= targetMinutes * 0.8,
					};
					await sessionOrm.setStudySessionById(sessionId, updated);
					toast.success(`Study session completed! ${duration} minutes focused.`);
				}
			} catch (error) {
				console.error("Error ending session:", error);
			}
		}

		setElapsedTime(0);
		setSessionId(null);
	};

	const formatTime = (seconds: number) => {
		const mins = Math.floor(seconds / 60);
		const secs = seconds % 60;
		return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
	};

	const progressPercentage = (elapsedTime / (targetMinutes * 60)) * 100;
	const isNearComplete = progressPercentage >= 80;

	const ambientIntensity = Math.min(100, (elapsedTime / (targetMinutes * 60)) * 100);
	const roomOpacity = focusMode === StudySessionFocusMode.Night ? 0.7 - ambientIntensity * 0.003 : 1 - ambientIntensity * 0.002;

	return (
		<div className="space-y-4">
			{/* Milestone celebration overlay */}
			{showCelebration && (
				<MilestoneCelebration
					minutes={15}
					onDismiss={() => setShowCelebration(false)}
				/>
			)}

			<Card>
				<CardHeader>
					<CardTitle>AI Study Room</CardTitle>
					<CardDescription>
						Create your perfect study environment with ambient visuals and sounds
					</CardDescription>
				</CardHeader>
				<CardContent className="space-y-4">
					{/* Study Room Visual */}
					<div
						className="relative rounded-lg overflow-hidden h-64 transition-all duration-1000"
						style={{
							background:
								focusMode === StudySessionFocusMode.Night
									? `linear-gradient(to bottom, #1a1a2e ${20 - ambientIntensity * 0.1}%, #16213e ${50 - ambientIntensity * 0.2}%, #0f3460)`
									: `linear-gradient(to bottom, #e0f2fe ${100 - ambientIntensity * 0.3}%, #bae6fd ${100 - ambientIntensity * 0.2}%, #7dd3fc)`,
							opacity: roomOpacity,
						}}
					>
						<div className="absolute inset-0 flex items-center justify-center">
							<div className="text-center space-y-3">
								<div
									className={`text-6xl font-bold transition-all duration-500 ${
										focusMode === StudySessionFocusMode.Night
											? "text-indigo-200"
											: "text-indigo-600"
									}`}
								>
									{formatTime(elapsedTime)}
								</div>
								<div
									className={`text-lg font-medium ${
										focusMode === StudySessionFocusMode.Night ? "text-indigo-300" : "text-indigo-500"
									}`}
								>
									{isActive
										? isPaused
											? "Paused"
											: "Studying..."
										: "Ready to focus"}
								</div>
								{isActive && (
									<Progress
										value={Math.min(progressPercentage, 100)}
										className="w-64 h-2 mx-auto"
									/>
								)}
							</div>
						</div>

						{/* Ambient animations */}
						{isActive && !isPaused && (
							<>
								<div
									className="absolute top-10 right-10 w-32 h-32 rounded-full opacity-20 animate-pulse"
									style={{
										background:
											focusMode === StudySessionFocusMode.Night
												? "radial-gradient(circle, #818cf8, transparent)"
												: "radial-gradient(circle, #fbbf24, transparent)",
										animationDuration: `${4 + ambientIntensity * 0.02}s`,
									}}
								/>
								<div
									className="absolute bottom-10 left-10 w-40 h-40 rounded-full opacity-15 animate-pulse"
									style={{
										background:
											focusMode === StudySessionFocusMode.Night
												? "radial-gradient(circle, #a78bfa, transparent)"
												: "radial-gradient(circle, #60a5fa, transparent)",
										animationDuration: `${5 + ambientIntensity * 0.03}s`,
									}}
								/>
							</>
						)}
					</div>

					{/* Controls */}
					<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div className="space-y-3">
							<div className="flex items-center justify-between">
								<Label htmlFor="focus-mode" className="text-base font-medium">
									Room Atmosphere
								</Label>
								<div className="flex items-center gap-2">
									<Sun className="h-4 w-4 text-yellow-500" />
									<Switch
										id="focus-mode"
										checked={focusMode === StudySessionFocusMode.Night}
										onCheckedChange={(checked) =>
											setFocusMode(checked ? StudySessionFocusMode.Night : StudySessionFocusMode.Day)
										}
										disabled={isActive}
									/>
									<Moon className="h-4 w-4 text-indigo-500" />
								</div>
							</div>

							<div className="space-y-2">
								<Label htmlFor="target-time" className="text-base font-medium">
									Target Duration
								</Label>
								<Select
									value={targetMinutes.toString()}
									onValueChange={(value) => setTargetMinutes(parseInt(value))}
									disabled={isActive}
								>
									<SelectTrigger id="target-time">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="15">15 minutes</SelectItem>
										<SelectItem value="25">25 minutes (Pomodoro)</SelectItem>
										<SelectItem value="30">30 minutes</SelectItem>
										<SelectItem value="45">45 minutes</SelectItem>
										<SelectItem value="60">60 minutes</SelectItem>
										<SelectItem value="90">90 minutes</SelectItem>
									</SelectContent>
								</Select>
							</div>
						</div>

						<div className="space-y-3">
							<div className="space-y-2">
								<Label htmlFor="audio" className="text-base font-medium flex items-center gap-2">
									{audioChoice === "none" ? (
										<VolumeX className="h-4 w-4" />
									) : (
										<Volume2 className="h-4 w-4" />
									)}
									Ambient Sound
								</Label>
								<Select
									value={audioChoice}
									onValueChange={(value) => setAudioChoice(value as AudioChoice)}
									disabled={isActive}
								>
									<SelectTrigger id="audio">
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										<SelectItem value="none">No sound</SelectItem>
										<SelectItem value="rain">Rain sounds</SelectItem>
										<SelectItem value="cafe">Coffee shop ambience</SelectItem>
										<SelectItem value="nature">Nature sounds</SelectItem>
									</SelectContent>
								</Select>
							</div>
						</div>
					</div>

					{/* Action Buttons */}
					<div className="flex gap-3 justify-center pt-4">
						{!isActive ? (
							<Button
								onClick={startSession}
								size="lg"
								className="bg-indigo-600 hover:bg-indigo-700 px-8"
							>
								<Play className="h-5 w-5 mr-2" />
								Start Session
							</Button>
						) : (
							<>
								<Button onClick={pauseSession} size="lg" variant="outline" className="px-8">
									{isPaused ? (
										<>
											<Play className="h-5 w-5 mr-2" />
											Resume
										</>
									) : (
										<>
											<Pause className="h-5 w-5 mr-2" />
											Pause
										</>
									)}
								</Button>
								<Button
									onClick={endSession}
									size="lg"
									variant="destructive"
									className="px-8"
								>
									<Square className="h-5 w-5 mr-2" />
									End Session
								</Button>
							</>
						)}
					</div>

					{isNearComplete && isActive && (
						<div className="text-center">
							<p className="text-green-600 font-medium animate-pulse">
								Great work! You're almost there!
							</p>
						</div>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
