import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, FileQuestion, CheckCircle2, XCircle, Clock, ChevronDown, ChevronUp, AlertCircle, Trash2 } from "lucide-react";
import { TestORM, type TestModel, TestDifficulty } from "@/components/data/orm/orm_test";
import {
	TestQuestionORM,
	type TestQuestionModel,
	TestQuestionQuestionType,
} from "@/components/data/orm/orm_test_question";
import { FlashcardORM, FlashcardMasteryLevel } from "@/components/data/orm/orm_flashcard";
import { PerformanceMetricORM, type PerformanceMetricModel } from "@/components/data/orm/orm_performance_metric";
import { APP_CONFIG } from "@/main";
import { toast } from "sonner";

export function TestMaker() {
	const [view, setView] = useState<"create" | "take" | "results">("create");
	const [tests, setTests] = useState<TestModel[]>([]);
	const [currentTest, setCurrentTest] = useState<TestModel | null>(null);
	const [questions, setQuestions] = useState<TestQuestionModel[]>([]);
	const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
	const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
	const [showWrongAnswers, setShowWrongAnswers] = useState(false);

	// Create form state
	const [topic, setTopic] = useState("");
	const [inputText, setInputText] = useState("");
	const [difficulty, setDifficulty] = useState<TestDifficulty>(TestDifficulty.Medium);
	const [questionCount, setQuestionCount] = useState(5);
	const [useFlashcards, setUseFlashcards] = useState(false);
	const [generating, setGenerating] = useState(false);
	const [flashcardSets, setFlashcardSets] = useState<string[]>([]);
	const [selectedFlashcardSet, setSelectedFlashcardSet] = useState<string>("all-weak");

	// Manual test creation state
	const [manualTestTitle, setManualTestTitle] = useState("");
	const [manualQuestions, setManualQuestions] = useState<Array<{
		question: string;
		answer: string;
		type: TestQuestionQuestionType;
		options?: string;
	}>>([]);
	const [activeCreationTab, setActiveCreationTab] = useState("text");

	const userId = APP_CONFIG.userId || "demo-user";

	useEffect(() => {
		loadTests();
		loadFlashcardSets();
	}, []);

	const loadFlashcardSets = async () => {
		try {
			const flashcardOrm = FlashcardORM.getInstance();
			const allCards = await flashcardOrm.getFlashcardByUserId(userId);

			// Get unique topics
			const uniqueTopics = Array.from(new Set(allCards.map((card) => card.topic)));
			setFlashcardSets(uniqueTopics);
		} catch (error) {
			console.error("Error loading flashcard sets:", error);
		}
	};

	const loadTests = async () => {
		try {
			const testOrm = TestORM.getInstance();
			const allTests = await testOrm.getTestByUserId(userId);
			setTests(allTests);
		} catch (error) {
			console.error("Error loading tests:", error);
		}
	};

	const createManualTest = async () => {
		if (!manualTestTitle.trim()) {
			toast.error("Please provide a test title");
			return;
		}

		if (manualQuestions.length === 0) {
			toast.error("Please add at least one question");
			return;
		}

		// Validate all questions have content
		const invalidQuestions = manualQuestions.filter(q => !q.question.trim() || !q.answer.trim());
		if (invalidQuestions.length > 0) {
			toast.error("All questions must have both question text and an answer");
			return;
		}

		setGenerating(true);
		try {
			const testOrm = TestORM.getInstance();
			const questionOrm = TestQuestionORM.getInstance();

			// Create test
			const newTest: Partial<TestModel> = {
				user_id: userId,
				title: manualTestTitle,
				topic: "Custom Test",
				difficulty,
				question_count: manualQuestions.length,
			};

			const [createdTest] = await testOrm.insertTest([newTest as TestModel]);

			// Create questions
			const questionsToInsert: Partial<TestQuestionModel>[] = manualQuestions.map((q) => ({
				test_id: createdTest.id,
				question_type: q.type,
				question_text: q.question,
				correct_answer: q.answer,
				options: q.options || null,
			}));

			await questionOrm.insertTestQuestion(questionsToInsert as TestQuestionModel[]);
			toast.success(`Created test with ${manualQuestions.length} questions!`);

			setCurrentTest(createdTest);
			const loadedQuestions = await questionOrm.getTestQuestionByTestId(createdTest.id);
			setQuestions(loadedQuestions);
			setCurrentQuestionIndex(0);
			setUserAnswers({});
			setView("take");

			// Reset manual form
			setManualTestTitle("");
			setManualQuestions([]);
		} catch (error) {
			console.error("Error creating manual test:", error);
			toast.error("Failed to create test");
		} finally {
			setGenerating(false);
		}
	};

	const generateTest = async () => {
		if (!topic.trim() && !useFlashcards) {
			toast.error("Please provide a topic");
			return;
		}

		if (useFlashcards && !selectedFlashcardSet) {
			toast.error("Please select a flashcard set");
			return;
		}

		setGenerating(true);
		try {
			const testOrm = TestORM.getInstance();
			const questionOrm = TestQuestionORM.getInstance();

			// Create test
			const testTitle = useFlashcards
				? selectedFlashcardSet === "all-weak"
					? "All Weak Cards Test"
					: `${selectedFlashcardSet} Test`
				: `${topic} Test`;

			const testTopic = useFlashcards
				? selectedFlashcardSet === "all-weak"
					? "Mixed Topics"
					: selectedFlashcardSet
				: topic;

			const newTest: Partial<TestModel> = {
				user_id: userId,
				title: testTitle,
				topic: testTopic,
				difficulty,
				question_count: questionCount,
			};

			const [createdTest] = await testOrm.insertTest([newTest as TestModel]);

			// Generate questions
			let generatedQuestions: Partial<TestQuestionModel>[] = [];

			if (useFlashcards) {
				// Generate from selected flashcard set
				const flashcardOrm = FlashcardORM.getInstance();
				let cardsToUse;

				if (selectedFlashcardSet === "all-weak") {
					// Get all weak cards across all sets
					const learningCards = await flashcardOrm.getFlashcardByMasteryLevelUserId(
						FlashcardMasteryLevel.Learning,
						userId,
					);
					const newCards = await flashcardOrm.getFlashcardByMasteryLevelUserId(
						FlashcardMasteryLevel.NotSeen,
						userId,
					);
					cardsToUse = [...learningCards, ...newCards].slice(0, questionCount);
				} else {
					// Get cards from specific set
					const allCardsInSet = await flashcardOrm.getFlashcardByTopicUserId(selectedFlashcardSet, userId);
					cardsToUse = allCardsInSet.slice(0, questionCount);
				}

				generatedQuestions = cardsToUse.map((card) => ({
					test_id: createdTest.id,
					question_type: TestQuestionQuestionType.ShortAnswer,
					question_text: card.front,
					correct_answer: card.back,
				}));
			} else {
				// Extract main concepts from text
				const sentences = inputText
					.split(/[.!?]+/)
					.map(s => s.trim())
					.filter((s) => s.length > 20);

				// Identify main points: sentences with key indicators
				const keyIndicators = [
					/^(first|second|third|finally|importantly|key|main|primary|essential)/i,
					/\b(is|are|means|refers to|defined as|called|known as)\b/i,
					/\b(because|therefore|thus|hence|consequently|as a result)/i,
					/\b(important|significant|critical|crucial|essential|fundamental)/i,
					/\b(always|never|must|should|will|can)\b/i,
				];

				const mainConcepts = sentences.filter(sentence => {
					// Prioritize sentences with key indicators
					return keyIndicators.some(pattern => pattern.test(sentence)) ||
						   sentence.split(' ').length >= 10; // Or substantial sentences
				});

				// If not enough main concepts found, fall back to substantial sentences
				const conceptsToUse = mainConcepts.length >= questionCount ? mainConcepts :
									  sentences.filter(s => s.split(' ').length >= 8);

				const selectedConcepts = conceptsToUse.slice(0, questionCount);

				generatedQuestions = selectedConcepts.map((concept, idx) => {
					const types = [
						TestQuestionQuestionType.MultipleChoice,
						TestQuestionQuestionType.ShortAnswer,
						TestQuestionQuestionType.TrueFalse,
						TestQuestionQuestionType.FillBlank,
					];
					const randomType = types[idx % types.length];

					let questionText = "";
					let correctAnswer = "";
					let options = null;

					// Extract key terms from the concept
					const words = concept.split(' ');
					const keyTermMatch = concept.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/); // Capitalized terms
					const definitionMatch = concept.match(/\b(is|are|means|refers to|defined as)\s+(.+?)(?:\.|,|$)/i);

					if (randomType === TestQuestionQuestionType.MultipleChoice) {
						// Create question about main concept
						if (definitionMatch && definitionMatch[2]) {
							const definition = definitionMatch[2].trim();
							questionText = `What ${definitionMatch[1]} described in this concept?`;
							correctAnswer = "A";
							options = JSON.stringify([
								`A) ${definition}`,
								"B) The opposite of what is stated",
								"C) Not mentioned in the material",
								"D) A different concept entirely",
							]);
						} else {
							questionText = `What is the main point of this concept?`;
							correctAnswer = "A";
							options = JSON.stringify([
								`A) ${concept.substring(0, 60)}...`,
								"B) This is not covered in the material",
								"C) The inverse of the stated concept",
								"D) None of the above",
							]);
						}
					} else if (randomType === TestQuestionQuestionType.TrueFalse) {
						questionText = `True or False: ${concept}`;
						correctAnswer = "True";
					} else if (randomType === TestQuestionQuestionType.FillBlank) {
						// Find important word to blank out (prefer nouns/key terms)
						let blankIndex = Math.floor(words.length / 2);

						// Try to find a capitalized or important word
						for (let i = 0; i < words.length; i++) {
							if (/^[A-Z]/.test(words[i]) ||
								/(important|key|main|essential|critical)/.test(words[i])) {
								blankIndex = i;
								break;
							}
						}

						const answer = words[blankIndex];
						words[blankIndex] = "______";
						questionText = words.join(" ");
						correctAnswer = answer;
					} else {
						// Short answer - ask about the key concept
						if (keyTermMatch) {
							questionText = `Explain the significance of: ${keyTermMatch[1]}`;
						} else {
							questionText = `Explain the main concept: ${words.slice(0, 5).join(' ')}...`;
						}
						correctAnswer = concept;
					}

					return {
						test_id: createdTest.id,
						question_type: randomType,
						question_text: questionText,
						correct_answer: correctAnswer,
						options,
					};
				});
			}

			if (generatedQuestions.length === 0) {
				toast.error("Not enough content to generate questions");
				await testOrm.deleteTestById(createdTest.id);
				return;
			}

			await questionOrm.insertTestQuestion(generatedQuestions as TestQuestionModel[]);
			toast.success(`Generated ${generatedQuestions.length} questions!`);

			setCurrentTest(createdTest);
			const loadedQuestions = await questionOrm.getTestQuestionByTestId(createdTest.id);
			setQuestions(loadedQuestions);
			setCurrentQuestionIndex(0);
			setUserAnswers({});
			setView("take");
		} catch (error) {
			console.error("Error generating test:", error);
			toast.error("Failed to generate test");
		} finally {
			setGenerating(false);
		}
	};

	const submitTest = async () => {
		if (!currentTest) return;

		try {
			const testOrm = TestORM.getInstance();
			const questionOrm = TestQuestionORM.getInstance();

			// Grade the test
			let correctCount = 0;
			const updatedQuestions: TestQuestionModel[] = [];

			for (const question of questions) {
				const userAnswer = userAnswers[question.id] || "";
				const isCorrect =
					userAnswer.toLowerCase().trim() === question.correct_answer.toLowerCase().trim();

				if (isCorrect) correctCount++;

				const updated: TestQuestionModel = {
					...question,
					user_answer: userAnswer,
					is_correct: isCorrect,
				};

				updatedQuestions.push(updated);
				await questionOrm.setTestQuestionById(question.id, updated);
			}

			const score = Math.round((correctCount / questions.length) * 100);

			// Update test
			const updatedTest: TestModel = {
				...currentTest,
				completed_at: new Date().toISOString(),
				score,
			};

			await testOrm.setTestById(currentTest.id, updatedTest);
			setCurrentTest(updatedTest);
			setQuestions(updatedQuestions);

			// Update performance metrics
			await updatePerformanceMetrics(currentTest.topic, correctCount, questions.length);

			toast.success(`Test completed! Score: ${score}%`);
			setView("results");
			loadTests();
		} catch (error) {
			console.error("Error submitting test:", error);
			toast.error("Failed to submit test");
		}
	};

	const updatePerformanceMetrics = async (topic: string, correct: number, total: number) => {
		try {
			const metricOrm = PerformanceMetricORM.getInstance();
			const existing = await metricOrm.getPerformanceMetricByTopicUserId(topic, userId);

			if (existing.length > 0) {
				const current = existing[0];
				const updated: PerformanceMetricModel = {
					...current,
					total_questions: (current.total_questions || 0) + total,
					correct_answers: (current.correct_answers || 0) + correct,
					average_score: Math.round(
						(((current.correct_answers || 0) + correct) /
							((current.total_questions || 0) + total)) *
							100,
					),
				};
				await metricOrm.setPerformanceMetricById(current.id, updated);
			} else {
				const newMetric: Partial<PerformanceMetricModel> = {
					user_id: userId,
					topic,
					total_questions: total,
					correct_answers: correct,
					average_score: Math.round((correct / total) * 100),
					weak_areas: JSON.stringify([]),
				};
				await metricOrm.insertPerformanceMetric([newMetric as PerformanceMetricModel]);
			}
		} catch (error) {
			console.error("Error updating metrics:", error);
		}
	};

	const startExistingTest = async (test: TestModel) => {
		try {
			const questionOrm = TestQuestionORM.getInstance();
			const loadedQuestions = await questionOrm.getTestQuestionByTestId(test.id);
			setCurrentTest(test);
			setQuestions(loadedQuestions);
			setCurrentQuestionIndex(0);
			setUserAnswers({});

			if (test.completed_at) {
				// Load existing answers
				const answers: Record<string, string> = {};
				loadedQuestions.forEach((q) => {
					if (q.user_answer) answers[q.id] = q.user_answer;
				});
				setUserAnswers(answers);
				setView("results");
			} else {
				setView("take");
			}
		} catch (error) {
			console.error("Error loading test:", error);
			toast.error("Failed to load test");
		}
	};

	const deleteTest = async (test: TestModel, event: React.MouseEvent) => {
		event.stopPropagation();

		try {
			const testOrm = TestORM.getInstance();
			const questionOrm = TestQuestionORM.getInstance();

			// Delete all questions associated with this test
			const testQuestions = await questionOrm.getTestQuestionByTestId(test.id);
			for (const question of testQuestions) {
				await questionOrm.deleteTestQuestionById(question.id);
			}

			// Delete the test itself
			await testOrm.deleteTestById(test.id);

			toast.success("Test deleted successfully");
			loadTests();
		} catch (error) {
			console.error("Error deleting test:", error);
			toast.error("Failed to delete test");
		}
	};

	const currentQuestion = questions[currentQuestionIndex];
	const progress = currentTest ? ((currentQuestionIndex + 1) / questions.length) * 100 : 0;

	return (
		<div className="space-y-6 animate-fade-in">
			{view === "create" && (
				<>
					<Card className="shadow-xl border-2 border-green-200 dark:border-green-800 bg-gradient-to-br from-white via-green-50 to-white dark:from-gray-900 dark:via-green-950 dark:to-gray-900">
						<CardHeader>
							<CardTitle className="flex items-center gap-3 text-2xl font-bold">
								<div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg shadow-lg">
									<FileQuestion className="h-6 w-6 text-white" />
								</div>
								Test Maker
							</CardTitle>
							<CardDescription className="text-base mt-2">
								Generate practice tests from your notes or flashcards, or create your own custom test
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-6">
							<Tabs value={activeCreationTab} onValueChange={setActiveCreationTab}>
								<TabsList className="grid w-full grid-cols-3">
									<TabsTrigger
										value="text"
										onClick={() => setUseFlashcards(false)}
									>
										From Text
									</TabsTrigger>
									<TabsTrigger
										value="flashcards"
										onClick={() => setUseFlashcards(true)}
									>
										From Flashcards
									</TabsTrigger>
									<TabsTrigger
										value="manual"
										onClick={() => setUseFlashcards(false)}
									>
										Manual
									</TabsTrigger>
								</TabsList>

								<TabsContent value="text" className="space-y-4 mt-6">
									<div className="space-y-2">
										<Label htmlFor="topic">Topic</Label>
										<Input
											id="topic"
											placeholder="e.g., World War II"
											value={topic}
											onChange={(e) => setTopic(e.target.value)}
										/>
									</div>

									<div className="space-y-2">
										<Label htmlFor="content">Study Material</Label>
										<Textarea
											id="content"
											placeholder="Paste your notes, textbook content, or study material here..."
											value={inputText}
											onChange={(e) => setInputText(e.target.value)}
											rows={10}
										/>
									</div>
								</TabsContent>

								<TabsContent value="flashcards" className="space-y-4 mt-6">
									<div className="space-y-2">
										<Label htmlFor="flashcard-set">Choose Flashcard Set</Label>
										<Select
											value={selectedFlashcardSet}
											onValueChange={setSelectedFlashcardSet}
										>
											<SelectTrigger id="flashcard-set">
												<SelectValue placeholder="Select a flashcard set" />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="all-weak">
													All Weak Cards (Learning + New)
												</SelectItem>
												{flashcardSets.length > 0 && (
													<>
														<div className="px-2 py-1.5 text-xs font-semibold text-gray-500">
															Your Sets
														</div>
														{flashcardSets.map((set) => (
															<SelectItem key={set} value={set}>
																{set}
															</SelectItem>
														))}
													</>
												)}
											</SelectContent>
										</Select>
									</div>

									<div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
										<p className="text-sm text-blue-800">
											{selectedFlashcardSet === "all-weak"
												? "This will generate a test from your flashcards marked as 'Learning' or 'New' across all sets to help you practice weak areas."
												: `This will generate a test from the "${selectedFlashcardSet}" flashcard set.`}
										</p>
									</div>
								</TabsContent>

								<TabsContent value="manual" className="space-y-4 mt-6">
									<div className="space-y-2">
										<Label htmlFor="manual-title">Test Title</Label>
										<Input
											id="manual-title"
											placeholder="e.g., Chapter 5 Practice Test"
											value={manualTestTitle}
											onChange={(e) => setManualTestTitle(e.target.value)}
										/>
									</div>

									<div className="space-y-3">
										<Label className="text-base font-medium">Questions</Label>
										{manualQuestions.map((q, index) => (
											<div key={index} className="p-4 border rounded-lg space-y-3 bg-gray-50">
												<div className="flex items-center justify-between">
													<span className="font-medium">Question {index + 1}</span>
													<Button
														variant="ghost"
														size="sm"
														onClick={() => {
															const updated = manualQuestions.filter((_, i) => i !== index);
															setManualQuestions(updated);
														}}
													>
														<XCircle className="h-4 w-4" />
													</Button>
												</div>
												<div className="space-y-2">
													<Input
														placeholder="Question text"
														value={q.question}
														onChange={(e) => {
															const updated = [...manualQuestions];
															updated[index].question = e.target.value;
															setManualQuestions(updated);
														}}
													/>
													<Input
														placeholder="Correct answer"
														value={q.answer}
														onChange={(e) => {
															const updated = [...manualQuestions];
															updated[index].answer = e.target.value;
															setManualQuestions(updated);
														}}
													/>
													<Select
														value={q.type.toString()}
														onValueChange={(value) => {
															const updated = [...manualQuestions];
															updated[index].type = parseInt(value) as TestQuestionQuestionType;
															setManualQuestions(updated);
														}}
													>
														<SelectTrigger>
															<SelectValue placeholder="Question type" />
														</SelectTrigger>
														<SelectContent>
															<SelectItem value={TestQuestionQuestionType.MultipleChoice.toString()}>
																Multiple Choice
															</SelectItem>
															<SelectItem value={TestQuestionQuestionType.TrueFalse.toString()}>
																True/False
															</SelectItem>
															<SelectItem value={TestQuestionQuestionType.ShortAnswer.toString()}>
																Short Answer
															</SelectItem>
															<SelectItem value={TestQuestionQuestionType.FillBlank.toString()}>
																Fill in the Blank
															</SelectItem>
														</SelectContent>
													</Select>
												</div>
											</div>
										))}

										<Button
											variant="outline"
											className="w-full"
											onClick={() => {
												setManualQuestions([
													...manualQuestions,
													{
														question: "",
														answer: "",
														type: TestQuestionQuestionType.ShortAnswer,
													},
												]);
											}}
										>
											<Sparkles className="h-4 w-4 mr-2" />
											Add Question
										</Button>
									</div>

									<div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
										<p className="text-sm text-blue-800">
											Create your own custom test by adding questions manually. Perfect for practicing specific topics or preparing for exams.
										</p>
									</div>
								</TabsContent>
							</Tabs>

							<div className="grid grid-cols-2 gap-4">
								<div className="space-y-2">
									<Label htmlFor="difficulty">Difficulty</Label>
									<Select
										value={difficulty.toString()}
										onValueChange={(v) => setDifficulty(parseInt(v))}
									>
										<SelectTrigger id="difficulty">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value={TestDifficulty.Easy.toString()}>
												Easy
											</SelectItem>
											<SelectItem value={TestDifficulty.Medium.toString()}>
												Medium
											</SelectItem>
											<SelectItem value={TestDifficulty.Hard.toString()}>
												Hard
											</SelectItem>
										</SelectContent>
									</Select>
								</div>

								<div className="space-y-2">
									<Label htmlFor="count">Number of Questions</Label>
									<Select
										value={questionCount.toString()}
										onValueChange={(v) => setQuestionCount(parseInt(v))}
									>
										<SelectTrigger id="count">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="5">5 questions</SelectItem>
											<SelectItem value="10">10 questions</SelectItem>
											<SelectItem value="15">15 questions</SelectItem>
											<SelectItem value="20">20 questions</SelectItem>
										</SelectContent>
									</Select>
								</div>
							</div>

							{activeCreationTab === "manual" ? (
								<Button
									onClick={createManualTest}
									disabled={
										generating ||
										!manualTestTitle.trim() ||
										manualQuestions.length === 0
									}
									className="w-full gap-2 bg-gradient-to-r from-green-600 via-emerald-600 to-green-700 hover:from-green-700 hover:via-emerald-700 hover:to-green-800 shadow-xl hover:shadow-2xl transition-all duration-300 text-lg font-semibold"
									size="lg"
								>
									<Sparkles className="h-6 w-6" />
									{generating ? "Creating Test..." : "Create Test"}
								</Button>
							) : (
								<Button
									onClick={generateTest}
									disabled={
										generating ||
										(!inputText.trim() && !useFlashcards) ||
										(useFlashcards && !selectedFlashcardSet)
									}
									className="w-full gap-2 bg-gradient-to-r from-green-600 via-emerald-600 to-green-700 hover:from-green-700 hover:via-emerald-700 hover:to-green-800 shadow-xl hover:shadow-2xl transition-all duration-300 text-lg font-semibold"
									size="lg"
								>
									<Sparkles className="h-6 w-6" />
									{generating ? "Generating Test..." : "Generate Test"}
								</Button>
							)}
						</CardContent>
					</Card>

					{/* Previous Tests */}
					{tests.length > 0 && (
						<Card>
							<CardHeader>
								<CardTitle className="text-lg">Your Tests</CardTitle>
							</CardHeader>
							<CardContent>
								<div className="space-y-3">
									{tests.slice(-5).reverse().map((test) => (
										<div
											key={test.id}
											className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer group"
											onClick={() => startExistingTest(test)}
										>
											<div>
												<div className="font-medium">{test.title}</div>
												<div className="text-sm text-gray-600">
													{test.question_count} questions •{" "}
													{test.difficulty === TestDifficulty.Easy
														? "Easy"
														: test.difficulty === TestDifficulty.Medium
															? "Medium"
															: "Hard"}
												</div>
											</div>
											<div className="flex items-center gap-2">
												{test.score !== null && test.score !== undefined ? (
													<Badge
														className={
															test.score >= 80
																? "bg-green-100 text-green-700"
																: test.score >= 60
																	? "bg-yellow-100 text-yellow-700"
																	: "bg-red-100 text-red-700"
														}
													>
														{test.score}%
													</Badge>
												) : (
													<Badge variant="outline">In Progress</Badge>
												)}
												<Button
													variant="ghost"
													size="icon"
													className="opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-100 hover:text-red-700"
													onClick={(e) => deleteTest(test, e)}
												>
													<Trash2 className="h-4 w-4" />
												</Button>
											</div>
										</div>
									))}
								</div>
							</CardContent>
						</Card>
					)}
				</>
			)}

			{view === "take" && currentTest && (
				<Card>
					<CardHeader>
						<div className="flex items-center justify-between">
							<div>
								<CardTitle>{currentTest.title}</CardTitle>
								<CardDescription>
									Question {currentQuestionIndex + 1} of {questions.length}
								</CardDescription>
							</div>
							<Badge variant="outline" className="gap-2">
								<Clock className="h-3 w-3" />
								In Progress
							</Badge>
						</div>
						<Progress value={progress} className="mt-4" />
					</CardHeader>
					<CardContent className="space-y-6">
						{currentQuestion && (
							<>
								<div className="space-y-4">
									<div className="flex items-start gap-3">
										<Badge>{currentQuestionIndex + 1}</Badge>
										<div className="flex-1">
											<p className="text-lg font-medium mb-2">
												{currentQuestion.question_text}
											</p>
											<Badge variant="secondary">
												{currentQuestion.question_type ===
												TestQuestionQuestionType.MultipleChoice
													? "Multiple Choice"
													: currentQuestion.question_type ===
														  TestQuestionQuestionType.TrueFalse
														? "True/False"
														: currentQuestion.question_type ===
															  TestQuestionQuestionType.FillBlank
															? "Fill in the Blank"
															: "Short Answer"}
											</Badge>
										</div>
									</div>

									{currentQuestion.question_type ===
										TestQuestionQuestionType.MultipleChoice &&
									currentQuestion.options ? (
										<RadioGroup
											value={userAnswers[currentQuestion.id] || ""}
											onValueChange={(value) =>
												setUserAnswers({
													...userAnswers,
													[currentQuestion.id]: value,
												})
											}
										>
											<div className="space-y-3">
												{JSON.parse(currentQuestion.options).map(
													(option: string, idx: number) => (
														<div
															key={idx}
															className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50"
														>
															<RadioGroupItem
																value={option.charAt(0)}
																id={`q${currentQuestion.id}-${idx}`}
															/>
															<Label
																htmlFor={`q${currentQuestion.id}-${idx}`}
																className="flex-1 cursor-pointer"
															>
																{option}
															</Label>
														</div>
													),
												)}
											</div>
										</RadioGroup>
									) : currentQuestion.question_type ===
									  TestQuestionQuestionType.TrueFalse ? (
										<RadioGroup
											value={userAnswers[currentQuestion.id] || ""}
											onValueChange={(value) =>
												setUserAnswers({
													...userAnswers,
													[currentQuestion.id]: value,
												})
											}
										>
											<div className="space-y-3">
												<div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
													<RadioGroupItem value="True" id="true" />
													<Label htmlFor="true" className="flex-1 cursor-pointer">
														True
													</Label>
												</div>
												<div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
													<RadioGroupItem value="False" id="false" />
													<Label htmlFor="false" className="flex-1 cursor-pointer">
														False
													</Label>
												</div>
											</div>
										</RadioGroup>
									) : (
										<Textarea
											placeholder="Type your answer here..."
											value={userAnswers[currentQuestion.id] || ""}
											onChange={(e) =>
												setUserAnswers({
													...userAnswers,
													[currentQuestion.id]: e.target.value,
												})
											}
											rows={4}
										/>
									)}
								</div>

								<div className="flex justify-between">
									<Button
										onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}
										disabled={currentQuestionIndex === 0}
										variant="outline"
									>
										Previous
									</Button>

									{currentQuestionIndex < questions.length - 1 ? (
										<Button
											onClick={() =>
												setCurrentQuestionIndex(currentQuestionIndex + 1)
											}
										>
											Next Question
										</Button>
									) : (
										<Button onClick={submitTest} className="bg-green-600 hover:bg-green-700">
											Submit Test
										</Button>
									)}
								</div>
							</>
						)}
					</CardContent>
				</Card>
			)}

			{view === "results" && currentTest && (
				<>
					<Card>
						<CardHeader>
							<div className="text-center space-y-4">
								<CardTitle className="text-2xl">{currentTest.title}</CardTitle>
								<div>
									<div
										className={`text-6xl font-bold ${
											(currentTest.score || 0) >= 80
												? "text-green-600"
												: (currentTest.score || 0) >= 60
													? "text-yellow-600"
													: "text-red-600"
										}`}
									>
										{currentTest.score}%
									</div>
									<p className="text-gray-600 mt-2">
										{questions.filter((q) => q.is_correct).length} out of{" "}
										{questions.length} correct
									</p>
								</div>
							</div>
						</CardHeader>
					</Card>

					<Card>
						<CardHeader>
							<CardTitle>Question Review</CardTitle>
						</CardHeader>
						<CardContent className="space-y-4">
							{questions.map((question, idx) => (
								<div
									key={question.id}
									className={`p-4 rounded-lg border-2 ${
										question.is_correct
											? "border-green-200 bg-green-50"
											: "border-red-200 bg-red-50"
									}`}
								>
									<div className="flex items-start gap-3">
										{question.is_correct ? (
											<CheckCircle2 className="h-5 w-5 text-green-600 mt-1" />
										) : (
											<XCircle className="h-5 w-5 text-red-600 mt-1" />
										)}
										<div className="flex-1 space-y-2">
											<p className="font-medium">
												{idx + 1}. {question.question_text}
											</p>
											<div className="text-sm space-y-1">
												<p>
													<span className="font-medium">Your answer:</span>{" "}
													<span
														className={
															question.is_correct
																? "text-green-700"
																: "text-red-700"
														}
													>
														{question.user_answer || "(No answer)"}
													</span>
												</p>
												{!question.is_correct && (
													<p>
														<span className="font-medium">Correct answer:</span>{" "}
														<span className="text-green-700">
															{question.correct_answer}
														</span>
													</p>
												)}
											</div>
										</div>
									</div>
								</div>
							))}
						</CardContent>
					</Card>

					{/* Wrong Answers Section */}
					{questions.filter((q) => !q.is_correct).length > 0 && (
						<Card className="border-red-200 bg-red-50/50">
							<CardHeader>
								<Button
									variant="ghost"
									className="w-full flex items-center justify-between p-4 hover:bg-red-100/50"
									onClick={() => setShowWrongAnswers(!showWrongAnswers)}
								>
									<div className="flex items-center gap-2">
										<AlertCircle className="h-5 w-5 text-red-600" />
										<span className="font-semibold text-red-900">
											Review Wrong Answers ({questions.filter((q) => !q.is_correct).length})
										</span>
									</div>
									{showWrongAnswers ? (
										<ChevronUp className="h-5 w-5 text-red-600" />
									) : (
										<ChevronDown className="h-5 w-5 text-red-600" />
									)}
								</Button>
							</CardHeader>
							{showWrongAnswers && (
								<CardContent className="space-y-4 pt-0">
									{questions
										.map((question, idx) => ({ question, idx }))
										.filter(({ question }) => !question.is_correct)
										.map(({ question, idx }) => (
											<div
												key={question.id}
												className="p-4 rounded-lg border-2 border-red-300 bg-white"
											>
												<div className="flex items-start gap-3">
													<XCircle className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
													<div className="flex-1 space-y-3">
														<p className="font-medium text-gray-900">
															{idx + 1}. {question.question_text}
														</p>
														<div className="space-y-2 text-sm">
															<div className="p-3 bg-red-50 rounded-md border border-red-200">
																<p className="font-medium text-red-900 mb-1">Your answer:</p>
																<p className="text-red-700">
																	{question.user_answer || "(No answer provided)"}
																</p>
															</div>
															<div className="p-3 bg-green-50 rounded-md border border-green-200">
																<p className="font-medium text-green-900 mb-1">Correct answer:</p>
																<p className="text-green-700">
																	{question.correct_answer}
																</p>
															</div>
														</div>
													</div>
												</div>
											</div>
										))}
								</CardContent>
							)}
						</Card>
					)}

					<div className="flex gap-3">
						<Button onClick={() => setView("create")} variant="outline" className="flex-1">
							Create New Test
						</Button>
						<Button
							onClick={() => {
								setView("take");
								setCurrentQuestionIndex(0);
								setUserAnswers({});
							}}
							className="flex-1"
						>
							Retake Test
						</Button>
					</div>
				</>
			)}
		</div>
	);
}
