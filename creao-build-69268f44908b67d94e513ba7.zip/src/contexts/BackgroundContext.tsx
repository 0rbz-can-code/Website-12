import { createContext, useContext, useState, type ReactNode } from "react";

export type BackgroundTheme =
	| "gradient"
	| "focuscore-light"
	| "focuscore-dark"
	| "forest"
	| "ocean"
	| "sunset"
	| "night-sky"
	| "space"
	| "beach"
	| "nature-mountains"
	| "nature-forest"
	| "abstract-waves"
	| "abstract-geometry"
	| "minimalist-lines";

interface BackgroundContextType {
	theme: BackgroundTheme;
	setTheme: (theme: BackgroundTheme) => void;
}

const BackgroundContext = createContext<BackgroundContextType | undefined>(undefined);

export function BackgroundProvider({ children }: { children: ReactNode }) {
	const [theme, setTheme] = useState<BackgroundTheme>(() => {
		const saved = localStorage.getItem("background-theme");
		return (saved as BackgroundTheme) || "gradient";
	});

	const handleSetTheme = (newTheme: BackgroundTheme) => {
		setTheme(newTheme);
		localStorage.setItem("background-theme", newTheme);
	};

	return (
		<BackgroundContext.Provider value={{ theme, setTheme: handleSetTheme }}>
			{children}
		</BackgroundContext.Provider>
	);
}

export function useBackground() {
	const context = useContext(BackgroundContext);
	if (context === undefined) {
		throw new Error("useBackground must be used within a BackgroundProvider");
	}
	return context;
}

export function getBackgroundClass(theme: BackgroundTheme): string {
	switch (theme) {
		case "gradient":
			return "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50";
		case "focuscore-light":
			return "bg-white";
		case "focuscore-dark":
			return "bg-black";
		case "forest":
			return "bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50";
		case "ocean":
			return "bg-gradient-to-br from-blue-50 via-cyan-50 to-sky-50";
		case "sunset":
			return "bg-gradient-to-br from-orange-50 via-rose-50 to-pink-50";
		case "night-sky":
			return "bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950";
		case "space":
			return "bg-black";
		case "beach":
			return "bg-gradient-to-br from-amber-50 via-orange-50 to-cyan-100";
		case "nature-mountains":
			return "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJza3kiIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMCUiIHkyPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdHlsZT0ic3RvcC1jb2xvcjojODdDRUVCO3N0b3Atb3BhY2l0eToxIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojRTBGMkZFO3N0b3Atb3BhY2l0eToxIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSJ1cmwoI3NreSkiLz48cG9seWdvbiBwb2ludHM9IjAsMzAwIDIwMCw0MDAgNTAwLDIwMCA3MDAsNDAwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjNEE1NTY4Ii8+PHBvbHlnb24gcG9pbnRzPSIxMDAsMzUwIDMwMCw0NTAgNjAwLDI1MCA4MDAsNDUwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjNjM3NDhCIi8+PHBvbHlnb24gcG9pbnRzPSIyMDAsMzgwIDQwMCw0ODAgNzAwLDI4MCA5MDAsNDgwIDEwMDAsNjAwIDAsNjAwIiBmaWxsPSIjOEI5NUE2Ii8+PC9zdmc+')] bg-cover bg-center";
		case "nature-forest":
			return "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJmb3Jlc3QiIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMCUiIHkyPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMzQ0RTQxO3N0b3Atb3BhY2l0eToxIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojNkY5MTdEO3N0b3Atb3BhY2l0eToxIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSJ1cmwoI2ZvcmVzdCkiLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxNTAiIHI9IjgwIiBmaWxsPSIjMjI1YTMzIiBvcGFjaXR5PSIwLjYiLz48Y2lyY2xlIGN4PSIzMDAiIGN5PSIyMDAiIHI9IjEwMCIgZmlsbD0iIzFhNGQyZSIgb3BhY2l0eT0iMC42Ii8+PGNpcmNsZSBjeD0iNTUwIiBjeT0iMTgwIiByPSI5MCIgZmlsbD0iIzJmNmUzZiIgb3BhY2l0eT0iMC42Ii8+PGNpcmNsZSBjeD0iNzUwIiBjeT0iMjIwIiByPSIxMTAiIGZpbGw9IiMxYzQ2MmIiIG9wYWNpdHk9IjAuNiIvPjxjaXJjbGUgY3g9IjkwMCIgY3k9IjE2MCIgcj0iNzAiIGZpbGw9IiMyODVhMzgiIG9wYWNpdHk9IjAuNiIvPjwvc3ZnPg==')] bg-cover bg-center";
		case "abstract-waves":
			return "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJ3YXZlcyIgeDE9IjAlIiB5MT0iMCUiIHgyPSIxMDAlIiB5Mj0iMTAwJSI+PHN0b3Agb2Zmc2V0PSIwJSIgc3R5bGU9InN0b3AtY29sb3I6IzY2NjZmZjtzdG9wLW9wYWNpdHk6MSIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3R5bGU9InN0b3AtY29sb3I6I2NjY2NmZjtzdG9wLW9wYWNpdHk6MSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAwIiBoZWlnaHQ9IjYwMCIgZmlsbD0idXJsKCN3YXZlcykiLz48cGF0aCBkPSJNMCAxMDAgUTI1MCA1MCw1MDAgMTAwIFQxMDAwIDEwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiM5OTk5ZmYiIG9wYWNpdHk9IjAuMyIvPjxwYXRoIGQ9Ik0wIDIwMCBRMjUwIDE1MCw1MDAgMjAwIFQxMDAwIDIwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiNiYmJiZmYiIG9wYWNpdHk9IjAuMyIvPjxwYXRoIGQ9Ik0wIDMwMCBRMjUwIDI1MCw1MDAgMzAwIFQxMDAwIDMwMCBMMTAwMCA2MDAgTDAgNjAwIFoiIGZpbGw9IiNkZGRkZmYiIG9wYWNpdHk9IjAuMyIvPjwvc3ZnPg==')] bg-cover bg-center";
		case "abstract-geometry":
			return "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjZjNlNWY1Ii8+PHBvbHlnb24gcG9pbnRzPSIwLDAgMjAwLDAgMTAwLDIwMCIgZmlsbD0iI2U5Y2RmMSIgb3BhY2l0eT0iMC43Ii8+PHBvbHlnb24gcG9pbnRzPSI0MDAsMCA2MDAsMCA1MDAsNDAwIiBmaWxsPSIjZDhiZGU3IiBvcGFjaXR5PSIwLjciLz48cG9seWdvbiBwb2ludHM9IjgwMCwwIDEwMDAsMCA5MDAsNDAwIiBmaWxsPSIjYzdhZGRkIiBvcGFjaXR5PSIwLjciLz48cG9seWdvbiBwb2ludHM9IjAsMzAwIDMwMCwzMDAgMTUwLDYwMCIgZmlsbD0iI2I2OWRjMyIgb3BhY2l0eT0iMC43Ii8+PHBvbHlnb24gcG9pbnRzPSI1MDAsMjAwIDgwMCwyMDAgNjUwLDYwMCIgZmlsbD0iI2E1OGRiOSIgb3BhY2l0eT0iMC43Ii8+PC9zdmc+')] bg-cover bg-center";
		case "minimalist-lines":
			return "bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI2MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjEwMDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjZmFmYWZhIi8+PGxpbmUgeDE9IjAiIHkxPSIxMDAiIHgyPSIxMDAwIiB5Mj0iMTAwIiBzdHJva2U9IiNlMGUwZTAiIHN0cm9rZS13aWR0aD0iMiIvPjxsaW5lIHgxPSIwIiB5MT0iMjAwIiB4Mj0iMTAwMCIgeTI9IjIwMCIgc3Ryb2tlPSIjZTBlMGUwIiBzdHJva2Utd2lkdGg9IjIiLz48bGluZSB4MT0iMCIgeTE9IjMwMCIgeDI9IjEwMDAiIHkyPSIzMDAiIHN0cm9rZT0iI2UwZTBlMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PGxpbmUgeDE9IjAiIHkxPSI0MDAiIHgyPSIxMDAwIiB5Mj0iNDAwIiBzdHJva2U9IiNlMGUwZTAiIHN0cm9rZS13aWR0aD0iMiIvPjxsaW5lIHgxPSIwIiB5MT0iNTAwIiB4Mj0iMTAwMCIgeTI9IjUwMCIgc3Ryb2tlPSIjZTBlMGUwIiBzdHJva2Utd2lkdGg9IjIiLz48L3N2Zz4=')] bg-cover bg-center";
		default:
			return "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50";
	}
}

export function shouldShowSpaceBackground(theme: BackgroundTheme): boolean {
	return theme === "space";
}
