/**
 * Re-export auth API from SDK for ORM client usage
 */
export { platformApi as authApi } from "@/sdk/core/request";
