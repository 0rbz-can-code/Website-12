// Sound Effects Utility for CheatEX

export enum SoundEffect {
	Click = 'click',
	Success = 'success',
	Error = 'error',
	Notification = 'notification',
	FlashcardFlip = 'flashcard-flip',
	TestComplete = 'test-complete',
	Achievement = 'achievement',
	TabSwitch = 'tab-switch',
}

class SoundManager {
	private static instance: SoundManager;
	private audioContext: AudioContext | null = null;
	private volume: number = 0.5;
	private enabled: boolean = true;

	private constructor() {
		// Initialize from localStorage
		const savedVolume = localStorage.getItem('sound-volume');
		const savedEnabled = localStorage.getItem('sound-enabled');

		if (savedVolume) this.volume = parseFloat(savedVolume);
		if (savedEnabled) this.enabled = JSON.parse(savedEnabled);
	}

	static getInstance(): SoundManager {
		if (!SoundManager.instance) {
			SoundManager.instance = new SoundManager();
		}
		return SoundManager.instance;
	}

	private getAudioContext(): AudioContext {
		if (!this.audioContext) {
			this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
		}
		return this.audioContext;
	}

	setVolume(volume: number) {
		this.volume = Math.max(0, Math.min(1, volume));
		localStorage.setItem('sound-volume', this.volume.toString());
	}

	getVolume(): number {
		return this.volume;
	}

	setEnabled(enabled: boolean) {
		this.enabled = enabled;
		localStorage.setItem('sound-enabled', JSON.stringify(enabled));
	}

	isEnabled(): boolean {
		return this.enabled;
	}

	// Generate sounds using Web Audio API with improved quality
	private playTone(frequency: number, duration: number, type: OscillatorType = 'sine', envelope?: 'linear' | 'exponential') {
		if (!this.enabled) return;

		const ctx = this.getAudioContext();
		const oscillator = ctx.createOscillator();
		const gainNode = ctx.createGain();

		oscillator.connect(gainNode);
		gainNode.connect(ctx.destination);

		oscillator.frequency.value = frequency;
		oscillator.type = type;

		// Better volume curve for more pleasant sounds
		const startVolume = this.volume * 0.25;
		gainNode.gain.setValueAtTime(startVolume, ctx.currentTime);

		if (envelope === 'linear') {
			gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + duration);
		} else {
			gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
		}

		oscillator.start(ctx.currentTime);
		oscillator.stop(ctx.currentTime + duration);
	}

	private playChord(frequencies: number[], duration: number, fadeOut: boolean = true) {
		if (!this.enabled) return;

		const ctx = this.getAudioContext();
		const masterGain = ctx.createGain();
		masterGain.connect(ctx.destination);

		// Adjusted volume for better balance
		const startVolume = this.volume * 0.15;
		masterGain.gain.setValueAtTime(startVolume, ctx.currentTime);

		frequencies.forEach(freq => {
			const oscillator = ctx.createOscillator();
			const gainNode = ctx.createGain();

			oscillator.connect(gainNode);
			gainNode.connect(masterGain);

			oscillator.frequency.value = freq;
			oscillator.type = 'sine';

			gainNode.gain.setValueAtTime(1, ctx.currentTime);

			if (fadeOut) {
				gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
			}

			oscillator.start(ctx.currentTime);
			oscillator.stop(ctx.currentTime + duration);
		});
	}

	play(effect: SoundEffect) {
		if (!this.enabled) return;

		switch (effect) {
			case SoundEffect.Click:
				// Gentle, pleasant click
				this.playTone(880, 0.04, 'sine', 'linear');
				setTimeout(() => this.playTone(440, 0.02, 'sine', 'linear'), 20);
				break;

			case SoundEffect.Success:
				// Bright, uplifting ascending arpeggio (C major)
				setTimeout(() => this.playTone(523.25, 0.12, 'sine'), 0);    // C5
				setTimeout(() => this.playTone(659.25, 0.12, 'sine'), 60);   // E5
				setTimeout(() => this.playTone(783.99, 0.16, 'sine'), 120);  // G5
				setTimeout(() => this.playTone(1046.5, 0.2, 'sine'), 180);   // C6
				break;

			case SoundEffect.Error:
				// Gentle warning sound (not harsh)
				this.playTone(392, 0.12, 'sine');
				setTimeout(() => this.playTone(349.23, 0.18, 'sine'), 90);
				break;

			case SoundEffect.Notification:
				// Pleasant double-tone notification
				this.playTone(587.33, 0.1, 'sine');  // D5
				setTimeout(() => this.playTone(880, 0.12, 'sine'), 100);  // A5
				break;

			case SoundEffect.FlashcardFlip:
				// Smooth whoosh with descending pitch
				this.playTone(600, 0.06, 'sine', 'linear');
				setTimeout(() => this.playTone(400, 0.05, 'sine', 'linear'), 30);
				break;

			case SoundEffect.TestComplete:
				// Triumphant celebration (I-IV-V-I progression)
				this.playChord([523.25, 659.25, 783.99], 0.35);  // C major
				setTimeout(() => this.playChord([587.33, 739.99, 880], 0.35), 180);  // D major
				setTimeout(() => this.playChord([659.25, 783.99, 987.77], 0.35), 360);  // E major
				setTimeout(() => this.playChord([523.25, 659.25, 1046.5], 0.5), 540);  // C major (higher)
				break;

			case SoundEffect.Achievement:
				// Magical sparkle sound with ascending tones
				this.playTone(1174.66, 0.08, 'sine');  // D6
				setTimeout(() => this.playTone(1318.51, 0.08, 'sine'), 40);  // E6
				setTimeout(() => this.playTone(1567.98, 0.1, 'sine'), 80);  // G6
				setTimeout(() => this.playTone(2093, 0.15, 'sine'), 120);  // C7
				setTimeout(() => this.playTone(2637.02, 0.18, 'sine'), 160);  // E7
				break;

			case SoundEffect.TabSwitch:
				// Soft, subtle navigation sound
				this.playTone(659.25, 0.05, 'sine', 'linear');
				setTimeout(() => this.playTone(783.99, 0.04, 'sine', 'linear'), 25);
				break;
		}
	}
}

export const soundManager = SoundManager.getInstance();

// Convenience function
export function playSound(effect: SoundEffect) {
	soundManager.play(effect);
}
