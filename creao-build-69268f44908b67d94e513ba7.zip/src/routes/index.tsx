import { createFileRoute } from "@tanstack/react-router";
import { StudyPlatform } from "@/components/StudyPlatform";

export const Route = createFileRoute("/")({
	component: App,
});

function App() {
	return <StudyPlatform />;
}
